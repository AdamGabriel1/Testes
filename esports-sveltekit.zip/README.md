# 🎮 eSports Manager - SvelteKit

Sistema completo de gerenciamento de estatísticas de eSports, recriado com **SvelteKit** + **SQLite**.

## ✨ Funcionalidades

- 📊 **Dashboard** com gráficos interativos (Chart.js)
- 🏆 **Colocações** por partida/quartil
- 🎯 **Jogadores** com kills por quartil
- 🔍 **Filtros** por mês, time e busca textual
- 📤 **Exportação** SQL e CSV
- 🎨 **UI Moderna** com Tailwind CSS (glassmorphism)

## 🚀 Instalação

```bash
# Instalar dependências
npm install

# Desenvolvimento
npm run dev

# Build para produção
npm run build

# Preview da build
npm run preview
```

## 📁 Estrutura

```
src/
├── lib/
│   ├── components/     # Componentes Svelte
│   ├── server/
│   │   └── db.ts       # Conexão SQLite
│   └── types.ts        # Tipagens TypeScript
├── routes/
│   ├── api/
│   │   ├── colocacoes/ # CRUD colocações
│   │   ├── jogadores/  # CRUD jogadores
│   │   ├── stats/      # Estatísticas
│   │   ├── dashboard/  # Dados dos gráficos
│   │   └── export/     # SQL e CSV
│   └── +page.svelte    # Página principal
```

## 🌐 API Endpoints

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/api/colocacoes` | Listar colocações |
| POST | `/api/colocacoes` | Criar colocação |
| PUT | `/api/colocacoes/:id` | Atualizar |
| DELETE | `/api/colocacoes/:id` | Remover |
| GET | `/api/jogadores` | Listar jogadores |
| POST | `/api/jogadores` | Criar jogador |
| PUT | `/api/jogadores/:id` | Atualizar |
| DELETE | `/api/jogadores/:id` | Remover |
| GET | `/api/stats` | Estatísticas gerais |
| GET | `/api/dashboard` | Dados dos gráficos |
| GET | `/api/export/sql` | Exportar SQL |
| GET | `/api/export/csv` | Exportar CSV |

## 📝 Diferenças do projeto original

| Original (Flask) | Novo (SvelteKit) |
|------------------|------------------|
| Flask + HTML | SvelteKit SSR |
| CORS externo | Mesma origem (SSR) |
| sqlite3 | better-sqlite3 |
| JS vanilla | Svelte reativo |
| HTML estático | Componentes Svelte |

## 🏗️ Tecnologias

- [SvelteKit](https://kit.svelte.dev)
- [Tailwind CSS](https://tailwindcss.com)
- [better-sqlite3](https://github.com/WiseLibs/better-sqlite3)
- [Chart.js](https://www.chartjs.org)
- [Font Awesome](https://fontawesome.com)
