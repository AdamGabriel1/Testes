#!/bin/bash
cd "$(dirname "$0")"
echo "🎮 eSports Manager - SvelteKit"
echo ""

# Verificar se Node está instalado
if ! command -v node &> /dev/null; then
    echo "❌ Node.js não encontrado. Instale o Node.js 18+"
    exit 1
fi

# Verificar se node_modules existe
if [ ! -d "node_modules" ]; then
    echo "📦 Instalando dependências..."
    npm install
fi

# Iniciar servidor
echo ""
echo "🚀 Servidor iniciando em http://localhost:5173"
echo ""
npm run dev
