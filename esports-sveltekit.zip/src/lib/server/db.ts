import Database from 'better-sqlite3';
import { join } from 'path';

const DB_PATH = join(process.cwd(), 'esports.db');

let db: Database.Database | null = null;

export function getDb(): Database.Database {
  if (!db) {
    db = new Database(DB_PATH);
    db.exec(`
      CREATE TABLE IF NOT EXISTS colocacoes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Mes TEXT NOT NULL,
        Dia INTEGER NOT NULL,
        Time TEXT NOT NULL,
        Q1_Pos INTEGER NOT NULL,
        Q2_Pos INTEGER NOT NULL,
        Q3_Pos INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS jogadores (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Mes TEXT NOT NULL,
        Dia INTEGER NOT NULL,
        Time TEXT NOT NULL,
        Jogador TEXT NOT NULL,
        Q1_Kills INTEGER NOT NULL,
        Q2_Kills INTEGER NOT NULL,
        Q3_Kills INTEGER NOT NULL
      );
    `);
  }
  return db;
}
