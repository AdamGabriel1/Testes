<script lang="ts">
  import { onMount, onDestroy } from 'svelte';
  import Chart from 'chart.js/auto';
  import type { DashboardData } from '$lib/types';

  export let data: DashboardData | null = null;

  let chartKillsTime: HTMLCanvasElement;
  let chartTopJogadores: HTMLCanvasElement;
  let chartPosicoes: HTMLCanvasElement;
  let chartQuartis: HTMLCanvasElement;

  let charts: Chart[] = [];

  $: if (data && chartKillsTime && chartTopJogadores && chartPosicoes && chartQuartis) {
    renderCharts();
  }

  function renderCharts() {
    charts.forEach(c => c.destroy());
    charts = [];

    if (!data) return;

    const commonOptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { labels: { color: '#e2e8f0' } } },
      scales: {
        y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(148, 163, 184, 0.1)' } },
        x: { ticks: { color: '#94a3b8' }, grid: { display: false } }
      }
    };

    charts.push(new Chart(chartKillsTime, {
      type: 'bar',
      data: {
        labels: data.kills_por_time.map(x => x.Time),
        datasets: [{
          label: 'Kills',
          data: data.kills_por_time.map(x => x.total),
          backgroundColor: 'rgba(99, 102, 241, 0.7)',
          borderColor: '#6366f1',
          borderWidth: 1,
          borderRadius: 6
        }]
      },
      options: { ...commonOptions, plugins: { legend: { display: false } } }
    }));

    charts.push(new Chart(chartTopJogadores, {
      type: 'bar',
      data: {
        labels: data.top_jogadores.map(x => x.Jogador),
        datasets: [{
          label: 'Kills',
          data: data.top_jogadores.map(x => x.total),
          backgroundColor: 'rgba(139, 92, 246, 0.7)',
          borderColor: '#8b5cf6',
          borderWidth: 1,
          borderRadius: 6
        }]
      },
      options: { indexAxis: 'y', ...commonOptions, plugins: { legend: { display: false } } }
    }));

    const colors = ['#fbbf24', '#34d399', '#60a5fa', '#a78bfa', '#f472b6', '#fb923c', '#94a3b8'];
    charts.push(new Chart(chartPosicoes, {
      type: 'doughnut',
      data: {
        labels: data.distribuicao_q1.map(x => `Pos ${x.posicao}`),
        datasets: [{
          data: data.distribuicao_q1.map(x => x.quantidade),
          backgroundColor: colors,
          borderWidth: 0
        }]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'right', labels: { color: '#e2e8f0' } } } }
    }));

    const q = data.kills_quartis;
    charts.push(new Chart(chartQuartis, {
      type: 'line',
      data: {
        labels: ['Q1', 'Q2', 'Q3'],
        datasets: [{
          label: 'Total de Kills',
          data: [q.q1_total, q.q2_total, q.q3_total],
          borderColor: '#ec4899',
          backgroundColor: 'rgba(236, 72, 153, 0.1)',
          fill: true,
          tension: 0.4,
          pointBackgroundColor: '#ec4899',
          pointBorderColor: '#fff',
          pointRadius: 6
        }]
      },
      options: { ...commonOptions, plugins: { legend: { display: false } } }
    }));
  }

  onDestroy(() => {
    charts.forEach(c => c.destroy());
  });
</script>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
  <div class="glass rounded-2xl p-6">
    <h3 class="text-lg font-bold text-white mb-4">Kills por Time (Top 10)</h3>
    <div class="h-64">
      <canvas bind:this={chartKillsTime}></canvas>
    </div>
  </div>
  <div class="glass rounded-2xl p-6">
    <h3 class="text-lg font-bold text-white mb-4">Top Jogadores - Total de Kills</h3>
    <div class="h-64">
      <canvas bind:this={chartTopJogadores}></canvas>
    </div>
  </div>
  <div class="glass rounded-2xl p-6">
    <h3 class="text-lg font-bold text-white mb-4">Distribuição de Colocações Q1</h3>
    <div class="h-64">
      <canvas bind:this={chartPosicoes}></canvas>
    </div>
  </div>
  <div class="glass rounded-2xl p-6">
    <h3 class="text-lg font-bold text-white mb-4">Kills por Quartil (Média)</h3>
    <div class="h-64">
      <canvas bind:this={chartQuartis}></canvas>
    </div>
  </div>
</div>
