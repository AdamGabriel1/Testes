<script lang="ts">
  import type { Colocacao } from '$lib/types';
  import { createEventDispatcher } from 'svelte';

  export let data: Colocacao[] = [];
  export let loading = false;

  const dispatch = createEventDispatcher();

  let sortField: keyof Colocacao | null = null;
  let sortAsc = true;

  $: sorted = [...data].sort((a, b) => {
    if (!sortField) return 0;
    let va = a[sortField];
    let vb = b[sortField];
    if (typeof va === 'string') { va = va.toLowerCase(); vb = vb.toLowerCase(); }
    return sortAsc ? (va > vb ? 1 : -1) : (va < vb ? 1 : -1);
  });

  function sort(field: keyof Colocacao) {
    if (sortField === field) sortAsc = !sortAsc;
    else { sortField = field; sortAsc = true; }
    sorted = sorted;
  }

  function posClass(pos: number) {
    if (pos === 1) return 'text-yellow-400 font-bold';
    if (pos <= 3) return 'text-emerald-400';
    return 'text-slate-400';
  }
</script>

<div class="glass rounded-2xl p-6">
  <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
    <div>
      <h2 class="text-lg font-bold text-white">Colocações por Partida</h2>
      <p class="text-sm text-slate-400">Gerencie as posições dos times em cada quartil</p>
    </div>
    <button on:click={() => dispatch('new')} 
            class="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-semibold hover:shadow-lg hover:shadow-indigo-500/30 transition-all flex items-center gap-2">
      <i class="fas fa-plus"></i> Nova Colocação
    </button>
  </div>

  <div class="overflow-x-auto rounded-xl border border-slate-700/50">
    <table class="w-full text-sm">
      <thead>
        <tr class="bg-slate-800/80 text-slate-300">
          <th class="px-4 py-3 text-left font-semibold cursor-pointer hover:text-white" on:click={() => sort('Mes')}>Mês <i class="fas fa-sort text-xs ml-1"></i></th>
          <th class="px-4 py-3 text-left font-semibold cursor-pointer hover:text-white" on:click={() => sort('Dia')}>Dia <i class="fas fa-sort text-xs ml-1"></i></th>
          <th class="px-4 py-3 text-left font-semibold cursor-pointer hover:text-white" on:click={() => sort('Time')}>Time <i class="fas fa-sort text-xs ml-1"></i></th>
          <th class="px-4 py-3 text-center font-semibold">Q1 Pos</th>
          <th class="px-4 py-3 text-center font-semibold">Q2 Pos</th>
          <th class="px-4 py-3 text-center font-semibold">Q3 Pos</th>
          <th class="px-4 py-3 text-center font-semibold">Média</th>
          <th class="px-4 py-3 text-center font-semibold">Ações</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-700/50">
        {#if loading}
          <tr><td colspan="8" class="px-4 py-8 text-center text-slate-500">
            <div class="inline-block w-5 h-5 border-3 border-white/30 border-t-indigo-500 rounded-full animate-spin mr-2"></div>
            Carregando dados...
          </td></tr>
        {:else if sorted.length === 0}
          <tr><td colspan="8" class="px-4 py-8 text-center text-slate-500">Nenhum registro encontrado</td></tr>
        {:else}
          {#each sorted as c}
            <tr class="row-hover transition-colors">
              <td class="px-4 py-3 text-slate-300">{c.Mes}</td>
              <td class="px-4 py-3 text-slate-300">{c.Dia}</td>
              <td class="px-4 py-3 text-white font-medium">{c.Time}</td>
              <td class="px-4 py-3 text-center {posClass(c.Q1_Pos)}">{c.Q1_Pos}</td>
              <td class="px-4 py-3 text-center {posClass(c.Q2_Pos)}">{c.Q2_Pos}</td>
              <td class="px-4 py-3 text-center {posClass(c.Q3_Pos)}">{c.Q3_Pos}</td>
              <td class="px-4 py-3 text-center text-slate-300">{((c.Q1_Pos + c.Q2_Pos + c.Q3_Pos) / 3).toFixed(1)}</td>
              <td class="px-4 py-3 text-center">
                <button on:click={() => dispatch('edit', c)} class="text-indigo-400 hover:text-indigo-300 mr-2 transition-colors"><i class="fas fa-edit"></i></button>
                <button on:click={() => dispatch('delete', c.id)} class="text-rose-400 hover:text-rose-300 transition-colors"><i class="fas fa-trash"></i></button>
              </td>
            </tr>
          {/each}
        {/if}
      </tbody>
    </table>
  </div>
</div>
