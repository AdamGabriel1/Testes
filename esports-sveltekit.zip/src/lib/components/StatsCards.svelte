<script lang="ts">
  import type { Stats } from '$lib/types';

  export let stats: Stats | null = null;

  const cards = [
    { key: 'total_times' as const, label: 'Total de Times', icon: 'fa-users', color: 'indigo' },
    { key: 'total_jogadores' as const, label: 'Total de Jogadores', icon: 'fa-user-ninja', color: 'purple' },
    { key: 'total_partidas' as const, label: 'Partidas Registradas', icon: 'fa-calendar-check', color: 'pink' },
    { key: 'total_kills' as const, label: 'Total de Kills', icon: 'fa-skull', color: 'rose' }
  ];
</script>

<div class="grid grid-cols-1 md:grid-cols-4 gap-4">
  {#each cards as card, i}
    <div class="stats-card rounded-2xl p-5 animate-fade-in" style="animation-delay: {i * 0.1}s">
      <div class="flex items-center justify-between">
        <div>
          <p class="text-slate-400 text-sm">{card.label}</p>
          <p class="text-2xl font-bold text-white mt-1">
            {stats ? stats[card.key] : '-'}
          </p>
        </div>
        <div class="w-12 h-12 rounded-xl bg-{card.color}-500/20 flex items-center justify-center">
          <i class="fas {card.icon} text-{card.color}-400 text-xl"></i>
        </div>
      </div>
    </div>
  {/each}
</div>
