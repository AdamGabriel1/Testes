<script lang="ts">
  import { createEventDispatcher } from 'svelte';

  export let open = false;
  export let title = 'Novo Registro';
  export let type: 'colocacoes' | 'jogadores' = 'colocacoes';
  export let editing = false;

  const dispatch = createEventDispatcher();

  let form = {
    Mes: 'Maio',
    Dia: 1,
    Time: '',
    Jogador: '',
    Q1: 0,
    Q2: 0,
    Q3: 0
  };

  export function setData(data: Record<string, unknown> | null) {
    if (data) {
      form = {
        Mes: String(data.Mes || 'Maio'),
        Dia: Number(data.Dia || 1),
        Time: String(data.Time || ''),
        Jogador: String(data.Jogador || ''),
        Q1: Number(data[type === 'colocacoes' ? 'Q1_Pos' : 'Q1_Kills'] || 0),
        Q2: Number(data[type === 'colocacoes' ? 'Q2_Pos' : 'Q2_Kills'] || 0),
        Q3: Number(data[type === 'colocacoes' ? 'Q3_Pos' : 'Q3_Kills'] || 0)
      };
    } else {
      form = { Mes: 'Maio', Dia: 1, Time: '', Jogador: '', Q1: 0, Q2: 0, Q3: 0 };
    }
  }

  function handleSubmit() {
    const payload: Record<string, string | number> = {
      Mes: form.Mes,
      Dia: form.Dia,
      Time: form.Time,
    };

    if (type === 'jogadores') {
      payload.Jogador = form.Jogador;
      payload.Q1_Kills = form.Q1;
      payload.Q2_Kills = form.Q2;
      payload.Q3_Kills = form.Q3;
    } else {
      payload.Q1_Pos = form.Q1;
      payload.Q2_Pos = form.Q2;
      payload.Q3_Pos = form.Q3;
    }

    dispatch('save', payload);
  }

  const meses = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
</script>

{#if open}
<div class="fixed inset-0 z-50">
  <div class="absolute inset-0 bg-black/70 backdrop-blur-sm" on:click={() => dispatch('close')}></div>
  <div class="absolute inset-0 flex items-center justify-center p-4">
    <div class="glass-strong rounded-2xl w-full max-w-lg p-6 animate-slide-in relative">
      <button on:click={() => dispatch('close')} class="absolute top-4 right-4 text-slate-400 hover:text-white transition-colors">
        <i class="fas fa-times text-xl"></i>
      </button>
      <h3 class="text-xl font-bold text-white mb-6">{title}</h3>
      <form on:submit|preventDefault={handleSubmit} class="space-y-4">
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium text-slate-400 mb-1">Mês</label>
            <select bind:value={form.Mes} required class="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow">
              {#each meses as m}
                <option value={m}>{m}</option>
              {/each}
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium text-slate-400 mb-1">Dia</label>
            <input type="number" bind:value={form.Dia} min="1" max="31" required 
                   class="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow">
          </div>
        </div>
        <div>
          <label class="block text-sm font-medium text-slate-400 mb-1">Time</label>
          <input type="text" bind:value={form.Time} required 
                 class="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow">
        </div>
        {#if type === 'jogadores'}
        <div>
          <label class="block text-sm font-medium text-slate-400 mb-1">Jogador</label>
          <input type="text" bind:value={form.Jogador} required 
                 class="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow">
        </div>
        {/if}
        <div class="grid grid-cols-3 gap-4">
          <div>
            <label class="block text-sm font-medium text-slate-400 mb-1">Q1</label>
            <input type="number" bind:value={form.Q1} min="0" required 
                   class="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow text-center">
          </div>
          <div>
            <label class="block text-sm font-medium text-slate-400 mb-1">Q2</label>
            <input type="number" bind:value={form.Q2} min="0" required 
                   class="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow text-center">
          </div>
          <div>
            <label class="block text-sm font-medium text-slate-400 mb-1">Q3</label>
            <input type="number" bind:value={form.Q3} min="0" required 
                   class="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow text-center">
          </div>
        </div>
        <div class="flex gap-3 pt-4">
          <button type="button" on:click={() => dispatch('close')} 
                  class="flex-1 py-2.5 rounded-xl border border-slate-600 text-slate-300 hover:bg-slate-700/50 transition-all font-medium">
            Cancelar
          </button>
          <button type="submit" 
                  class="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-semibold hover:shadow-lg hover:shadow-indigo-500/30 transition-all">
            Salvar
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
{/if}
