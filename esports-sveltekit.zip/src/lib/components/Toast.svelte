<script lang="ts">
  import { fly } from 'svelte/transition';

  export let message = '';
  export let type: 'success' | 'error' = 'success';
  export let visible = false;
</script>

{#if visible}
<div class="fixed bottom-6 right-6 z-50" transition:fly={{ y: 20, duration: 300 }}>
  <div class="glass-strong rounded-xl px-6 py-4 flex items-center gap-3 border {type === 'error' ? 'border-rose-500/30' : 'border-emerald-500/30'}">
    <i class="fas {type === 'error' ? 'fa-exclamation-circle text-rose-400' : 'fa-check-circle text-emerald-400'} text-xl"></i>
    <span class="text-white font-medium">{message}</span>
  </div>
</div>
{/if}
