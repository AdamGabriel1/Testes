<script lang="ts">
  import type { Jogador } from '$lib/types';
  import { createEventDispatcher } from 'svelte';

  export let data: Jogador[] = [];
  export let loading = false;

  const dispatch = createEventDispatcher();

  let sortField: keyof Jogador | null = null;
  let sortAsc = true;

  $: sorted = [...data].sort((a, b) => {
    if (!sortField) return 0;
    let va = a[sortField];
    let vb = b[sortField];
    if (typeof va === 'string') { va = va.toLowerCase(); vb = vb.toLowerCase(); }
    return sortAsc ? (va > vb ? 1 : -1) : (va < vb ? 1 : -1);
  });

  function sort(field: keyof Jogador) {
    if (sortField === field) sortAsc = !sortAsc;
    else { sortField = field; sortAsc = true; }
    sorted = sorted;
  }
</script>

<div class="glass rounded-2xl p-6">
  <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
    <div>
      <h2 class="text-lg font-bold text-white">Estatísticas dos Jogadores</h2>
      <p class="text-sm text-slate-400">Gerencie kills e performance dos jogadores</p>
    </div>
    <button on:click={() => dispatch('new')} 
            class="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-semibold hover:shadow-lg hover:shadow-indigo-500/30 transition-all flex items-center gap-2">
      <i class="fas fa-plus"></i> Novo Jogador
    </button>
  </div>

  <div class="overflow-x-auto rounded-xl border border-slate-700/50">
    <table class="w-full text-sm">
      <thead>
        <tr class="bg-slate-800/80 text-slate-300">
          <th class="px-4 py-3 text-left font-semibold cursor-pointer hover:text-white" on:click={() => sort('Mes')}>Mês <i class="fas fa-sort text-xs ml-1"></i></th>
          <th class="px-4 py-3 text-left font-semibold cursor-pointer hover:text-white" on:click={() => sort('Dia')}>Dia <i class="fas fa-sort text-xs ml-1"></i></th>
          <th class="px-4 py-3 text-left font-semibold cursor-pointer hover:text-white" on:click={() => sort('Time')}>Time <i class="fas fa-sort text-xs ml-1"></i></th>
          <th class="px-4 py-3 text-left font-semibold cursor-pointer hover:text-white" on:click={() => sort('Jogador')}>Jogador <i class="fas fa-sort text-xs ml-1"></i></th>
          <th class="px-4 py-3 text-center font-semibold">Q1 Kills</th>
          <th class="px-4 py-3 text-center font-semibold">Q2 Kills</th>
          <th class="px-4 py-3 text-center font-semibold">Q3 Kills</th>
          <th class="px-4 py-3 text-center font-semibold">Total</th>
          <th class="px-4 py-3 text-center font-semibold">Média</th>
          <th class="px-4 py-3 text-center font-semibold">Ações</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-700/50">
        {#if loading}
          <tr><td colspan="10" class="px-4 py-8 text-center text-slate-500">
            <div class="inline-block w-5 h-5 border-3 border-white/30 border-t-indigo-500 rounded-full animate-spin mr-2"></div>
            Carregando dados...
          </td></tr>
        {:else if sorted.length === 0}
          <tr><td colspan="10" class="px-4 py-8 text-center text-slate-500">Nenhum registro encontrado</td></tr>
        {:else}
          {#each sorted as j}
            {@const total = j.Q1_Kills + j.Q2_Kills + j.Q3_Kills}
            <tr class="row-hover transition-colors">
              <td class="px-4 py-3 text-slate-300">{j.Mes}</td>
              <td class="px-4 py-3 text-slate-300">{j.Dia}</td>
              <td class="px-4 py-3 text-white font-medium">{j.Time}</td>
              <td class="px-4 py-3 text-slate-200">{j.Jogador}</td>
              <td class="px-4 py-3 text-center text-slate-300">{j.Q1_Kills}</td>
              <td class="px-4 py-3 text-center text-slate-300">{j.Q2_Kills}</td>
              <td class="px-4 py-3 text-center text-slate-300">{j.Q3_Kills}</td>
              <td class="px-4 py-3 text-center text-white font-bold">{total}</td>
              <td class="px-4 py-3 text-center text-slate-400">{(total / 3).toFixed(1)}</td>
              <td class="px-4 py-3 text-center">
                <button on:click={() => dispatch('edit', j)} class="text-indigo-400 hover:text-indigo-300 mr-2 transition-colors"><i class="fas fa-edit"></i></button>
                <button on:click={() => dispatch('delete', j.id)} class="text-rose-400 hover:text-rose-300 transition-colors"><i class="fas fa-trash"></i></button>
              </td>
            </tr>
          {/each}
        {/if}
      </tbody>
    </table>
  </div>
</div>
