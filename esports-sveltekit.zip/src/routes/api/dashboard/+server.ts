import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { getDb } from '$lib/server/db';

export const GET: RequestHandler = async () => {
  const db = getDb();

  const killsPorTime = db.prepare(`
    SELECT Time, SUM(Q1_Kills + Q2_Kills + Q3_Kills) as total 
    FROM jogadores GROUP BY Time ORDER BY total DESC LIMIT 10
  `).all();

  const topJogadores = db.prepare(`
    SELECT Jogador, SUM(Q1_Kills + Q2_Kills + Q3_Kills) as total 
    FROM jogadores GROUP BY Jogador ORDER BY total DESC LIMIT 10
  `).all();

  const distribuicaoQ1 = db.prepare(`
    SELECT Q1_Pos as posicao, COUNT(*) as quantidade 
    FROM colocacoes GROUP BY Q1_Pos
  `).all();

  const killsQuartis = db.prepare(`
    SELECT 
      SUM(Q1_Kills) as q1_total,
      SUM(Q2_Kills) as q2_total,
      SUM(Q3_Kills) as q3_total
    FROM jogadores
  `).get();

  return json({
    kills_por_time: killsPorTime,
    top_jogadores: topJogadores,
    distribuicao_q1: distribuicaoQ1,
    kills_quartis: killsQuartis
  });
};
