import { json, text } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { getDb } from '$lib/server/db';

export const GET: RequestHandler = async () => {
  const db = getDb();
  const lines: string[] = ['-- eSports Database Export', 'PRAGMA foreign_keys=OFF;', 'BEGIN TRANSACTION;'];

  const tables = db.prepare(`
    SELECT sql FROM sqlite_master WHERE type='table' AND name IN ('colocacoes', 'jogadores')
  `).all() as { sql: string }[];

  for (const t of tables) {
    lines.push(t.sql + ';');
  }

  const colocacoes = db.prepare('SELECT * FROM colocacoes').all() as Record<string, unknown>[];
  for (const row of colocacoes) {
    const vals = Object.values(row).map(v => 
      typeof v === 'string' ? `'${v.replace(/'/g, "''")}'` : String(v)
    ).join(', ');
    lines.push(`INSERT INTO colocacoes VALUES (${vals});`);
  }

  const jogadores = db.prepare('SELECT * FROM jogadores').all() as Record<string, unknown>[];
  for (const row of jogadores) {
    const vals = Object.values(row).map(v => 
      typeof v === 'string' ? `'${v.replace(/'/g, "''")}'` : String(v)
    ).join(', ');
    lines.push(`INSERT INTO jogadores VALUES (${vals});`);
  }

  lines.push('COMMIT;');

  return new Response(lines.join('
'), {
    headers: { 'Content-Type': 'text/plain' }
  });
};
