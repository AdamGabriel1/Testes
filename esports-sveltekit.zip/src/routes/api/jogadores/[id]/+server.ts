import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { getDb } from '$lib/server/db';

export const PUT: RequestHandler = async ({ request, params }) => {
  const db = getDb();
  const data = await request.json();
  const id = parseInt(params.id);

  const stmt = db.prepare(`
    UPDATE jogadores SET Mes=?, Dia=?, Time=?, Jogador=?, Q1_Kills=?, Q2_Kills=?, Q3_Kills=?
    WHERE id=?
  `);
  stmt.run(data.Mes, data.Dia, data.Time, data.Jogador, data.Q1_Kills, data.Q2_Kills, data.Q3_Kills, id);

  return json({ id, ...data });
};

export const DELETE: RequestHandler = async ({ params }) => {
  const db = getDb();
  const id = parseInt(params.id);

  const stmt = db.prepare('DELETE FROM jogadores WHERE id=?');
  stmt.run(id);

  return json({ message: 'Jogador excluído' });
};
