import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { getDb } from '$lib/server/db';

export const GET: RequestHandler = async ({ url }) => {
  const db = getDb();
  const mes = url.searchParams.get('mes');
  const time = url.searchParams.get('time');
  const search = url.searchParams.get('search');

  let sql = 'SELECT * FROM jogadores WHERE 1=1';
  const params: (string | number)[] = [];

  if (mes) {
    sql += ' AND Mes = ?';
    params.push(mes);
  }
  if (time) {
    sql += ' AND Time = ?';
    params.push(time);
  }
  if (search) {
    sql += ' AND (Jogador LIKE ? OR Time LIKE ? OR Mes LIKE ?)';
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }
  sql += ' ORDER BY Mes DESC, Dia DESC';

  const stmt = db.prepare(sql);
  const rows = stmt.all(...params);
  return json(rows);
};

export const POST: RequestHandler = async ({ request }) => {
  const db = getDb();
  const data = await request.json();

  const stmt = db.prepare(`
    INSERT INTO jogadores (Mes, Dia, Time, Jogador, Q1_Kills, Q2_Kills, Q3_Kills)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  const result = stmt.run(data.Mes, data.Dia, data.Time, data.Jogador, data.Q1_Kills, data.Q2_Kills, data.Q3_Kills);

  return json({ id: result.lastInsertRowid, ...data }, { status: 201 });
};
