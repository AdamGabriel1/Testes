import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { getDb } from '$lib/server/db';

export const PUT: RequestHandler = async ({ request, params }) => {
  const db = getDb();
  const data = await request.json();
  const id = parseInt(params.id);

  const stmt = db.prepare(`
    UPDATE colocacoes SET Mes=?, Dia=?, Time=?, Q1_Pos=?, Q2_Pos=?, Q3_Pos=?
    WHERE id=?
  `);
  stmt.run(data.Mes, data.Dia, data.Time, data.Q1_Pos, data.Q2_Pos, data.Q3_Pos, id);

  return json({ id, ...data });
};

export const DELETE: RequestHandler = async ({ params }) => {
  const db = getDb();
  const id = parseInt(params.id);

  const stmt = db.prepare('DELETE FROM colocacoes WHERE id=?');
  stmt.run(id);

  return json({ message: 'Colocação excluída' });
};
