import { json, error } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { getDb } from '$lib/server/db';

export const GET: RequestHandler = async ({ url }) => {
  const db = getDb();
  const mes = url.searchParams.get('mes');
  const search = url.searchParams.get('search');

  let sql = 'SELECT * FROM colocacoes WHERE 1=1';
  const params: (string | number)[] = [];

  if (mes) {
    sql += ' AND Mes = ?';
    params.push(mes);
  }
  if (search) {
    sql += ' AND (Time LIKE ? OR Mes LIKE ?)';
    params.push(`%${search}%`, `%${search}%`);
  }
  sql += ' ORDER BY Mes DESC, Dia DESC, Q1_Pos ASC';

  const stmt = db.prepare(sql);
  const rows = stmt.all(...params);
  return json(rows);
};

export const POST: RequestHandler = async ({ request }) => {
  const db = getDb();
  const data = await request.json();

  const stmt = db.prepare(`
    INSERT INTO colocacoes (Mes, Dia, Time, Q1_Pos, Q2_Pos, Q3_Pos)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  const result = stmt.run(data.Mes, data.Dia, data.Time, data.Q1_Pos, data.Q2_Pos, data.Q3_Pos);

  return json({ id: result.lastInsertRowid, ...data }, { status: 201 });
};
