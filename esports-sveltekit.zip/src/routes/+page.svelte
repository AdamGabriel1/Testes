<script lang="ts">
  import { onMount } from 'svelte';
  import type { Colocacao, Jogador, Stats, DashboardData, TabType } from '$lib/types';
  import StatsCards from '$lib/components/StatsCards.svelte';
  import ColocacoesTable from '$lib/components/ColocacoesTable.svelte';
  import JogadoresTable from '$lib/components/JogadoresTable.svelte';
  import DashboardCharts from '$lib/components/DashboardCharts.svelte';
  import Modal from '$lib/components/Modal.svelte';
  import Toast from '$lib/components/Toast.svelte';

  let activeTab: TabType = 'colocacoes';
  let stats: Stats | null = null;
  let colocacoes: Colocacao[] = [];
  let jogadores: Jogador[] = [];
  let dashboard: DashboardData | null = null;
  let loading = { colocacoes: false, jogadores: false, dashboard: false };

  let modalOpen = false;
  let modalType: 'colocacoes' | 'jogadores' = 'colocacoes';
  let editingId: number | null = null;
  let editData: Record<string, unknown> | null = null;
  let modalRef: Modal;

  let toast = { message: '', type: 'success' as const, visible: false };
  let toastTimer: ReturnType<typeof setTimeout>;

  // Filtros
  let searchColocacoes = '';
  let searchJogadores = '';
  let mesColocacoes = '';
  let mesJogadores = '';
  let timeJogadores = '';
  let filterTimeout: ReturnType<typeof setTimeout>;

  $: meses = [...new Set([...colocacoes.map(c => c.Mes), ...jogadores.map(j => j.Mes)])];
  $: times = [...new Set(jogadores.map(j => j.Time))];

  onMount(() => {
    loadAll();
  });

  async function loadAll() {
    await Promise.all([loadStats(), loadColocacoes(), loadJogadores()]);
  }

  async function loadStats() {
    try {
      const res = await fetch('/api/stats');
      stats = await res.json();
    } catch (e) {
      showToast('Erro ao carregar estatísticas', 'error');
    }
  }

  async function loadColocacoes() {
    loading.colocacoes = true;
    try {
      let url = '/api/colocacoes';
      const params = new URLSearchParams();
      if (searchColocacoes) params.append('search', searchColocacoes);
      if (mesColocacoes) params.append('mes', mesColocacoes);
      if (params.toString()) url += '?' + params.toString();

      const res = await fetch(url);
      colocacoes = await res.json();
    } catch (e) {
      showToast('Erro ao carregar colocações', 'error');
    } finally {
      loading.colocacoes = false;
    }
  }

  async function loadJogadores() {
    loading.jogadores = true;
    try {
      let url = '/api/jogadores';
      const params = new URLSearchParams();
      if (searchJogadores) params.append('search', searchJogadores);
      if (mesJogadores) params.append('mes', mesJogadores);
      if (timeJogadores) params.append('time', timeJogadores);
      if (params.toString()) url += '?' + params.toString();

      const res = await fetch(url);
      jogadores = await res.json();
    } catch (e) {
      showToast('Erro ao carregar jogadores', 'error');
    } finally {
      loading.jogadores = false;
    }
  }

  async function loadDashboard() {
    loading.dashboard = true;
    try {
      const res = await fetch('/api/dashboard');
      dashboard = await res.json();
    } catch (e) {
      showToast('Erro ao carregar dashboard', 'error');
    } finally {
      loading.dashboard = false;
    }
  }

  function debouncedLoad(type: 'colocacoes' | 'jogadores') {
    clearTimeout(filterTimeout);
    filterTimeout = setTimeout(() => {
      type === 'colocacoes' ? loadColocacoes() : loadJogadores();
    }, 300);
  }

  function switchTab(tab: TabType) {
    activeTab = tab;
    if (tab === 'dashboard' && !dashboard) loadDashboard();
  }

  function openModal(type: 'colocacoes' | 'jogadores', data: Colocacao | Jogador | null = null) {
    modalType = type;
    editingId = data ? data.id : null;
    editData = data ? { ...data } : null;
    modalOpen = true;
    // Chamar setData após o modal abrir
    setTimeout(() => {
      if (modalRef) modalRef.setData(editData);
    }, 0);
  }

  async function handleSave(event: CustomEvent) {
    const payload = event.detail;
    const url = editingId ? `/api/${modalType}/${editingId}` : `/api/${modalType}`;
    const method = editingId ? 'PUT' : 'POST';

    try {
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) throw new Error('Erro na requisição');

      showToast(editingId ? 'Registro atualizado!' : 'Registro criado!');
      modalOpen = false;
      await Promise.all([loadStats(), modalType === 'colocacoes' ? loadColocacoes() : loadJogadores()]);
      if (dashboard) loadDashboard();
    } catch (e) {
      showToast('Erro ao salvar registro', 'error');
    }
  }

  async function handleDelete(type: 'colocacoes' | 'jogadores', id: number) {
    if (!confirm('Tem certeza que deseja excluir este registro?')) return;

    try {
      const res = await fetch(`/api/${type}/${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Erro na requisição');

      showToast('Registro excluído!');
      await Promise.all([loadStats(), type === 'colocacoes' ? loadColocacoes() : loadJogadores()]);
      if (dashboard) loadDashboard();
    } catch (e) {
      showToast('Erro ao excluir registro', 'error');
    }
  }

  async function exportSQL() {
    try {
      const res = await fetch('/api/export/sql');
      const text = await res.text();
      downloadFile(text, 'esports_export.sql', 'text/plain');
      showToast('SQL exportado com sucesso!');
    } catch (e) {
      showToast('Erro ao exportar SQL', 'error');
    }
  }

  async function exportCSV() {
    try {
      const res = await fetch('/api/export/csv');
      const text = await res.text();
      downloadFile(text, 'esports_export.csv', 'text/csv');
      showToast('CSV exportado com sucesso!');
    } catch (e) {
      showToast('Erro ao exportar CSV', 'error');
    }
  }

  function downloadFile(content: string, filename: string, type: string) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  function showToast(message: string, type: 'success' | 'error' = 'success') {
    clearTimeout(toastTimer);
    toast = { message, type, visible: true };
    toastTimer = setTimeout(() => { toast.visible = false; }, 3000);
  }

  const tabs = [
    { id: 'colocacoes' as TabType, label: 'Colocações', icon: 'fa-trophy' },
    { id: 'jogadores' as TabType, label: 'Jogadores', icon: 'fa-crosshairs' },
    { id: 'dashboard' as TabType, label: 'Dashboard', icon: 'fa-chart-pie' }
  ];
</script>

<header class="glass-strong sticky top-0 z-50 border-b border-slate-700/50">
  <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
    <div class="flex items-center gap-3">
      <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/30">
        <i class="fas fa-gamepad text-white text-lg"></i>
      </div>
      <div>
        <h1 class="text-xl font-bold text-white glow-text">eSports Manager</h1>
        <p class="text-xs text-slate-400">SvelteKit API REST</p>
      </div>
    </div>
    <div class="flex items-center gap-3">
      <span class="api-online px-3 py-1 rounded-full text-xs font-semibold">
        <i class="fas fa-circle text-xs mr-1"></i> Online
      </span>
      <button on:click={exportSQL} class="px-4 py-2 rounded-lg bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-600/30 transition-all text-sm font-medium flex items-center gap-2">
        <i class="fas fa-download"></i> SQL
      </button>
      <button on:click={exportCSV} class="px-4 py-2 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30 hover:bg-blue-600/30 transition-all text-sm font-medium flex items-center gap-2">
        <i class="fas fa-file-csv"></i> CSV
      </button>
    </div>
  </div>
</header>

<main class="max-w-7xl mx-auto px-4 py-6 space-y-6">
  <StatsCards {stats} />

  <div class="glass rounded-2xl p-2 flex gap-2">
    {#each tabs as tab}
      <button 
        on:click={() => switchTab(tab.id)}
        class="flex-1 py-3 rounded-xl text-sm font-semibold transition-all flex items-center justify-center gap-2
               {activeTab === tab.id ? 'tab-active' : 'text-slate-400 hover:text-white hover:bg-slate-700/50'}">
        <i class="fas {tab.icon}"></i> {tab.label}
      </button>
    {/each}
  </div>

  {#if activeTab === 'colocacoes'}
    <div class="space-y-4">
      <div class="glass rounded-2xl p-6">
        <div class="flex gap-3 mb-4">
          <div class="relative flex-1 max-w-xs">
            <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-500"></i>
            <input type="text" bind:value={searchColocacoes} on:input={() => debouncedLoad('colocacoes')}
                   placeholder="Buscar time ou data..." 
                   class="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white placeholder-slate-500 input-glow outline-none transition-all">
          </div>
          <select bind:value={mesColocacoes} on:change={() => loadColocacoes()} 
                  class="px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow">
            <option value="">Todos os Meses</option>
            {#each meses as m}
              <option value={m}>{m}</option>
            {/each}
          </select>
          <button on:click={loadColocacoes} class="px-3 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-slate-400 hover:text-white transition-all">
            <i class="fas fa-sync-alt"></i>
          </button>
        </div>
      </div>
      <ColocacoesTable data={colocacoes} loading={loading.colocacoes}
                       on:new={() => openModal('colocacoes')}
                       on:edit={(e) => openModal('colocacoes', e.detail)}
                       on:delete={(e) => handleDelete('colocacoes', e.detail)} />
    </div>
  {/if}

  {#if activeTab === 'jogadores'}
    <div class="space-y-4">
      <div class="glass rounded-2xl p-6">
        <div class="flex gap-3 mb-4 flex-wrap">
          <div class="relative flex-1 min-w-[200px]">
            <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-500"></i>
            <input type="text" bind:value={searchJogadores} on:input={() => debouncedLoad('jogadores')}
                   placeholder="Buscar jogador, time..." 
                   class="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white placeholder-slate-500 input-glow outline-none transition-all">
          </div>
          <select bind:value={mesJogadores} on:change={() => loadJogadores()} 
                  class="px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow">
            <option value="">Todos os Meses</option>
            {#each meses as m}
              <option value={m}>{m}</option>
            {/each}
          </select>
          <select bind:value={timeJogadores} on:change={() => loadJogadores()} 
                  class="px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow">
            <option value="">Todos os Times</option>
            {#each times as t}
              <option value={t}>{t}</option>
            {/each}
          </select>
          <button on:click={loadJogadores} class="px-3 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-slate-400 hover:text-white transition-all">
            <i class="fas fa-sync-alt"></i>
          </button>
        </div>
      </div>
      <JogadoresTable data={jogadores} loading={loading.jogadores}
                      on:new={() => openModal('jogadores')}
                      on:edit={(e) => openModal('jogadores', e.detail)}
                      on:delete={(e) => handleDelete('jogadores', e.detail)} />
    </div>
  {/if}

  {#if activeTab === 'dashboard'}
    {#if loading.dashboard}
      <div class="flex items-center justify-center py-20">
        <div class="inline-block w-8 h-8 border-4 border-white/30 border-t-indigo-500 rounded-full animate-spin mr-3"></div>
        <span class="text-slate-400">Carregando dashboard...</span>
      </div>
    {:else}
      <DashboardCharts data={dashboard} />
    {/if}
  {/if}
</main>

<Modal 
  bind:this={modalRef}
  open={modalOpen} 
  type={modalType} 
  title={editingId ? 'Editar Registro' : 'Novo Registro'}
  editing={!!editingId}
  on:close={() => modalOpen = false}
  on:save={handleSave}
/>

<Toast {...toast} />
