# eSports Manager - SvelteKit

Sistema de gerenciamento de eSports refeito com **SvelteKit** fullstack.

## Estrutura

- **Frontend**: SvelteKit SPA com Tailwind CSS v4
- **Backend**: API Routes nativas do SvelteKit (`+server.ts`)
- **Database**: SQLite com `better-sqlite3`
- **Charts**: Chart.js

## Como rodar

### 1. Criar o projeto

```bash
npm create svelte@latest esports-manager
# Escolha: Skeleton project, Yes TypeScript, Yes ESLint/Prettier

cd esports-manager
```

### 2. Instalar dependências

```bash
npm install
npm install better-sqlite3 chart.js
npm install -D @types/better-sqlite3
```

### 3. Copiar os arquivos

Substitua os arquivos do projeto gerado pelos arquivos deste diretório.

### 4. Configurar ambiente

```bash
cp .env.example .env
```

### 5. Rodar

```bash
npm run dev
# ou
npm run dev -- --open
```

O servidor iniciará em `http://localhost:5173` (dev) ou na porta configurada.

## API Endpoints

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/api/colocacoes` | Lista colocações (filtros: `mes`, `search`) |
| POST | `/api/colocacoes` | Cria colocação |
| PUT | `/api/colocacoes/:id` | Atualiza colocação |
| DELETE | `/api/colocacoes/:id` | Remove colocação |
| GET | `/api/jogadores` | Lista jogadores (filtros: `mes`, `time`, `search`) |
| POST | `/api/jogadores` | Cria jogador |
| PUT | `/api/jogadores/:id` | Atualiza jogador |
| DELETE | `/api/jogadores/:id` | Remove jogador |
| GET | `/api/stats` | Estatísticas gerais |
| GET | `/api/dashboard` | Dados para gráficos |
| GET | `/api/export/sql` | Exporta SQL |
| GET | `/api/export/csv` | Exporta CSV |

## Funcionalidades

- ✅ CRUD de Colocações (times por quartil)
- ✅ CRUD de Jogadores (kills por quartil)
- ✅ Filtros por mês, time e busca textual
- ✅ Ordenação de colunas
- ✅ Dashboard com 4 gráficos (Chart.js)
- ✅ Exportação SQL e CSV
- ✅ Design dark mode com glassmorphism
- ✅ Toast notifications
- ✅ SQLite integrado (auto-migração)
