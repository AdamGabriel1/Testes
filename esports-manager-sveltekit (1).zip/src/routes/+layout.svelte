<script lang="ts">
	import '../app.css';
	import Header from '$lib/components/Header.svelte';
	import Toast from '$lib/components/Toast.svelte';
	import { onMount } from 'svelte';
	import { stats, toastMessage } from '$lib/stores';

	onMount(async () => {
		const res = await fetch('/api/stats');
		const data = await res.json();
		stats.set(data);
	});

	// Auto-hide toast
	$effect(() => {
		const msg = $toastMessage;
		if (msg) {
			const timer = setTimeout(() => toastMessage.set(null), 3000);
			return () => clearTimeout(timer);
		}
	});
</script>

<Header />

<main class="max-w-7xl mx-auto px-4 py-6 space-y-6">
	<slot />
</main>

<Toast />
