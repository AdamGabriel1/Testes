import type { RequestHandler } from './$types';
import db from '$lib/db';

export const GET: RequestHandler = async () => {
	const csvLines: string[] = ['Tipo;Mes;Dia;Time;Jogador;Q1;Q2;Q3'];

	const colocacoes = db.prepare('SELECT * FROM colocacoes').all() as Record<string, unknown>[];
	colocacoes.forEach(row => {
		csvLines.push(`Colocacao;${row.Mes};${row.Dia};${row.Time};;${row.Q1_Pos};${row.Q2_Pos};${row.Q3_Pos}`);
	});

	const jogadores = db.prepare('SELECT * FROM jogadores').all() as Record<string, unknown>[];
	jogadores.forEach(row => {
		csvLines.push(`Jogador;${row.Mes};${row.Dia};${row.Time};${row.Jogador};${row.Q1_Kills};${row.Q2_Kills};${row.Q3_Kills}`);
	});

	return new Response(csvLines.join('\n'), {
		headers: {
			'Content-Type': 'text/csv',
			'Content-Disposition': 'attachment; filename=esports.csv'
		}
	});
};
