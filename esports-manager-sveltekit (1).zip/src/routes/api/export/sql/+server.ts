import { text } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import db from '$lib/db';

export const GET: RequestHandler = async () => {
	const sqlLines: string[] = ['-- eSports Database Export', 'PRAGMA foreign_keys=OFF;', 'BEGIN TRANSACTION;'];

	const tables = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name IN ('colocacoes', 'jogadores')").all() as { sql: string }[];
	tables.forEach(row => sqlLines.push(row.sql + ';'));

	const colocacoes = db.prepare('SELECT * FROM colocacoes').all() as Record<string, unknown>[];
	colocacoes.forEach(row => {
		const vals = Object.values(row).map(v =>
			typeof v === 'string' ? `'${v.replace(/'/g, "''")}'` : String(v)
		).join(', ');
		sqlLines.push(`INSERT INTO colocacoes VALUES (${vals});`);
	});

	const jogadores = db.prepare('SELECT * FROM jogadores').all() as Record<string, unknown>[];
	jogadores.forEach(row => {
		const vals = Object.values(row).map(v =>
			typeof v === 'string' ? `'${v.replace(/'/g, "''")}'` : String(v)
		).join(', ');
		sqlLines.push(`INSERT INTO jogadores VALUES (${vals});`);
	});

	sqlLines.push('COMMIT;');

	return new Response(sqlLines.join('\n'), {
		headers: { 'Content-Type': 'text/plain' }
	});
};
