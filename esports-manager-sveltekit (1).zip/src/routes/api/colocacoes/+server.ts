import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import db from '$lib/db';
import type { Colocacao } from '$lib/types';

export const GET: RequestHandler = async ({ url }) => {
	const mes = url.searchParams.get('mes');
	const search = url.searchParams.get('search');

	let sql = 'SELECT * FROM colocacoes WHERE 1=1';
	const params: (string | number)[] = [];

	if (mes) {
		sql += ' AND Mes = ?';
		params.push(mes);
	}
	if (search) {
		sql += ' AND (Time LIKE ? OR Mes LIKE ?)';
		params.push(`%${search}%`, `%${search}%`);
	}
	sql += ' ORDER BY Mes DESC, Dia DESC, Q1_Pos ASC';

	const rows = db.prepare(sql).all(...params) as Colocacao[];
	return json(rows);
};

export const POST: RequestHandler = async ({ request }) => {
	const data = await request.json();
	const result = db.prepare(`
		INSERT INTO colocacoes (Mes, Dia, Time, Q1_Pos, Q2_Pos, Q3_Pos)
		VALUES (?, ?, ?, ?, ?, ?)
	`).run(data.Mes, data.Dia, data.Time, data.Q1_Pos, data.Q2_Pos, data.Q3_Pos);

	return json({ id: result.lastInsertRowid, ...data }, { status: 201 });
};
