import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import db from '$lib/db';

export const PUT: RequestHandler = async ({ request, params }) => {
	const data = await request.json();
	const id = parseInt(params.id);

	db.prepare(`
		UPDATE colocacoes SET Mes=?, Dia=?, Time=?, Q1_Pos=?, Q2_Pos=?, Q3_Pos=?
		WHERE id=?
	`).run(data.Mes, data.Dia, data.Time, data.Q1_Pos, data.Q2_Pos, data.Q3_Pos, id);

	return json({ id, ...data });
};

export const DELETE: RequestHandler = async ({ params }) => {
	const id = parseInt(params.id);
	db.prepare('DELETE FROM colocacoes WHERE id=?').run(id);
	return json({ message: 'Colocação excluída' });
};
