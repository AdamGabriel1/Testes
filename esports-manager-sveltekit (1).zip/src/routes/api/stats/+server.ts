import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import db from '$lib/db';

export const GET: RequestHandler = async () => {
	const totalTimes = db.prepare(`
		SELECT COUNT(DISTINCT Time) as total FROM (
			SELECT Time FROM colocacoes UNION SELECT Time FROM jogadores
		)
	`).get() as { total: number };

	const totalJogadores = db.prepare('SELECT COUNT(*) as total FROM jogadores').get() as { total: number };
	const totalPartidas = db.prepare("SELECT COUNT(DISTINCT Mes || '-' || Dia) as total FROM colocacoes").get() as { total: number };
	const totalKills = db.prepare('SELECT SUM(Q1_Kills + Q2_Kills + Q3_Kills) as total FROM jogadores').get() as { total: number | null };

	return json({
		total_times: totalTimes.total,
		total_jogadores: totalJogadores.total,
		total_partidas: totalPartidas.total,
		total_kills: totalKills.total || 0
	});
};
