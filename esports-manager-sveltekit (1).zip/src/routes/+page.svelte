<script lang="ts">
	import { activeTab } from '$lib/stores';
	import StatsCards from '$lib/components/StatsCards.svelte';
	import ColocacoesTab from '$lib/components/ColocacoesTab.svelte';
	import JogadoresTab from '$lib/components/JogadoresTab.svelte';
	import DashboardTab from '$lib/components/DashboardTab.svelte';

	const tabs = [
		{ id: 'colocacoes' as const, label: 'Colocações', icon: 'fa-trophy' },
		{ id: 'jogadores' as const, label: 'Jogadores', icon: 'fa-crosshairs' },
		{ id: 'dashboard' as const, label: 'Dashboard', icon: 'fa-chart-pie' }
	];
</script>

<svelte:head>
	<title>eSports Manager - SvelteKit</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</svelte:head>

<StatsCards />

<div class="glass rounded-2xl p-2 flex gap-2">
	{#each tabs as tab}
		<button
			onclick={() => activeTab.set(tab.id)}
			class="flex-1 py-3 rounded-xl text-sm font-semibold transition-all flex items-center justify-center gap-2
				{$activeTab === tab.id ? 'tab-active' : 'text-slate-400 hover:text-white hover:bg-slate-700/50'}"
		>
			<i class="fas {tab.icon}"></i> {tab.label}
		</button>
	{/each}
</div>

{#if $activeTab === 'colocacoes'}
	<ColocacoesTab />
{:else if $activeTab === 'jogadores'}
	<JogadoresTab />
{:else}
	<DashboardTab />
{/if}
