import { writable } from 'svelte/store';
import type { Stats, DashboardData } from './types';

export const stats = writable<Stats>({
	total_times: 0,
	total_jogadores: 0,
	total_partidas: 0,
	total_kills: 0
});

export const dashboardData = writable<DashboardData | null>(null);
export const toastMessage = writable<{ msg: string; type: 'success' | 'error' } | null>(null);
export const activeTab = writable<'colocacoes' | 'jogadores' | 'dashboard'>('colocacoes');
