import Database from 'better-sqlite3';
import { DB_PATH } from '$env/static/private';
import { existsSync, mkdirSync } from 'fs';
import { dirname } from 'path';

const dbPath = DB_PATH || './data/esports.db';

// Garante que o diretório existe
const dir = dirname(dbPath);
if (!existsSync(dir)) {
	mkdirSync(dir, { recursive: true });
}

const db = new Database(dbPath);
db.pragma('journal_mode = WAL');

// Cria as tabelas se não existirem
db.exec(`
	CREATE TABLE IF NOT EXISTS colocacoes (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		Mes TEXT NOT NULL,
		Dia INTEGER NOT NULL,
		Time TEXT NOT NULL,
		Q1_Pos INTEGER NOT NULL,
		Q2_Pos INTEGER NOT NULL,
		Q3_Pos INTEGER NOT NULL
	);

	CREATE TABLE IF NOT EXISTS jogadores (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		Mes TEXT NOT NULL,
		Dia INTEGER NOT NULL,
		Time TEXT NOT NULL,
		Jogador TEXT NOT NULL,
		Q1_Kills INTEGER NOT NULL,
		Q2_Kills INTEGER NOT NULL,
		Q3_Kills INTEGER NOT NULL
	);
`);

export default db;
