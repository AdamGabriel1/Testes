<script lang="ts">
	import { onMount } from 'svelte';
	import Chart from 'chart.js/auto';
	import type { DashboardData } from '$lib/types';

	let data: DashboardData | null = $state(null);
	let loading = $state(true);
	let charts: Record<string, Chart> = {};

	let killsTimeCanvas: HTMLCanvasElement;
	let topJogadoresCanvas: HTMLCanvasElement;
	let posicoesCanvas: HTMLCanvasElement;
	let quartisCanvas: HTMLCanvasElement;

	onMount(async () => {
		const res = await fetch('/api/dashboard');
		data = await res.json();
		loading = false;
	});

	$effect(() => {
		if (data && !loading) {
			// Destrói charts anteriores
			Object.values(charts).forEach(c => c.destroy());

			charts.killsTime = new Chart(killsTimeCanvas, {
				type: 'bar',
				data: {
					labels: data.kills_por_time.map(x => x.Time),
					datasets: [{
						label: 'Kills',
						data: data.kills_por_time.map(x => x.total),
						backgroundColor: 'rgba(99, 102, 241, 0.7)',
						borderColor: '#6366f1',
						borderWidth: 1,
						borderRadius: 6
					}]
				},
				options: {
					responsive: true,
					plugins: { legend: { display: false } },
					scales: {
						y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(148, 163, 184, 0.1)' } },
						x: { ticks: { color: '#94a3b8' }, grid: { display: false } }
					}
				}
			});

			charts.topJogadores = new Chart(topJogadoresCanvas, {
				type: 'bar',
				data: {
					labels: data.top_jogadores.map(x => x.Jogador),
					datasets: [{
						label: 'Kills',
						data: data.top_jogadores.map(x => x.total),
						backgroundColor: 'rgba(139, 92, 246, 0.7)',
						borderColor: '#8b5cf6',
						borderWidth: 1,
						borderRadius: 6
					}]
				},
				options: {
					responsive: true,
					indexAxis: 'y',
					plugins: { legend: { display: false } },
					scales: {
						x: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(148, 163, 184, 0.1)' } },
						y: { ticks: { color: '#94a3b8' }, grid: { display: false } }
					}
				}
			});

			const colors = ['#fbbf24', '#34d399', '#60a5fa', '#a78bfa', '#f472b6', '#fb923c', '#94a3b8'];
			charts.posicoes = new Chart(posicoesCanvas, {
				type: 'doughnut',
				data: {
					labels: data.distribuicao_q1.map(x => `Pos ${x.posicao}`),
					datasets: [{
						data: data.distribuicao_q1.map(x => x.quantidade),
						backgroundColor: colors,
						borderWidth: 0
					}]
				},
				options: {
					responsive: true,
					plugins: { legend: { position: 'right', labels: { color: '#e2e8f0' } } }
				}
			});

			const q = data.kills_quartis;
			charts.quartis = new Chart(quartisCanvas, {
				type: 'line',
				data: {
					labels: ['Q1', 'Q2', 'Q3'],
					datasets: [{
						label: 'Total de Kills',
						data: [q.q1_total, q.q2_total, q.q3_total],
						borderColor: '#ec4899',
						backgroundColor: 'rgba(236, 72, 153, 0.1)',
						fill: true,
						tension: 0.4,
						pointBackgroundColor: '#ec4899',
						pointBorderColor: '#fff',
						pointRadius: 6
					}]
				},
				options: {
					responsive: true,
					plugins: { legend: { display: false } },
					scales: {
						y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(148, 163, 184, 0.1)' } },
						x: { ticks: { color: '#94a3b8' }, grid: { display: false } }
					}
				}
			});
		}
	});
</script>

{#if loading}
	<div class="flex items-center justify-center py-20">
		<div class="loading mr-3"></div>
		<span class="text-slate-400">Carregando dashboard...</span>
	</div>
{:else if data}
	<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
		<div class="glass rounded-2xl p-6">
			<h3 class="text-lg font-bold text-white mb-4">Kills por Time (Top 10)</h3>
			<canvas bind:this={killsTimeCanvas} height="250"></canvas>
		</div>
		<div class="glass rounded-2xl p-6">
			<h3 class="text-lg font-bold text-white mb-4">Top Jogadores - Total de Kills</h3>
			<canvas bind:this={topJogadoresCanvas} height="250"></canvas>
		</div>
		<div class="glass rounded-2xl p-6">
			<h3 class="text-lg font-bold text-white mb-4">Distribuição de Colocações Q1</h3>
			<canvas bind:this={posicoesCanvas} height="250"></canvas>
		</div>
		<div class="glass rounded-2xl p-6">
			<h3 class="text-lg font-bold text-white mb-4">Kills por Quartil (Média)</h3>
			<canvas bind:this={quartisCanvas} height="250"></canvas>
		</div>
	</div>
{/if}
