<script lang="ts">
	import { stats } from '$lib/stores';

	function exportSQL() {
		fetch('/api/export/sql')
			.then(r => r.text())
			.then(text => downloadFile(text, 'esports_export.sql', 'text/plain'));
	}

	function exportCSV() {
		fetch('/api/export/csv')
			.then(r => r.text())
			.then(text => downloadFile(text, 'esports_export.csv', 'text/csv'));
	}

	function downloadFile(content: string, filename: string, type: string) {
		const blob = new Blob([content], { type });
		const url = URL.createObjectURL(blob);
		const a = document.createElement('a');
		a.href = url; a.download = filename; a.click();
		URL.revokeObjectURL(url);
	}
</script>

<header class="glass-strong sticky top-0 z-50 border-b border-slate-700/50">
	<div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
		<div class="flex items-center gap-3">
			<div class="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/30">
				<i class="fas fa-gamepad text-white text-lg"></i>
			</div>
			<div>
				<h1 class="text-xl font-bold text-white glow-text">eSports Manager</h1>
				<p class="text-xs text-slate-400">SvelteKit Fullstack</p>
			</div>
		</div>
		<div class="flex items-center gap-3">
			<span class="api-status api-online"><i class="fas fa-circle text-xs mr-1"></i> Online</span>
			<button onclick={exportSQL} class="px-4 py-2 rounded-lg bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-600/30 transition-all text-sm font-medium flex items-center gap-2">
				<i class="fas fa-download"></i> SQL
			</button>
			<button onclick={exportCSV} class="px-4 py-2 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30 hover:bg-blue-600/30 transition-all text-sm font-medium flex items-center gap-2">
				<i class="fas fa-file-csv"></i> CSV
			</button>
		</div>
	</div>
</header>
