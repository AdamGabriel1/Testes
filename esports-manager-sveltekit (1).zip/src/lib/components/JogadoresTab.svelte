<script lang="ts">
	import { onMount } from 'svelte';
	import type { Jogador } from '$lib/types';
	import { toastMessage } from '$lib/stores';
	import Modal from './Modal.svelte';

	let data: Jogador[] = [];
	let loading = true;
	let search = '';
	let mesFilter = '';
	let timeFilter = '';
	let sortField: string | null = null;
	let sortAsc = true;
	let modalOpen = false;
	let editingId: number | null = null;
	let modalTitle = 'Novo Registro';
	let modalData: Record<string, unknown> | null = null;
	let meses: string[] = [];
	let times: string[] = [];
	let filterTimeout: ReturnType<typeof setTimeout>;
	let modalRef: Modal;

	onMount(() => loadData());

	async function loadData() {
		loading = true;
		const params = new URLSearchParams();
		if (search) params.set('search', search);
		if (mesFilter) params.set('mes', mesFilter);
		if (timeFilter) params.set('time', timeFilter);
		const res = await fetch(`/api/jogadores?${params}`);
		data = await res.json();
		meses = [...new Set(data.map(j => j.Mes))];
		times = [...new Set(data.map(j => j.Time))];
		loading = false;
	}

	function debouncedFilter() {
		clearTimeout(filterTimeout);
		filterTimeout = setTimeout(() => loadData(), 300);
	}

	function sortTable(field: string) {
		if (sortField === field) sortAsc = !sortAsc;
		else { sortField = field; sortAsc = true; }
	}

	let sortedData = $derived([...data].sort((a, b) => {
		if (!sortField) return 0;
		let va = a[sortField as keyof Jogador];
		let vb = b[sortField as keyof Jogador];
		if (typeof va === 'string') { va = va.toLowerCase(); vb = (vb as string).toLowerCase(); }
		return sortAsc ? (va > vb ? 1 : -1) : (va < vb ? 1 : -1);
	}));

	function openModal(id?: number) {
		editingId = id ?? null;
		modalTitle = id ? 'Editar Registro' : 'Novo Registro';
		if (id) {
			const item = data.find(j => j.id === id);
			modalData = item ? { ...item } : null;
		} else {
			modalData = null;
		}
		modalOpen = true;
		setTimeout(() => {
			if (modalRef) modalRef.setData(modalData);
		}, 0);
	}

	async function handleSubmit(event: CustomEvent<Record<string, unknown>>) {
		const payload = event.detail;
		try {
			if (editingId) {
				await fetch(`/api/jogadores/${editingId}`, {
					method: 'PUT',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify(payload)
				});
				toastMessage.set({ msg: 'Registro atualizado com sucesso!', type: 'success' });
			} else {
				await fetch('/api/jogadores', {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify(payload)
				});
				toastMessage.set({ msg: 'Registro criado com sucesso!', type: 'success' });
			}
			modalOpen = false;
			await loadData();
		} catch {
			toastMessage.set({ msg: 'Erro ao salvar registro', type: 'error' });
		}
	}

	async function deleteRecord(id: number) {
		if (!confirm('Tem certeza que deseja excluir este registro?')) return;
		try {
			await fetch(`/api/jogadores/${id}`, { method: 'DELETE' });
			toastMessage.set({ msg: 'Registro excluído com sucesso!', type: 'success' });
			await loadData();
		} catch {
			toastMessage.set({ msg: 'Erro ao excluir registro', type: 'error' });
		}
	}
</script>

<div class="glass rounded-2xl p-6">
	<div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
		<div>
			<h2 class="text-lg font-bold text-white">Estatísticas dos Jogadores</h2>
			<p class="text-sm text-slate-400">Gerencie kills e performance dos jogadores</p>
		</div>
		<button onclick={() => openModal()} class="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-semibold hover:shadow-lg hover:shadow-indigo-500/30 transition-all flex items-center gap-2">
			<i class="fas fa-plus"></i> Novo Jogador
		</button>
	</div>
	<div class="flex gap-3 mb-4 flex-wrap">
		<div class="relative flex-1 min-w-[200px]">
			<i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-500"></i>
			<input type="text" bind:value={search} oninput={debouncedFilter} placeholder="Buscar jogador, time..." class="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white placeholder-slate-500 input-glow outline-none transition-all">
		</div>
		<select bind:value={mesFilter} onchange={() => loadData()} class="px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow">
			<option value="">Todos os Meses</option>
			{#each meses as m}
				<option value={m}>{m}</option>
			{/each}
		</select>
		<select bind:value={timeFilter} onchange={() => loadData()} class="px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow">
			<option value="">Todos os Times</option>
			{#each times as t}
				<option value={t}>{t}</option>
			{/each}
		</select>
		<button onclick={loadData} class="px-3 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-slate-400 hover:text-white transition-all">
			<i class="fas fa-sync-alt"></i>
		</button>
	</div>
	<div class="overflow-x-auto rounded-xl border border-slate-700/50">
		<table class="w-full text-sm">
			<thead>
				<tr class="bg-slate-800/80 text-slate-300">
					<th class="px-4 py-3 text-left font-semibold cursor-pointer hover:text-white" onclick={() => sortTable('Mes')}>Mês <i class="fas fa-sort text-xs ml-1"></i></th>
					<th class="px-4 py-3 text-left font-semibold cursor-pointer hover:text-white" onclick={() => sortTable('Dia')}>Dia <i class="fas fa-sort text-xs ml-1"></i></th>
					<th class="px-4 py-3 text-left font-semibold cursor-pointer hover:text-white" onclick={() => sortTable('Time')}>Time <i class="fas fa-sort text-xs ml-1"></i></th>
					<th class="px-4 py-3 text-left font-semibold cursor-pointer hover:text-white" onclick={() => sortTable('Jogador')}>Jogador <i class="fas fa-sort text-xs ml-1"></i></th>
					<th class="px-4 py-3 text-center font-semibold">Q1 Kills</th>
					<th class="px-4 py-3 text-center font-semibold">Q2 Kills</th>
					<th class="px-4 py-3 text-center font-semibold">Q3 Kills</th>
					<th class="px-4 py-3 text-center font-semibold">Total</th>
					<th class="px-4 py-3 text-center font-semibold">Média</th>
					<th class="px-4 py-3 text-center font-semibold">Ações</th>
				</tr>
			</thead>
			<tbody class="divide-y divide-slate-700/50">
				{#if loading}
					<tr><td colspan="10" class="px-4 py-8 text-center text-slate-500"><div class="loading mr-2"></div> Carregando dados...</td></tr>
				{:else if sortedData.length === 0}
					<tr><td colspan="10" class="px-4 py-8 text-center text-slate-500">Nenhum registro encontrado</td></tr>
				{:else}
					{#each sortedData as j}
						{@const total = j.Q1_Kills + j.Q2_Kills + j.Q3_Kills}
						<tr class="row-hover transition-colors">
							<td class="px-4 py-3 text-slate-300">{j.Mes}</td>
							<td class="px-4 py-3 text-slate-300">{j.Dia}</td>
							<td class="px-4 py-3 text-white font-medium">{j.Time}</td>
							<td class="px-4 py-3 text-slate-200">{j.Jogador}</td>
							<td class="px-4 py-3 text-center text-slate-300">{j.Q1_Kills}</td>
							<td class="px-4 py-3 text-center text-slate-300">{j.Q2_Kills}</td>
							<td class="px-4 py-3 text-center text-slate-300">{j.Q3_Kills}</td>
							<td class="px-4 py-3 text-center text-white font-bold">{total}</td>
							<td class="px-4 py-3 text-center text-slate-400">{(total / 3).toFixed(1)}</td>
							<td class="px-4 py-3 text-center">
								<button onclick={() => openModal(j.id)} class="text-indigo-400 hover:text-indigo-300 mr-2 transition-colors"><i class="fas fa-edit"></i></button>
								<button onclick={() => deleteRecord(j.id)} class="text-rose-400 hover:text-rose-300 transition-colors"><i class="fas fa-trash"></i></button>
							</td>
						</tr>
					{/each}
				{/if}
			</tbody>
		</table>
	</div>
</div>

<Modal bind:open={modalOpen} title={modalTitle} type="jogadores" editingId={editingId} on:close={() => modalOpen = false} on:submit={handleSubmit} bind:this={modalRef} />
