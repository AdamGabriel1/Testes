<script lang="ts">
	import { onMount } from 'svelte';
	import type { Colocacao } from '$lib/types';
	import { toastMessage } from '$lib/stores';
	import Modal from './Modal.svelte';

	let data: Colocacao[] = [];
	let loading = true;
	let search = '';
	let mesFilter = '';
	let sortField: string | null = null;
	let sortAsc = true;
	let modalOpen = false;
	let editingId: number | null = null;
	let modalTitle = 'Novo Registro';
	let modalData: Record<string, unknown> | null = null;
	let meses: string[] = [];
	let filterTimeout: ReturnType<typeof setTimeout>;
	let modalRef: Modal;

	onMount(() => loadData());

	async function loadData() {
		loading = true;
		const params = new URLSearchParams();
		if (search) params.set('search', search);
		if (mesFilter) params.set('mes', mesFilter);
		const res = await fetch(`/api/colocacoes?${params}`);
		data = await res.json();
		meses = [...new Set(data.map(c => c.Mes))];
		loading = false;
	}

	function debouncedFilter() {
		clearTimeout(filterTimeout);
		filterTimeout = setTimeout(() => loadData(), 300);
	}

	function sortTable(field: string) {
		if (sortField === field) sortAsc = !sortAsc;
		else { sortField = field; sortAsc = true; }
	}

	let sortedData = $derived([...data].sort((a, b) => {
		if (!sortField) return 0;
		let va = a[sortField as keyof Colocacao];
		let vb = b[sortField as keyof Colocacao];
		if (typeof va === 'string') { va = va.toLowerCase(); vb = (vb as string).toLowerCase(); }
		return sortAsc ? (va > vb ? 1 : -1) : (va < vb ? 1 : -1);
	}));

	function openModal(id?: number) {
		editingId = id ?? null;
		modalTitle = id ? 'Editar Registro' : 'Novo Registro';
		if (id) {
			const item = data.find(c => c.id === id);
			modalData = item ? { ...item } : null;
		} else {
			modalData = null;
		}
		modalOpen = true;
		// Atualiza o modal após abrir
		setTimeout(() => {
			if (modalRef) modalRef.setData(modalData);
		}, 0);
	}

	async function handleSubmit(event: CustomEvent<Record<string, unknown>>) {
		const payload = event.detail;
		try {
			if (editingId) {
				await fetch(`/api/colocacoes/${editingId}`, {
					method: 'PUT',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify(payload)
				});
				toastMessage.set({ msg: 'Registro atualizado com sucesso!', type: 'success' });
			} else {
				await fetch('/api/colocacoes', {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify(payload)
				});
				toastMessage.set({ msg: 'Registro criado com sucesso!', type: 'success' });
			}
			modalOpen = false;
			await loadData();
		} catch {
			toastMessage.set({ msg: 'Erro ao salvar registro', type: 'error' });
		}
	}

	async function deleteRecord(id: number) {
		if (!confirm('Tem certeza que deseja excluir este registro?')) return;
		try {
			await fetch(`/api/colocacoes/${id}`, { method: 'DELETE' });
			toastMessage.set({ msg: 'Registro excluído com sucesso!', type: 'success' });
			await loadData();
		} catch {
			toastMessage.set({ msg: 'Erro ao excluir registro', type: 'error' });
		}
	}

	function posClass(pos: number) {
		if (pos === 1) return 'text-yellow-400 font-bold';
		if (pos <= 3) return 'text-emerald-400';
		return 'text-slate-400';
	}
</script>

<div class="glass rounded-2xl p-6">
	<div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
		<div>
			<h2 class="text-lg font-bold text-white">Colocações por Partida</h2>
			<p class="text-sm text-slate-400">Gerencie as posições dos times em cada quartil</p>
		</div>
		<button onclick={() => openModal()} class="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-semibold hover:shadow-lg hover:shadow-indigo-500/30 transition-all flex items-center gap-2">
			<i class="fas fa-plus"></i> Nova Colocação
		</button>
	</div>
	<div class="flex gap-3 mb-4">
		<div class="relative flex-1 max-w-xs">
			<i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-500"></i>
			<input type="text" bind:value={search} oninput={debouncedFilter} placeholder="Buscar time ou data..." class="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white placeholder-slate-500 input-glow outline-none transition-all">
		</div>
		<select bind:value={mesFilter} onchange={() => loadData()} class="px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow">
			<option value="">Todos os Meses</option>
			{#each meses as m}
				<option value={m}>{m}</option>
			{/each}
		</select>
		<button onclick={loadData} class="px-3 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-slate-400 hover:text-white transition-all">
			<i class="fas fa-sync-alt"></i>
		</button>
	</div>
	<div class="overflow-x-auto rounded-xl border border-slate-700/50">
		<table class="w-full text-sm">
			<thead>
				<tr class="bg-slate-800/80 text-slate-300">
					<th class="px-4 py-3 text-left font-semibold cursor-pointer hover:text-white" onclick={() => sortTable('Mes')}>Mês <i class="fas fa-sort text-xs ml-1"></i></th>
					<th class="px-4 py-3 text-left font-semibold cursor-pointer hover:text-white" onclick={() => sortTable('Dia')}>Dia <i class="fas fa-sort text-xs ml-1"></i></th>
					<th class="px-4 py-3 text-left font-semibold cursor-pointer hover:text-white" onclick={() => sortTable('Time')}>Time <i class="fas fa-sort text-xs ml-1"></i></th>
					<th class="px-4 py-3 text-center font-semibold">Q1 Pos</th>
					<th class="px-4 py-3 text-center font-semibold">Q2 Pos</th>
					<th class="px-4 py-3 text-center font-semibold">Q3 Pos</th>
					<th class="px-4 py-3 text-center font-semibold">Média</th>
					<th class="px-4 py-3 text-center font-semibold">Ações</th>
				</tr>
			</thead>
			<tbody class="divide-y divide-slate-700/50">
				{#if loading}
					<tr><td colspan="8" class="px-4 py-8 text-center text-slate-500"><div class="loading mr-2"></div> Carregando dados...</td></tr>
				{:else if sortedData.length === 0}
					<tr><td colspan="8" class="px-4 py-8 text-center text-slate-500">Nenhum registro encontrado</td></tr>
				{:else}
					{#each sortedData as c}
						<tr class="row-hover transition-colors">
							<td class="px-4 py-3 text-slate-300">{c.Mes}</td>
							<td class="px-4 py-3 text-slate-300">{c.Dia}</td>
							<td class="px-4 py-3 text-white font-medium">{c.Time}</td>
							<td class="px-4 py-3 text-center {posClass(c.Q1_Pos)}">{c.Q1_Pos}</td>
							<td class="px-4 py-3 text-center {posClass(c.Q2_Pos)}">{c.Q2_Pos}</td>
							<td class="px-4 py-3 text-center {posClass(c.Q3_Pos)}">{c.Q3_Pos}</td>
							<td class="px-4 py-3 text-center text-slate-300">{((c.Q1_Pos + c.Q2_Pos + c.Q3_Pos) / 3).toFixed(1)}</td>
							<td class="px-4 py-3 text-center">
								<button onclick={() => openModal(c.id)} class="text-indigo-400 hover:text-indigo-300 mr-2 transition-colors"><i class="fas fa-edit"></i></button>
								<button onclick={() => deleteRecord(c.id)} class="text-rose-400 hover:text-rose-300 transition-colors"><i class="fas fa-trash"></i></button>
							</td>
						</tr>
					{/each}
				{/if}
			</tbody>
		</table>
	</div>
</div>

<Modal bind:open={modalOpen} title={modalTitle} type="colocacoes" editingId={editingId} on:close={() => modalOpen = false} on:submit={handleSubmit} bind:this={modalRef} />
