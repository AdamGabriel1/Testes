export interface Colocacao {
	id: number;
	Mes: string;
	Dia: number;
	Time: string;
	Q1_Pos: number;
	Q2_Pos: number;
	Q3_Pos: number;
}

export interface Jogador {
	id: number;
	Mes: string;
	Dia: number;
	Time: string;
	Jogador: string;
	Q1_Kills: number;
	Q2_Kills: number;
	Q3_Kills: number;
}

export interface Stats {
	total_times: number;
	total_jogadores: number;
	total_partidas: number;
	total_kills: number;
}

export interface DashboardData {
	kills_por_time: { Time: string; total: number }[];
	top_jogadores: { Jogador: string; total: number }[];
	distribuicao_q1: { posicao: number; quantidade: number }[];
	kills_quartis: { q1_total: number; q2_total: number; q3_total: number };
}

export interface FilterParams {
	mes?: string;
	search?: string;
	time?: string;
}
