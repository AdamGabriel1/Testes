import { useState } from "react";
import { Link, useLocation } from "react-router";
import { useAppStore } from "@/stores/appStore";
import {
  LayoutDashboard,
  Users,
  Trophy,
  Calendar,
  BarChart3,
  Swords,
  Settings,
  Menu,
  X,
  Zap,
  Shield,
  ChevronDown,
  Bell,
  LogIn,
  LogOut,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";

const navItems = [
  { path: "/", label: "Dashboard", icon: LayoutDashboard },
  { path: "/organizations", label: "Organizacoes", icon: Shield },
  { path: "/players", label: "Jogadores", icon: Users },
  { path: "/events", label: "Eventos", icon: Calendar },
  { path: "/rankings", label: "Rankings", icon: BarChart3 },
  { path: "/brackets", label: "Chaveamento", icon: Swords },
  { path: "/admin", label: "Admin", icon: Settings },
];

const modeOptions = [
  { value: "all", label: "Todos", icon: Zap },
  { value: "xtrenio", label: "Xtrenios", icon: Zap },
  { value: "scrim", label: "Scrims", icon: Swords },
  { value: "campeonato", label: "Campeonatos", icon: Trophy },
  { value: "liga", label: "Ligas", icon: Shield },
  { value: "ranqueada", label: "Ranqueadas", icon: BarChart3 },
  { value: "torneio", label: "Torneios", icon: Calendar },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const { sidebarOpen, toggleSidebar, siteMode, setSiteMode } = useAppStore();
  const location = useLocation();
  const { user, logout } = useAuth();
  const [modeDropdownOpen, setModeDropdownOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const currentModeLabel = modeOptions.find(m => m.value === siteMode)?.label || "Todos";

  return (
    <div className="min-h-screen bg-[#050507] text-white flex">
      {/* Desktop Sidebar */}
      <aside
        className={cn(
          "fixed left-0 top-0 h-full z-40 bg-[#0A0A0F]/95 backdrop-blur-xl border-r border-white/5 transition-all duration-300 hidden lg:flex flex-col",
          sidebarOpen ? "w-64" : "w-20"
        )}
      >
        <div className="p-4 flex items-center justify-between">
          {sidebarOpen && (
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#00F0FF] to-[#BC13FE] flex items-center justify-center">
                <Zap className="w-5 h-5 text-[#050507]" />
              </div>
              <span className="font-bold text-lg tracking-tight">ESPORTS</span>
            </Link>
          )}
          <button
            onClick={toggleSidebar}
            className="p-2 rounded-lg hover:bg-white/5 transition-colors"
          >
            {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200",
                  isActive
                    ? "text-[#00F0FF] bg-[#00F0FF]/10 border border-[#00F0FF]/20"
                    : "text-[#8A8F98] hover:text-white hover:bg-white/5"
                )}
                title={!sidebarOpen ? item.label : undefined}
              >
                <item.icon className="w-5 h-5 flex-shrink-0" />
                {sidebarOpen && <span className="text-sm font-medium">{item.label}</span>}
              </Link>
            );
          })}
        </nav>

        {sidebarOpen && (
          <div className="p-4 border-t border-white/5">
            <div className="glass-panel p-3">
              <p className="text-xs text-[#8A8F98] mb-2">Modo do Sistema</p>
              <div className="relative">
                <button
                  onClick={() => setModeDropdownOpen(!modeDropdownOpen)}
                  className="w-full flex items-center justify-between px-3 py-2 bg-[#0A0A0F] border border-[#1A1A24] rounded-lg text-sm hover:border-[#00F0FF]/30 transition-colors"
                >
                  <span>{currentModeLabel}</span>
                  <ChevronDown className="w-4 h-4 text-[#8A8F98]" />
                </button>
                {modeDropdownOpen && (
                  <div className="absolute bottom-full left-0 right-0 mb-1 bg-[#0A0A0F] border border-[#1A1A24] rounded-lg overflow-hidden z-50">
                    {modeOptions.map((mode) => (
                      <button
                        key={mode.value}
                        onClick={() => {
                          setSiteMode(mode.value as any);
                          setModeDropdownOpen(false);
                        }}
                        className={cn(
                          "w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-white/5 transition-colors",
                          siteMode === mode.value ? "text-[#00F0FF]" : "text-[#8A8F98]"
                        )}
                      >
                        <mode.icon className="w-4 h-4" />
                        {mode.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        <div className="p-4 border-t border-white/5">
          {user ? (
            <div className="flex items-center gap-3">
              {user.avatar && (
                <img src={user.avatar} alt="" className="w-8 h-8 rounded-full" />
              )}
              {sidebarOpen && (
                <>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{user.name}</p>
                    <p className="text-xs text-[#8A8F98]">{user.role}</p>
                  </div>
                  <button onClick={logout} className="p-2 hover:bg-white/5 rounded-lg transition-colors">
                    <LogOut className="w-4 h-4 text-[#8A8F98]" />
                  </button>
                </>
              )}
            </div>
          ) : (
            <Link
              to="/login"
              className={cn(
                "flex items-center gap-2 text-[#8A8F98] hover:text-white transition-colors",
                !sidebarOpen && "justify-center"
              )}
            >
              <LogIn className="w-5 h-5" />
              {sidebarOpen && <span className="text-sm">Entrar</span>}
            </Link>
          )}
        </div>
      </aside>

      {/* Mobile Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-[#0A0A0F]/80 backdrop-blur-xl border-b border-white/5 lg:hidden">
        <div className="flex items-center justify-between px-4 py-3">
          <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="p-2">
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
          <Link to="/" className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-[#00F0FF] to-[#BC13FE] flex items-center justify-center">
              <Zap className="w-4 h-4 text-[#050507]" />
            </div>
            <span className="font-bold">ESPORTS</span>
          </Link>
          <button className="p-2 relative">
            <Bell className="w-5 h-5 text-[#8A8F98]" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-[#FF2E63] rounded-full" />
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <nav className="px-4 pb-4 space-y-1 border-t border-white/5">
            {navItems.map((item) => {
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setMobileMenuOpen(false)}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all",
                    isActive
                      ? "text-[#00F0FF] bg-[#00F0FF]/10 border border-[#00F0FF]/20"
                      : "text-[#8A8F98]"
                  )}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="text-sm font-medium">{item.label}</span>
                </Link>
              );
            })}
          </nav>
        )}
      </header>

      {/* Main Content */}
      <main
        className={cn(
          "flex-1 transition-all duration-300 min-h-screen",
          "lg:ml-64 pt-16 lg:pt-0",
          !sidebarOpen && "lg:ml-20"
        )}
      >
        {/* Desktop Header */}
        <header className="hidden lg:flex items-center justify-between px-8 py-4 border-b border-white/5">
          <div>
            <h1 className="text-xl font-bold">
              {navItems.find(n => n.path === location.pathname)?.label || "Dashboard"}
            </h1>
            <p className="text-sm text-[#8A8F98] mt-0.5">
              Sistema Profissional de eSports Mobile
            </p>
          </div>
          <div className="flex items-center gap-4">
            <button className="relative p-2 rounded-xl hover:bg-white/5 transition-colors">
              <Bell className="w-5 h-5 text-[#8A8F98]" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-[#FF2E63] rounded-full animate-pulse" />
            </button>
            {user ? (
              <div className="flex items-center gap-3 px-3 py-2 rounded-xl bg-white/5">
                {user.avatar && (
                  <img src={user.avatar} alt="" className="w-7 h-7 rounded-full" />
                )}
                <span className="text-sm font-medium">{user.name}</span>
              </div>
            ) : (
              <Link to="/login" className="btn-primary text-sm py-2 px-4">
                Entrar
              </Link>
            )}
          </div>
        </header>

        <div className="p-4 lg:p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
