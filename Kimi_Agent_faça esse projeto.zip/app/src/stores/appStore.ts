import { create } from "zustand";

export type SiteMode = "xtrenio" | "scrim" | "campeonato" | "liga" | "ranqueada" | "torneio" | "all";

interface AppState {
  siteMode: SiteMode;
  sidebarOpen: boolean;
  setSiteMode: (mode: SiteMode) => void;
  setSidebarOpen: (open: boolean) => void;
  toggleSidebar: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  siteMode: "all",
  sidebarOpen: true,
  setSiteMode: (mode) => set({ siteMode: mode }),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
}));
