import { useState } from "react";
import { trpc } from "@/providers/trpc";
import {
  Settings,
  Users,
  Shield,
  Calendar,
  Trophy,
  BarChart3,
  MessageSquare,
  Plus,
  Trash2,
  Edit,
} from "lucide-react";
import { motion } from "framer-motion";

const tabs = [
  { id: "events", label: "Eventos", icon: Calendar },
  { id: "organizations", label: "Organizacoes", icon: Shield },
  { id: "players", label: "Jogadores", icon: Users },
  { id: "templates", label: "Templates", icon: MessageSquare },
  { id: "stats", label: "Estatisticas", icon: BarChart3 },
];

export default function Admin() {
  const [activeTab, setActiveTab] = useState("events");


  const utils = trpc.useUtils();
  const { data: eventStats } = trpc.event.getStats.useQuery();
  const { data: orgStats } = trpc.organization.getStats.useQuery();
  const { data: dashboardStats } = trpc.dashboard.getStats.useQuery();
  const { data: eventsList } = trpc.event.list.useQuery({ limit: 50 });
  const { data: orgsList } = trpc.organization.list.useQuery({ limit: 50 });
  const { data: playersList } = trpc.player.list.useQuery({ limit: 50 });
  const { data: templatesList } = trpc.template.list.useQuery();

  const deleteEvent = trpc.event.delete.useMutation({
    onSuccess: () => {
      utils.event.list.invalidate();
      utils.event.getStats.invalidate();
    },
  });

  const deleteOrg = trpc.organization.delete.useMutation({
    onSuccess: () => {
      utils.organization.list.invalidate();
    },
  });

  const deletePlayer = trpc.player.delete.useMutation({
    onSuccess: () => {
      utils.player.list.invalidate();
    },
  });

  const deleteTemplate = trpc.template.delete.useMutation({
    onSuccess: () => {
      utils.template.list.invalidate();
    },
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Settings className="w-6 h-6 text-[#00F0FF]" />
          Painel Administrativo
        </h1>
        <p className="text-sm text-[#8A8F98] mt-1">Gerenciamento completo do sistema</p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Eventos", value: dashboardStats?.events || 0, icon: Calendar, color: "#00F0FF" },
          { label: "Organizacoes", value: dashboardStats?.organizations || 0, icon: Shield, color: "#BC13FE" },
          { label: "Jogadores", value: dashboardStats?.players || 0, icon: Users, color: "#00FF94" },
          { label: "Ao Vivo", value: dashboardStats?.liveEvents || 0, icon: Trophy, color: "#FF2E63" },
        ].map((stat) => (
          <div key={stat.label} className="stat-card">
            <div className="flex items-center gap-2 mb-2">
              <stat.icon className="w-5 h-5" style={{ color: stat.color }} />
              <span className="text-sm text-[#8A8F98]">{stat.label}</span>
            </div>
            <p className="text-2xl font-bold font-mono">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto scrollbar-custom pb-1">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              "flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-medium whitespace-nowrap transition-all",
              activeTab === tab.id
                ? "bg-[#00F0FF]/10 text-[#00F0FF] border border-[#00F0FF]/30"
                : "bg-white/5 text-[#8A8F98] border border-transparent hover:bg-white/10"
            )}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Events Tab */}
      {activeTab === "events" && (
        <div className="glass-panel overflow-hidden">
          <div className="p-4 border-b border-white/5 flex items-center justify-between">
            <h2 className="font-semibold">Gerenciar Eventos</h2>
            <button className="btn-primary text-sm py-2 px-4 flex items-center gap-2">
              <Plus className="w-4 h-4" /> Criar Evento
            </button>
          </div>
          <div className="overflow-x-auto scrollbar-custom">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/5">
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8A8F98]">Nome</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8A8F98] hidden sm:table-cell">Tipo</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8A8F98] hidden md:table-cell">Status</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8A8F98] hidden lg:table-cell">Data</th>
                  <th className="text-right px-4 py-3 text-xs font-medium text-[#8A8F98]">Acoes</th>
                </tr>
              </thead>
              <tbody>
                {(eventsList || []).map((event) => (
                  <tr key={event.id} className="border-b border-white/[0.02] hover:bg-white/[0.02]">
                    <td className="px-4 py-3 text-sm font-medium">{event.name}</td>
                    <td className="px-4 py-3 text-sm text-[#8A8F98] capitalize hidden sm:table-cell">{event.type}</td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      <span className={cn(
                        "text-xs px-2 py-1 rounded-full capitalize",
                        event.status === "live" ? "bg-[#FF2E63]/10 text-[#FF2E63]" :
                        event.status === "upcoming" ? "bg-[#00F0FF]/10 text-[#00F0FF]" :
                        "bg-white/5 text-[#8A8F98]"
                      )}>
                        {event.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-[#8A8F98] hidden lg:table-cell">
                      {event.date ? new Date(event.date).toLocaleDateString("pt-BR") : "N/A"}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button className="p-1.5 rounded-lg hover:bg-white/5 text-[#8A8F98] hover:text-[#00F0FF] transition-colors">
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => deleteEvent.mutate({ id: event.id })}
                          className="p-1.5 rounded-lg hover:bg-white/5 text-[#8A8F98] hover:text-[#FF2E63] transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Organizations Tab */}
      {activeTab === "organizations" && (
        <div className="glass-panel overflow-hidden">
          <div className="p-4 border-b border-white/5 flex items-center justify-between">
            <h2 className="font-semibold">Gerenciar Organizacoes</h2>
          </div>
          <div className="overflow-x-auto scrollbar-custom">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/5">
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8A8F98]">Nome</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8A8F98]">Tag</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8A8F98] hidden sm:table-cell">Pais</th>
                  <th className="text-right px-4 py-3 text-xs font-medium text-[#8A8F98]">Pontos</th>
                  <th className="text-right px-4 py-3 text-xs font-medium text-[#8A8F98]">Acoes</th>
                </tr>
              </thead>
              <tbody>
                {(orgsList || []).map((org) => (
                  <tr key={org.id} className="border-b border-white/[0.02] hover:bg-white/[0.02]">
                    <td className="px-4 py-3 text-sm font-medium">{org.name}</td>
                    <td className="px-4 py-3 text-sm font-mono text-[#00F0FF]">{org.tag}</td>
                    <td className="px-4 py-3 text-sm text-[#8A8F98] hidden sm:table-cell">{org.country}</td>
                    <td className="px-4 py-3 text-right text-sm font-mono">{org.rankingPoints}</td>
                    <td className="px-4 py-3 text-right">
                      <button
                        onClick={() => deleteOrg.mutate({ id: org.id })}
                        className="p-1.5 rounded-lg hover:bg-white/5 text-[#8A8F98] hover:text-[#FF2E63] transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Players Tab */}
      {activeTab === "players" && (
        <div className="glass-panel overflow-hidden">
          <div className="p-4 border-b border-white/5">
            <h2 className="font-semibold">Gerenciar Jogadores</h2>
          </div>
          <div className="overflow-x-auto scrollbar-custom">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/5">
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8A8F98]">Nickname</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8A8F98] hidden sm:table-cell">ID</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8A8F98] hidden md:table-cell">Pais</th>
                  <th className="text-right px-4 py-3 text-xs font-medium text-[#8A8F98]">Kills</th>
                  <th className="text-right px-4 py-3 text-xs font-medium text-[#8A8F98]">Pts</th>
                  <th className="text-right px-4 py-3 text-xs font-medium text-[#8A8F98]">Acoes</th>
                </tr>
              </thead>
              <tbody>
                {(playersList || []).map((player) => (
                  <tr key={player.id} className="border-b border-white/[0.02] hover:bg-white/[0.02]">
                    <td className="px-4 py-3 text-sm font-medium flex items-center gap-2">
                      {player.nickname}
                      {player.isBanned && (
                        <span className="text-xs px-1.5 py-0.5 rounded bg-[#FF2E63]/10 text-[#FF2E63]">BAN</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-sm font-mono text-[#8A8F98] hidden sm:table-cell">{player.gameId}</td>
                    <td className="px-4 py-3 text-sm text-[#8A8F98] hidden md:table-cell">{player.country}</td>
                    <td className="px-4 py-3 text-right text-sm font-mono text-[#00FF94]">{player.kills}</td>
                    <td className="px-4 py-3 text-right text-sm font-mono">{player.rankingPoints}</td>
                    <td className="px-4 py-3 text-right">
                      <button
                        onClick={() => deletePlayer.mutate({ id: player.id })}
                        className="p-1.5 rounded-lg hover:bg-white/5 text-[#8A8F98] hover:text-[#FF2E63] transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Templates Tab */}
      {activeTab === "templates" && (
        <div className="glass-panel overflow-hidden">
          <div className="p-4 border-b border-white/5">
            <h2 className="font-semibold">Gerenciar Templates WhatsApp</h2>
          </div>
          <div className="divide-y divide-white/5">
            {(templatesList || []).map((template) => (
              <div key={template.id} className="p-4 hover:bg-white/[0.02] transition-colors">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-medium">{template.name}</h3>
                      {template.isDefault && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-[#00F0FF]/10 text-[#00F0FF]">
                          Padrao
                        </span>
                      )}
                    </div>
                    <pre className="text-xs text-[#8A8F98] whitespace-pre-wrap font-mono bg-[#0A0A0F] p-3 rounded-lg">
                      {template.content?.slice(0, 200)}...
                    </pre>
                  </div>
                  <button
                    onClick={() => deleteTemplate.mutate({ id: template.id })}
                    className="p-1.5 rounded-lg hover:bg-white/5 text-[#8A8F98] hover:text-[#FF2E63] transition-colors ml-4"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Stats Tab */}
      {activeTab === "stats" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="glass-panel p-6">
            <h2 className="font-semibold mb-4">Eventos</h2>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-[#8A8F98]">Total</span>
                <span className="text-sm font-mono">{eventStats?.total || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-[#8A8F98]">Proximos</span>
                <span className="text-sm font-mono text-[#00F0FF]">{eventStats?.upcoming || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-[#8A8F98]">Ao Vivo</span>
                <span className="text-sm font-mono text-[#FF2E63]">{eventStats?.live || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-[#8A8F98]">Concluidos</span>
                <span className="text-sm font-mono text-[#00FF94]">{eventStats?.finished || 0}</span>
              </div>
            </div>
          </div>

          <div className="glass-panel p-6">
            <h2 className="font-semibold mb-4">Organizacoes</h2>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-[#8A8F98]">Total</span>
                <span className="text-sm font-mono">{orgStats?.total || 0}</span>
              </div>
              {orgStats?.topOrg && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-[#8A8F98]">Top Organizacao</span>
                  <span className="text-sm font-medium text-[#FFD700]">{orgStats.topOrg.name}</span>
                </div>
              )}
            </div>
          </div>

          <div className="glass-panel p-6 md:col-span-2">
            <h2 className="font-semibold mb-4">Sistema</h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {[
                { label: "Jogadores", value: dashboardStats?.players || 0 },
                { label: "Equipes", value: dashboardStats?.organizations || 0 },
                { label: "Eventos", value: dashboardStats?.events || 0 },
                { label: "Partidas", value: dashboardStats?.matches || 0 },
              ].map((s) => (
                <div key={s.label} className="text-center p-3 rounded-xl bg-white/[0.02]">
                  <p className="text-2xl font-bold font-mono text-[#00F0FF]">{s.value}</p>
                  <p className="text-xs text-[#8A8F98] mt-1">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
}

function cn(...classes: (string | undefined | false)[]) {
  return classes.filter(Boolean).join(" ");
}
