import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAppStore } from "@/stores/appStore";
import { Calendar, Search, ArrowRight, Zap, Swords, Trophy, Shield, BarChart3, Radio } from "lucide-react";
import { Link } from "react-router";
import { motion } from "framer-motion";

const typeIcons: Record<string, React.ElementType> = {
  xtrenio: Zap,
  scrim: Swords,
  campeonato: Trophy,
  liga: Shield,
  ranqueada: BarChart3,
  torneio: Calendar,
};

const typeColors: Record<string, string> = {
  xtrenio: "#00F0FF",
  scrim: "#00FF94",
  campeonato: "#FFD700",
  liga: "#BC13FE",
  ranqueada: "#FF2E63",
  torneio: "#00F0FF",
};

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.08 } }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4 } }
};

export default function Events() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const { siteMode } = useAppStore();
  
  const { data: events, isLoading } = trpc.event.list.useQuery({
    ...(siteMode !== "all" ? { type: siteMode } : {}),
    limit: 50,
  });

  const filteredEvents = (events || []).filter(e => {
    if (statusFilter !== "all" && e.status !== statusFilter) return false;
    if (search && !e.name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <motion.div
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-6"
    >
      <motion.div variants={item} className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Eventos</h1>
          <p className="text-sm text-[#8A8F98] mt-1">
            {siteMode === "all" ? "Todos os eventos" : `Filtrado por: ${siteMode}`}
          </p>
        </div>
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8A8F98]" />
            <input
              type="text"
              placeholder="Buscar evento..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="input-dark w-full pl-10"
            />
          </div>
        </div>
      </motion.div>

      {/* Status Filter */}
      <motion.div variants={item} className="flex items-center gap-2 flex-wrap">
        {[
          { value: "all", label: "Todos" },
          { value: "upcoming", label: "Proximos" },
          { value: "live", label: "Ao Vivo" },
          { value: "finished", label: "Concluidos" },
        ].map((filter) => (
          <button
            key={filter.value}
            onClick={() => setStatusFilter(filter.value)}
            className={cn(
              "px-4 py-2 rounded-full text-sm font-medium transition-all",
              statusFilter === filter.value
                ? "bg-[#00F0FF]/10 text-[#00F0FF] border border-[#00F0FF]/30"
                : "bg-white/5 text-[#8A8F98] border border-transparent hover:bg-white/10"
            )}
          >
            {filter.label}
          </button>
        ))}
      </motion.div>

      {isLoading && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="glass-panel p-6 animate-pulse">
              <div className="h-4 bg-white/10 rounded w-1/2 mb-3" />
              <div className="h-3 bg-white/10 rounded w-3/4" />
            </div>
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredEvents.map((event) => {
          const Icon = typeIcons[event.type] || Calendar;
          const color = typeColors[event.type] || "#00F0FF";
          
          return (
            <motion.div key={event.id} variants={item}>
              <Link
                to={`/events/${event.id}`}
                className="glass-panel-hover p-5 block group"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: `${color}15` }}
                    >
                      <Icon className="w-5 h-5" style={{ color }} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold group-hover:text-[#00F0FF] transition-colors">{event.name}</h3>
                        {event.status === "live" && (
                          <span className="flex items-center gap-1 text-xs text-[#FF2E63]">
                            <Radio className="w-3 h-3 animate-pulse" /> AO VIVO
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-[#8A8F98] capitalize">{event.type} • {event.mode}</p>
                    </div>
                  </div>
                  <ArrowRight className="w-5 h-5 text-[#8A8F98] group-hover:text-[#00F0FF] group-hover:translate-x-1 transition-all" />
                </div>

                <p className="text-sm text-[#8A8F98] line-clamp-2 mb-3">{event.description}</p>

                <div className="flex items-center gap-4 text-xs text-[#8A8F98] pt-3 border-t border-white/5">
                  <span>
                    {event.date ? new Date(event.date).toLocaleDateString("pt-BR") : ""}
                  </span>
                  <span>{event.timeBr} (BR)</span>
                  <span className="capitalize">{event.format?.replace("_", " ")}</span>
                  <span className={event.registrationOpen ? "text-[#00FF94]" : "text-[#FF2E63]"}>
                    {event.registrationOpen ? "Inscricoes abertas" : "Inscricoes fechadas"}
                  </span>
                </div>
              </Link>
            </motion.div>
          );
        })}
      </div>

      {filteredEvents.length === 0 && !isLoading && (
        <div className="glass-panel p-12 text-center">
          <Calendar className="w-12 h-12 text-[#8A8F98] mx-auto mb-3" />
          <p className="text-[#8A8F98]">Nenhum evento encontrado</p>
        </div>
      )}
    </motion.div>
  );
}

function cn(...classes: (string | undefined | false)[]) {
  return classes.filter(Boolean).join(" ");
}
