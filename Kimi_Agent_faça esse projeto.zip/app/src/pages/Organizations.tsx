import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Search, MapPin, Trophy, Users, ArrowRight } from "lucide-react";
import { Link } from "react-router";
import { motion } from "framer-motion";

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.05 } }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.3 } }
};

export default function Organizations() {
  const [search, setSearch] = useState("");
  const { data: orgs, isLoading } = trpc.organization.list.useQuery(
    search ? { search, limit: 50 } : { limit: 50 }
  );

  return (
    <motion.div
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-6"
    >
      <motion.div variants={item} className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Organizacoes</h1>
          <p className="text-sm text-[#8A8F98] mt-1">{orgs?.length || 0} organizacoes registradas</p>
        </div>
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8A8F98]" />
          <input
            type="text"
            placeholder="Buscar organizacao..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="input-dark w-full pl-10"
          />
        </div>
      </motion.div>

      {isLoading && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="glass-panel p-6 animate-pulse">
              <div className="h-4 bg-white/10 rounded w-1/2 mb-3" />
              <div className="h-3 bg-white/10 rounded w-3/4" />
            </div>
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {(orgs || []).map((org) => (
          <motion.div key={org.id} variants={item}>
            <Link
              to={`/organizations/${org.id}`}
              className="glass-panel-hover p-6 block group"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#00F0FF]/20 to-[#BC13FE]/20 flex items-center justify-center text-lg font-bold text-[#00F0FF]">
                    {org.tag}
                  </div>
                  <div>
                    <h3 className="font-semibold group-hover:text-[#00F0FF] transition-colors">{org.name}</h3>
                    <div className="flex items-center gap-1 text-xs text-[#8A8F98]">
                      <MapPin className="w-3 h-3" />
                      {org.country}
                    </div>
                  </div>
                </div>
                <ArrowRight className="w-5 h-5 text-[#8A8F98] group-hover:text-[#00F0FF] group-hover:translate-x-1 transition-all" />
              </div>

              <div className="grid grid-cols-3 gap-3 pt-4 border-t border-white/5">
                <div className="text-center">
                  <p className="text-lg font-bold font-mono text-[#00F0FF]">{org.rankingPoints}</p>
                  <p className="text-xs text-[#8A8F98]">Pts</p>
                </div>
                <div className="text-center">
                  <p className="text-lg font-bold font-mono text-[#00FF94]">{org.wins}</p>
                  <p className="text-xs text-[#8A8F98]">Wins</p>
                </div>
                <div className="text-center">
                  <p className="text-lg font-bold font-mono text-[#FF2E63]">{org.kills}</p>
                  <p className="text-xs text-[#8A8F98]">Kills</p>
                </div>
              </div>

              <div className="flex items-center gap-4 mt-4 text-xs text-[#8A8F98]">
                <span className="flex items-center gap-1">
                  <Trophy className="w-3 h-3" />
                  {org.matchesPlayed} partidas
                </span>
                <span className="flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  Cap: {org.captain}
                </span>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
