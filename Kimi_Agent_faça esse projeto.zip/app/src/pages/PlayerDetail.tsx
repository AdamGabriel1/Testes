import { useParams, useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { ArrowLeft, Users, Crosshair, Trophy, Star, TrendingUp, Ban, Shield } from "lucide-react";
import { motion } from "framer-motion";

export default function PlayerDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const playerId = Number(id);
  
  const { data: player } = trpc.player.getById.useQuery({ id: playerId });

  if (!player) {
    return (
      <div className="glass-panel p-12 text-center">
        <div className="animate-spin w-8 h-8 border-2 border-[#00F0FF] border-t-transparent rounded-full mx-auto mb-3" />
        <p className="text-[#8A8F98]">Carregando jogador...</p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="flex items-center gap-4">
        <button
          onClick={() => navigate("/players")}
          className="p-2 rounded-xl hover:bg-white/5 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#00F0FF]/20 to-[#BC13FE]/20 flex items-center justify-center">
            <Users className="w-8 h-8 text-[#00F0FF]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold">{player.nickname}</h1>
              {player.isBanned && (
                <span className="flex items-center gap-1 text-xs px-2 py-1 rounded-full bg-[#FF2E63]/10 text-[#FF2E63]">
                  <Ban className="w-3 h-3" /> BANIDO
                </span>
              )}
            </div>
            <div className="flex items-center gap-3 mt-1">
              {player.organization && (
                <span className="text-sm text-[#00F0FF] flex items-center gap-1">
                  <Shield className="w-3 h-3" /> {player.organization.name}
                </span>
              )}
              <span className="text-sm text-[#8A8F98]">{player.country}</span>
              <span className="text-sm text-[#8A8F98] capitalize">{player.role}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Pontos", value: player.rankingPoints, icon: Trophy, color: "#00F0FF" },
          { label: "Kills", value: player.kills, icon: Crosshair, color: "#00FF94" },
          { label: "MVPs", value: player.mvps, icon: Star, color: "#FFD700" },
          { label: "Win Rate", value: `${player.winRate}%`, icon: TrendingUp, color: "#BC13FE" },
        ].map((stat) => (
          <div key={stat.label} className="stat-card">
            <div className="flex items-center gap-2 mb-2">
              <stat.icon className="w-4 h-4" style={{ color: stat.color }} />
              <span className="text-xs text-[#8A8F98]">{stat.label}</span>
            </div>
            <p className="text-xl font-bold font-mono">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Match Stats */}
        <div className="glass-panel p-6">
          <h2 className="text-lg font-semibold mb-4">Estatisticas de Partidas</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02]">
              <span className="text-sm text-[#8A8F98]">Partidas Jogadas</span>
              <span className="text-sm font-mono font-semibold">{player.matchesPlayed}</span>
            </div>
            <div className="flex items-center justify-between p-3 rounded-xl bg-[#00FF94]/5">
              <span className="text-sm text-[#00FF94]">Vitorias</span>
              <span className="text-sm font-mono font-semibold text-[#00FF94]">{player.wins}</span>
            </div>
            <div className="flex items-center justify-between p-3 rounded-xl bg-[#FF2E63]/5">
              <span className="text-sm text-[#FF2E63]">Derrotas</span>
              <span className="text-sm font-mono font-semibold text-[#FF2E63]">{player.losses}</span>
            </div>
            <div className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02]">
              <span className="text-sm text-[#8A8F98]">Penalizacoes</span>
              <span className="text-sm font-mono font-semibold">{player.penalizations}</span>
            </div>
          </div>
        </div>

        {/* Info */}
        <div className="glass-panel p-6">
          <h2 className="text-lg font-semibold mb-4">Informacoes</h2>
          <div className="space-y-4">
            {player.gameId && (
              <div className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02]">
                <span className="text-sm text-[#8A8F98]">ID do Jogo</span>
                <span className="text-sm font-mono">{player.gameId}</span>
              </div>
            )}
            {player.uid && (
              <div className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02]">
                <span className="text-sm text-[#8A8F98]">UID</span>
                <span className="text-sm font-mono">{player.uid}</span>
              </div>
            )}
            {player.discord && (
              <div className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02]">
                <span className="text-sm text-[#8A8F98]">Discord</span>
                <span className="text-sm font-mono">{player.discord}</span>
              </div>
            )}
            <div className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02]">
              <span className="text-sm text-[#8A8F98]">Pais</span>
              <span className="text-sm">{player.country}</span>
            </div>
            <div className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02]">
              <span className="text-sm text-[#8A8F98]">Funcao</span>
              <span className="text-sm capitalize">{player.role}</span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
