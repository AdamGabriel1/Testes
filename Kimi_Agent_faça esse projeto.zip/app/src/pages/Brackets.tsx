import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Swords, Trophy, Radio } from "lucide-react";
import { motion } from "framer-motion";

export default function Brackets() {
  const [selectedEvent, setSelectedEvent] = useState<number | null>(null);
  const { data: liveEvents } = trpc.event.list.useQuery({ status: "live", limit: 10 });
  const { data: upcomingEvents } = trpc.event.list.useQuery({ status: "upcoming", limit: 10 });

  const events = [...(liveEvents || []), ...(upcomingEvents || [])].filter(
    e => e.format === "mata_mata" || e.format === "chaveamento" || e.format === "eliminacao_simples" || e.format === "eliminacao_dupla"
  );

  events.find(e => e.id === selectedEvent);

  // Demo bracket data
  const generateDemoBracket = () => {
    const rounds = [
      {
        round: 1,
        matches: [
          { id: 1, teamA: "Red Devils", teamB: "Ghost Legion", scoreA: 2, scoreB: 0, winner: "A" },
          { id: 2, teamA: "Underground", teamB: "Phoenix Rising", scoreA: 2, scoreB: 1, winner: "A" },
          { id: 3, teamA: "DML", teamB: "Neon Tigers", scoreA: 2, scoreB: 0, winner: "A" },
          { id: 4, teamA: "Red Magic BR", teamB: "Shadow Squad", scoreA: 1, scoreB: 2, winner: "B" },
        ]
      },
      {
        round: 2,
        matches: [
          { id: 5, teamA: "Red Devils", teamB: "Underground", scoreA: 2, scoreB: 1, winner: "A" },
          { id: 6, teamA: "DML", teamB: "Shadow Squad", scoreA: 2, scoreB: 0, winner: "A" },
        ]
      },
      {
        round: 3,
        matches: [
          { id: 7, teamA: "Red Devils", teamB: "DML", scoreA: 1, scoreB: 2, winner: "B" },
        ]
      }
    ];
    return rounds;
  };

  const bracket = generateDemoBracket();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div>
        <h1 className="text-2xl font-bold">Chaveamento</h1>
        <p className="text-sm text-[#8A8F98] mt-1">Visualizacao de brackets de torneios</p>
      </div>

      {/* Event Selector */}
      <div className="glass-panel p-4">
        <p className="text-sm text-[#8A8F98] mb-3">Selecione um evento:</p>
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-custom pb-1">
          {events.length === 0 && (
            <p className="text-sm text-[#8A8F98]">Nenhum evento com chaveamento disponivel</p>
          )}
          {events.map((event) => (
            <button
              key={event.id}
              onClick={() => setSelectedEvent(event.id)}
              className={cn(
                "flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-all",
                selectedEvent === event.id
                  ? "bg-[#00F0FF]/10 text-[#00F0FF] border border-[#00F0FF]/30"
                  : "bg-white/5 text-[#8A8F98] hover:bg-white/10"
              )}
            >
              {event.status === "live" && <Radio className="w-3 h-3 text-[#FF2E63] animate-pulse" />}
              <Swords className="w-4 h-4" />
              {event.name}
            </button>
          ))}
          <button
            onClick={() => setSelectedEvent(0)}
            className={cn(
              "flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-all",
              selectedEvent === 0 || selectedEvent === null
                ? "bg-[#00F0FF]/10 text-[#00F0FF] border border-[#00F0FF]/30"
                : "bg-white/5 text-[#8A8F98] hover:bg-white/10"
            )}
          >
            <Trophy className="w-4 h-4" />
            Demo
          </button>
        </div>
      </div>

      {/* Bracket Display */}
      <div className="glass-panel p-6 overflow-x-auto">
        <div className="flex items-start gap-8 min-w-max">
          {bracket.map((round) => (
            <div key={round.round} className="flex flex-col gap-4">
              <h3 className="text-sm font-semibold text-[#8A8F98] text-center">
                {round.round === bracket.length ? "Final" : `Rodada ${round.round}`}
              </h3>
              <div className="flex flex-col gap-4 justify-around h-full">
                {round.matches.map((match) => (
                  <div
                    key={match.id}
                    className="w-56 bg-[#0A0A0F] border border-[#1A1A24] rounded-xl overflow-hidden hover:border-[#00F0FF]/30 transition-all"
                  >
                    <div className={cn(
                      "flex items-center justify-between px-3 py-2",
                      match.winner === "A" && "bg-[#00FF94]/5"
                    )}>
                      <span className={cn(
                        "text-sm font-medium",
                        match.winner === "A" ? "text-[#00FF94]" : "text-white"
                      )}>
                        {match.teamA}
                      </span>
                      <span className={cn(
                        "text-sm font-mono font-bold",
                        match.winner === "A" ? "text-[#00FF94]" : "text-[#8A8F98]"
                      )}>
                        {match.scoreA}
                      </span>
                    </div>
                    <div className="h-px bg-[#1A1A24]" />
                    <div className={cn(
                      "flex items-center justify-between px-3 py-2",
                      match.winner === "B" && "bg-[#00FF94]/5"
                    )}>
                      <span className={cn(
                        "text-sm font-medium",
                        match.winner === "B" ? "text-[#00FF94]" : "text-white"
                      )}>
                        {match.teamB}
                      </span>
                      <span className={cn(
                        "text-sm font-mono font-bold",
                        match.winner === "B" ? "text-[#00FF94]" : "text-[#8A8F98]"
                      )}>
                        {match.scoreB}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}

          {/* Champion */}
          <div className="flex flex-col gap-4 items-center justify-center">
            <h3 className="text-sm font-semibold text-[#FFD700]">Campeao</h3>
            <div className="w-56 glass-panel p-4 text-center border-[#FFD700]/30 shadow-[0_0_20px_rgba(255,215,0,0.1)]">
              <Trophy className="w-8 h-8 text-[#FFD700] mx-auto mb-2" />
              <p className="font-semibold text-[#FFD700]">DML</p>
              <p className="text-xs text-[#8A8F98] mt-1">Devils Mobile League</p>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function cn(...classes: (string | undefined | false)[]) {
  return classes.filter(Boolean).join(" ");
}
