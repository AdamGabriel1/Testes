import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Users, Search, Ban } from "lucide-react";
import { Link } from "react-router";
import { motion } from "framer-motion";

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.03 } }
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0, transition: { duration: 0.3 } }
};

export default function Players() {
  const [search, setSearch] = useState("");
  const { data: players, isLoading } = trpc.player.list.useQuery(
    search ? { search, limit: 50 } : { limit: 50 }
  );

  return (
    <motion.div
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-6"
    >
      <motion.div variants={item} className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Jogadores</h1>
          <p className="text-sm text-[#8A8F98] mt-1">{players?.length || 0} jogadores registrados</p>
        </div>
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8A8F98]" />
          <input
            type="text"
            placeholder="Buscar jogador..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="input-dark w-full pl-10"
          />
        </div>
      </motion.div>

      {isLoading && (
        <div className="glass-panel p-8 text-center">
          <div className="animate-spin w-8 h-8 border-2 border-[#00F0FF] border-t-transparent rounded-full mx-auto mb-3" />
          <p className="text-[#8A8F98]">Carregando jogadores...</p>
        </div>
      )}

      <motion.div variants={item} className="glass-panel overflow-hidden">
        <div className="overflow-x-auto scrollbar-custom">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/5">
                <th className="text-left px-4 py-3 text-xs font-medium text-[#8A8F98] uppercase">Rank</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-[#8A8F98] uppercase">Jogador</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-[#8A8F98] uppercase hidden sm:table-cell">Pais</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-[#8A8F98] uppercase hidden md:table-cell">Role</th>
                <th className="text-right px-4 py-3 text-xs font-medium text-[#8A8F98] uppercase">Kills</th>
                <th className="text-right px-4 py-3 text-xs font-medium text-[#8A8F98] uppercase hidden sm:table-cell">Win Rate</th>
                <th className="text-right px-4 py-3 text-xs font-medium text-[#8A8F98] uppercase">Pts</th>
              </tr>
            </thead>
            <tbody>
              {(players || []).map((player, idx) => (
                <tr
                  key={player.id}
                  className="border-b border-white/[0.02] hover:bg-white/[0.02] transition-colors"
                >
                  <td className="px-4 py-3">
                    <span className={cn(
                      "w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold font-mono",
                      idx === 0 ? "bg-[#FFD700]/20 text-[#FFD700]" :
                      idx === 1 ? "bg-[#C0C0C0]/20 text-[#C0C0C0]" :
                      idx === 2 ? "bg-[#CD7F32]/20 text-[#CD7F32]" :
                      "text-[#8A8F98]"
                    )}>
                      {idx + 1}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#00F0FF]/20 to-[#BC13FE]/20 flex items-center justify-center">
                        <Users className="w-4 h-4 text-[#00F0FF]" />
                      </div>
                      <div>
                        <Link
                          to={`/players/${player.id}`}
                          className="text-sm font-medium hover:text-[#00F0FF] transition-colors flex items-center gap-1"
                        >
                          {player.nickname}
                          {player.isBanned && <Ban className="w-3 h-3 text-[#FF2E63]" />}
                        </Link>
                        {player.gameId && (
                          <p className="text-xs text-[#8A8F98] font-mono">ID: {player.gameId}</p>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 hidden sm:table-cell">
                    <span className="text-sm text-[#8A8F98]">{player.country}</span>
                  </td>
                  <td className="px-4 py-3 hidden md:table-cell">
                    <span className="text-xs px-2 py-1 rounded-full bg-white/5 text-[#8A8F98] capitalize">
                      {player.role}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <span className="text-sm font-mono text-[#00FF94]">{player.kills}</span>
                  </td>
                  <td className="px-4 py-3 text-right hidden sm:table-cell">
                    <span className="text-sm font-mono">{player.winRate}%</span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <span className="text-sm font-mono font-semibold text-[#00F0FF]">{player.rankingPoints}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </motion.div>
  );
}

function cn(...classes: (string | undefined | false)[]) {
  return classes.filter(Boolean).join(" ");
}
