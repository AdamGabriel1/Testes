import { useState } from "react";
import { trpc } from "@/providers/trpc";
import {
  Trophy,
  Crosshair,
  Star,
  TrendingUp,
  Users,
  Shield,
} from "lucide-react";
import { motion } from "framer-motion";

type TabType = "players" | "teams" | "kills" | "mvps" | "winrate";

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.05 } }
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0, transition: { duration: 0.3 } }
};

export default function Rankings() {
  const [activeTab, setActiveTab] = useState<TabType>("players");

  const { data: playersRanking } = trpc.ranking.getPlayers.useQuery({ limit: 50 });
  const { data: teamsRanking } = trpc.ranking.getTeams.useQuery({ limit: 50 });
  const { data: killsRanking } = trpc.ranking.getTopKills.useQuery({ limit: 50 });
  const { data: mvpsRanking } = trpc.ranking.getTopMvps.useQuery({ limit: 50 });
  const { data: winRateRanking } = trpc.ranking.getTopWinRate.useQuery({ limit: 50 });

  const tabs: { id: TabType; label: string; icon: React.ElementType }[] = [
    { id: "players", label: "Jogadores", icon: Users },
    { id: "teams", label: "Equipes", icon: Shield },
    { id: "kills", label: "Kills", icon: Crosshair },
    { id: "mvps", label: "MVPs", icon: Star },
    { id: "winrate", label: "Win Rate", icon: TrendingUp },
  ];

  const getData = () => {
    switch (activeTab) {
      case "players": return playersRanking || [];
      case "teams": return teamsRanking || [];
      case "kills": return killsRanking || [];
      case "mvps": return mvpsRanking || [];
      case "winrate": return winRateRanking || [];
    }
  };

  const isTeam = activeTab === "teams";
  const data = getData();

  return (
    <motion.div
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-6"
    >
      <motion.div variants={item}>
        <h1 className="text-2xl font-bold">Rankings</h1>
        <p className="text-sm text-[#8A8F98] mt-1">Temporada Ativa: Season 5</p>
      </motion.div>

      {/* Tabs */}
      <motion.div variants={item} className="flex items-center gap-2 overflow-x-auto scrollbar-custom pb-1">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              "flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-medium whitespace-nowrap transition-all",
              activeTab === tab.id
                ? "bg-[#00F0FF]/10 text-[#00F0FF] border border-[#00F0FF]/30"
                : "bg-white/5 text-[#8A8F98] border border-transparent hover:bg-white/10"
            )}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </motion.div>

      {/* Top 3 Podium */}
      {data.length >= 3 && (
        <motion.div variants={item} className="grid grid-cols-3 gap-4 items-end">
          {[1, 0, 2].map((idx) => {
            const entry = data[idx] as any;
            if (!entry) return null;
            const isFirst = idx === 0;
            return (
              <div
                key={idx}
                className={cn(
                  "glass-panel p-4 text-center",
                  isFirst && "border-[#FFD700]/30 shadow-[0_0_20px_rgba(255,215,0,0.1)]"
                )}
              >
                <div className={cn(
                  "w-12 h-12 rounded-full mx-auto mb-2 flex items-center justify-center text-lg font-bold",
                  idx === 0 ? "bg-[#FFD700]/20 text-[#FFD700]" :
                  idx === 1 ? "bg-[#C0C0C0]/20 text-[#C0C0C0]" :
                  "bg-[#CD7F32]/20 text-[#CD7F32]"
                )}>
                  {idx === 0 ? <Trophy className="w-6 h-6" /> : idx + 1}
                </div>
                <p className="font-semibold text-sm truncate">{isTeam ? entry.name : entry.nickname}</p>
                <p className="text-xs text-[#8A8F98] mt-1">
                  {isTeam ? entry.tag : entry.country}
                </p>
                <p className="text-lg font-mono font-bold text-[#00F0FF] mt-2">
                  {activeTab === "kills" ? entry.kills :
                   activeTab === "mvps" ? entry.mvps :
                   activeTab === "winrate" ? `${entry.winRate}%` :
                   entry.rankingPoints}
                </p>
              </div>
            );
          })}
        </motion.div>
      )}

      {/* Full Table */}
      <motion.div variants={item} className="glass-panel overflow-hidden">
        <div className="overflow-x-auto scrollbar-custom">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/5">
                <th className="text-left px-4 py-3 text-xs font-medium text-[#8A8F98] uppercase w-16">Rank</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-[#8A8F98] uppercase">
                  {isTeam ? "Organizacao" : "Jogador"}
                </th>
                {!isTeam && (
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8A8F98] uppercase hidden sm:table-cell">Pais</th>
                )}
                {isTeam && (
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8A8F98] uppercase hidden sm:table-cell">Tag</th>
                )}
                <th className="text-right px-4 py-3 text-xs font-medium text-[#8A8F98] uppercase">
                  {activeTab === "kills" ? "Kills" :
                   activeTab === "mvps" ? "MVPs" :
                   activeTab === "winrate" ? "Win Rate" :
                   "Pontos"}
                </th>
                <th className="text-right px-4 py-3 text-xs font-medium text-[#8A8F98] uppercase hidden md:table-cell">Partidas</th>
                <th className="text-right px-4 py-3 text-xs font-medium text-[#8A8F98] uppercase hidden md:table-cell">Wins</th>
              </tr>
            </thead>
            <tbody>
              {data.map((entry: any, idx: number) => (
                <tr
                  key={entry.id}
                  className="border-b border-white/[0.02] hover:bg-white/[0.02] transition-colors"
                >
                  <td className="px-4 py-3">
                    <span className={cn(
                      "w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold font-mono",
                      idx === 0 ? "bg-[#FFD700]/20 text-[#FFD700]" :
                      idx === 1 ? "bg-[#C0C0C0]/20 text-[#C0C0C0]" :
                      idx === 2 ? "bg-[#CD7F32]/20 text-[#CD7F32]" :
                      "text-[#8A8F98]"
                    )}>
                      {idx + 1}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#00F0FF]/20 to-[#BC13FE]/20 flex items-center justify-center">
                        {isTeam ? (
                          <Shield className="w-4 h-4 text-[#00F0FF]" />
                        ) : (
                          <Users className="w-4 h-4 text-[#00F0FF]" />
                        )}
                      </div>
                      <span className="text-sm font-medium">{isTeam ? entry.name : entry.nickname}</span>
                    </div>
                  </td>
                  {!isTeam && (
                    <td className="px-4 py-3 hidden sm:table-cell">
                      <span className="text-sm text-[#8A8F98]">{entry.country}</span>
                    </td>
                  )}
                  {isTeam && (
                    <td className="px-4 py-3 hidden sm:table-cell">
                      <span className="text-sm font-mono text-[#00F0FF]">{entry.tag}</span>
                    </td>
                  )}
                  <td className="px-4 py-3 text-right">
                    <span className="text-sm font-mono font-semibold text-[#00F0FF]">
                      {activeTab === "kills" ? entry.kills :
                       activeTab === "mvps" ? entry.mvps :
                       activeTab === "winrate" ? `${entry.winRate}%` :
                       entry.rankingPoints}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right hidden md:table-cell">
                    <span className="text-sm text-[#8A8F98]">{entry.matchesPlayed}</span>
                  </td>
                  <td className="px-4 py-3 text-right hidden md:table-cell">
                    <span className="text-sm text-[#00FF94]">{entry.wins}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </motion.div>
  );
}

function cn(...classes: (string | undefined | false)[]) {
  return classes.filter(Boolean).join(" ");
}
