import { useParams, useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { ArrowLeft, MapPin, Trophy, Users, Crosshair, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

export default function OrganizationDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const orgId = Number(id);
  
  const { data: org } = trpc.organization.getById.useQuery({ id: orgId });

  if (!org) {
    return (
      <div className="glass-panel p-12 text-center">
        <div className="animate-spin w-8 h-8 border-2 border-[#00F0FF] border-t-transparent rounded-full mx-auto mb-3" />
        <p className="text-[#8A8F98]">Carregando organizacao...</p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="flex items-center gap-4">
        <button
          onClick={() => navigate("/organizations")}
          className="p-2 rounded-xl hover:bg-white/5 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#00F0FF]/20 to-[#BC13FE]/20 flex items-center justify-center text-2xl font-bold text-[#00F0FF]">
            {org.tag}
          </div>
          <div>
            <h1 className="text-2xl font-bold">{org.name}</h1>
            <div className="flex items-center gap-3 mt-1">
              <span className="text-sm text-[#8A8F98] flex items-center gap-1">
                <MapPin className="w-3 h-3" /> {org.country}
              </span>
              <span className="text-sm font-mono text-[#00F0FF]">{org.tag}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Pontos", value: org.rankingPoints, icon: Trophy, color: "#00F0FF" },
          { label: "Vitorias", value: org.wins, icon: TrendingUp, color: "#00FF94" },
          { label: "Derrotas", value: org.losses, icon: TrendingUp, color: "#FF2E63" },
          { label: "Kills", value: org.kills, icon: Crosshair, color: "#BC13FE" },
        ].map((stat) => (
          <div key={stat.label} className="stat-card">
            <div className="flex items-center gap-2 mb-2">
              <stat.icon className="w-4 h-4" style={{ color: stat.color }} />
              <span className="text-xs text-[#8A8F98]">{stat.label}</span>
            </div>
            <p className="text-xl font-bold font-mono">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Players */}
      <div className="glass-panel p-6">
        <h2 className="text-lg font-semibold flex items-center gap-2 mb-4">
          <Users className="w-5 h-5 text-[#00F0FF]" />
          Jogadores ({org.players?.length || 0})
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {(org.players || []).map((player) => (
            <div
              key={player.id}
              className="flex items-center gap-3 p-3 rounded-xl bg-white/[0.02] hover:bg-white/5 transition-colors"
            >
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#00F0FF]/20 to-[#BC13FE]/20 flex items-center justify-center">
                <Users className="w-5 h-5 text-[#00F0FF]" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{player.nickname}</p>
                <p className="text-xs text-[#8A8F98] capitalize">{player.role}</p>
              </div>
              <div className="text-right">
                <p className="text-xs font-mono text-[#00F0FF]">{player.rankingPoints} pts</p>
                <p className="text-xs text-[#8A8F98]">{player.kills} kills</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
