import { useState } from "react";
import { useParams, useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import {
  ArrowLeft,
  Copy,
  Check,
  Users,
  MessageSquare,
  Shield,
  Clock,
  Calendar,
  Link as LinkIcon,
  Radio,
} from "lucide-react";
import { motion } from "framer-motion";

export default function EventDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const eventId = Number(id);
  
  const { data: event } = trpc.event.getById.useQuery({ id: eventId });
  const { data: slotsData } = trpc.registration.getByEvent.useQuery({ eventId });
  const { data: templateData, refetch: generateMessage } = trpc.template.generateMessage.useQuery(
    { templateId: 1, eventId },
    { enabled: false }
  );
  const utils = trpc.useUtils();
  const createRegistration = trpc.registration.create.useMutation({
    onSuccess: () => {
      utils.registration.getByEvent.invalidate({ eventId });
      setShowForm(false);
      setFormData({ teamName: "", captainName: "", captainDiscord: "", region: "", notes: "" });
    },
  });

  const [showForm, setShowForm] = useState(false);
  const [copied, setCopied] = useState(false);
  const [formData, setFormData] = useState({
    teamName: "",
    captainName: "",
    captainDiscord: "",
    region: "",
    notes: "",
  });

  if (!event) {
    return (
      <div className="glass-panel p-12 text-center">
        <div className="animate-spin w-8 h-8 border-2 border-[#00F0FF] border-t-transparent rounded-full mx-auto mb-3" />
        <p className="text-[#8A8F98]">Carregando evento...</p>
      </div>
    );
  }

  const handleCopyMessage = async () => {
    const result = await generateMessage();
    if (result.data?.message) {
      await navigator.clipboard.writeText(result.data.message);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createRegistration.mutate({
      eventId,
      teamName: formData.teamName,
      captainName: formData.captainName,
      captainDiscord: formData.captainDiscord,
      region: formData.region || undefined,
      notes: formData.notes || undefined,
    });
  };

  const filledSlots = (slotsData?.slots || []).filter(s => !s.isEmpty).length;
  const totalSlots = slotsData?.maxTeams || event.maxTeams || 20;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex items-center gap-4">
        <button
          onClick={() => navigate("/events")}
          className="p-2 rounded-xl hover:bg-white/5 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold">{event.name}</h1>
            {event.status === "live" && (
              <span className="badge-live animate-pulse flex items-center gap-1">
                <Radio className="w-3 h-3" /> AO VIVO
              </span>
            )}
            {event.status === "upcoming" && <span className="badge-upcoming">PROXIMO</span>}
            {event.status === "finished" && <span className="badge-finished">CONCLUIDO</span>}
          </div>
          <p className="text-sm text-[#8A8F98] mt-1 capitalize">{event.type} • {event.mode} • {event.format?.replace("_", " ")}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Info */}
        <div className="lg:col-span-2 space-y-6">
          {/* Event Info */}
          <div className="glass-panel p-6">
            <h2 className="text-lg font-semibold mb-4">Informacoes do Evento</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#00F0FF]/10 flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-[#00F0FF]" />
                </div>
                <div>
                  <p className="text-xs text-[#8A8F98]">Data</p>
                  <p className="text-sm font-medium">
                    {event.date ? new Date(event.date).toLocaleDateString("pt-BR") : "N/A"}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#00F0FF]/10 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-[#00F0FF]" />
                </div>
                <div>
                  <p className="text-xs text-[#8A8F98]">Horario BR</p>
                  <p className="text-sm font-medium">{event.timeBr || "N/A"}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#BC13FE]/10 flex items-center justify-center">
                  <Users className="w-5 h-5 text-[#BC13FE]" />
                </div>
                <div>
                  <p className="text-xs text-[#8A8F98]">Vagas</p>
                  <p className="text-sm font-medium">{filledSlots}/{totalSlots}</p>
                </div>
              </div>
            </div>
            
            {event.description && (
              <div className="mt-4 pt-4 border-t border-white/5">
                <p className="text-sm text-[#8A8F98]">{event.description}</p>
              </div>
            )}
            
            {event.rules && (
              <div className="mt-4 pt-4 border-t border-white/5">
                <p className="text-xs font-medium text-[#8A8F98] mb-1">Regras</p>
                <p className="text-sm">{event.rules}</p>
              </div>
            )}

            <div className="mt-4 pt-4 border-t border-white/5 flex items-center gap-4">
              {event.discordLink && (
                <a
                  href={event.discordLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-sm text-[#00F0FF] hover:underline"
                >
                  <LinkIcon className="w-4 h-4" /> Discord
                </a>
              )}
              {event.scrimLink && (
                <a
                  href={event.scrimLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-sm text-[#00F0FF] hover:underline"
                >
                  <LinkIcon className="w-4 h-4" /> Link Scrim
                </a>
              )}
            </div>
          </div>

          {/* Slots */}
          <div className="glass-panel p-6">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Shield className="w-5 h-5 text-[#00F0FF]" />
              Slots ({filledSlots}/{totalSlots})
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
              {(slotsData?.slots || []).map((slot) => (
                <div
                  key={slot.number}
                  className={cn(
                    "p-3 rounded-xl border text-center transition-all",
                    slot.isEmpty
                      ? "border-dashed border-white/10 bg-white/[0.02]"
                      : "border-[#00FF94]/30 bg-[#00FF94]/5"
                  )}
                >
                  <p className="text-xs text-[#8A8F98] font-mono mb-1">#{String(slot.number).padStart(2, "0")}</p>
                  {slot.team ? (
                    <p className="text-xs font-medium truncate">{slot.team.teamName}</p>
                  ) : (
                    <p className="text-xs text-[#4A4A54]">Vazio</p>
                  )}
                </div>
              ))}
            </div>

            {/* Reserves */}
            {(slotsData?.reserves || []).length > 0 && (
              <div className="mt-4 pt-4 border-t border-white/5">
                <h3 className="text-sm font-medium text-[#8A8F98] mb-2">Reservas</h3>
                <div className="space-y-1">
                  {(slotsData?.reserves || []).map((r) => (
                    <div key={r.id} className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/[0.02]">
                      <span className="text-xs text-[#8A8F98] font-mono">R</span>
                      <span className="text-sm">{r.teamName}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Registration Form */}
          {event.registrationOpen && (
            <div className="glass-panel p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <Users className="w-5 h-5 text-[#00FF94]" />
                  Inscrever Equipe
                </h2>
                <button
                  onClick={() => setShowForm(!showForm)}
                  className="btn-primary text-sm py-2 px-4"
                >
                  {showForm ? "Cancelar" : "Nova Inscricao"}
                </button>
              </div>

              {showForm && (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm text-[#8A8F98] mb-1 block">Nome da Equipe *</label>
                      <input
                        type="text"
                        required
                        value={formData.teamName}
                        onChange={(e) => setFormData({ ...formData, teamName: e.target.value })}
                        className="input-dark w-full"
                        placeholder="Ex: Red Devils"
                      />
                    </div>
                    <div>
                      <label className="text-sm text-[#8A8F98] mb-1 block">Nome do Capitao *</label>
                      <input
                        type="text"
                        required
                        value={formData.captainName}
                        onChange={(e) => setFormData({ ...formData, captainName: e.target.value })}
                        className="input-dark w-full"
                        placeholder="Ex: Devil_King"
                      />
                    </div>
                    <div>
                      <label className="text-sm text-[#8A8F98] mb-1 block">Discord do Capitao</label>
                      <input
                        type="text"
                        value={formData.captainDiscord}
                        onChange={(e) => setFormData({ ...formData, captainDiscord: e.target.value })}
                        className="input-dark w-full"
                        placeholder="user#1234"
                      />
                    </div>
                    <div>
                      <label className="text-sm text-[#8A8F98] mb-1 block">Regiao</label>
                      <input
                        type="text"
                        value={formData.region}
                        onChange={(e) => setFormData({ ...formData, region: e.target.value })}
                        className="input-dark w-full"
                        placeholder="Ex: BR"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm text-[#8A8F98] mb-1 block">Observacoes</label>
                    <textarea
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      className="input-dark w-full h-20 resize-none"
                      placeholder="Observacoes adicionais..."
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={createRegistration.isPending}
                    className="btn-primary w-full disabled:opacity-50"
                  >
                    {createRegistration.isPending ? "Inscrevendo..." : "Confirmar Inscricao"}
                  </button>
                </form>
              )}
            </div>
          )}
        </div>

        {/* Right Column: WhatsApp Generator */}
        <div className="space-y-6">
          <div className="glass-panel p-6">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-[#00FF94]" />
              Gerar Msg WhatsApp
            </h2>
            <button
              onClick={handleCopyMessage}
              className="btn-secondary w-full mb-4 flex items-center justify-center gap-2"
            >
              {copied ? <Check className="w-4 h-4 text-[#00FF94]" /> : <Copy className="w-4 h-4" />}
              {copied ? "Copiado!" : "Gerar e Copiar Mensagem"}
            </button>
            
            {templateData?.message && (
              <div className="bg-[#0A0A0F] border border-[#1A1A24] rounded-xl p-4">
                <pre className="text-xs text-[#8A8F98] whitespace-pre-wrap font-mono leading-relaxed">
                  {templateData.message}
                </pre>
              </div>
            )}
          </div>

          {/* Quick Stats */}
          <div className="glass-panel p-6">
            <h3 className="text-sm font-semibold text-[#8A8F98] mb-3">Estatisticas Rapidas</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">Slots Preenchidos</span>
                <span className="text-sm font-mono text-[#00F0FF]">{filledSlots}/{totalSlots}</span>
              </div>
              <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-[#00F0FF] to-[#BC13FE] rounded-full transition-all"
                  style={{ width: `${(filledSlots / totalSlots) * 100}%` }}
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Reservas</span>
                <span className="text-sm font-mono text-[#8A8F98]">{(slotsData?.reserves || []).length}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function cn(...classes: (string | undefined | false)[]) {
  return classes.filter(Boolean).join(" ");
}
