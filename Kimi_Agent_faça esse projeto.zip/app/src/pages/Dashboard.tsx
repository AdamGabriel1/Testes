import { trpc } from "@/providers/trpc";
import { useAppStore } from "@/stores/appStore";
import {
  Users,
  Shield,
  Calendar,
  Radio,
  Trophy,
  ArrowRight,
} from "lucide-react";
import { Link } from "react-router";
import { motion } from "framer-motion";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4 } }
};

export default function Dashboard() {
  const { siteMode } = useAppStore();
  const { data: stats } = trpc.dashboard.getStats.useQuery();
  const { data: topPlayers } = trpc.dashboard.getTopPlayers.useQuery();
  const { data: topOrgs } = trpc.dashboard.getTopOrganizations.useQuery();
  const { data: upcomingEvents } = trpc.dashboard.getUpcomingEvents.useQuery();
  const { data: liveMatches } = trpc.dashboard.getLiveMatches.useQuery();

  const statCards = [
    { label: "Jogadores Ativos", value: stats?.players || 0, icon: Users, color: "#00F0FF" },
    { label: "Equipes Inscritas", value: stats?.organizations || 0, icon: Shield, color: "#BC13FE" },
    { label: "Eventos Agendados", value: stats?.upcomingEvents || 0, icon: Calendar, color: "#00FF94" },
    { label: "Eventos Ao Vivo", value: stats?.liveEvents || 0, icon: Radio, color: "#FF2E63" },
  ];

  const filteredEvents = upcomingEvents?.filter(e => {
    if (siteMode === "all") return true;
    return e.type === siteMode;
  });

  return (
    <motion.div
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-6"
    >
      {/* Stats Overview */}
      <motion.div variants={item} className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat) => (
          <div key={stat.label} className="stat-card">
            <div className="flex items-center gap-3 mb-3">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ backgroundColor: `${stat.color}15` }}
              >
                <stat.icon className="w-5 h-5" style={{ color: stat.color }} />
              </div>
            </div>
            <p className="text-2xl lg:text-3xl font-bold font-mono">{stat.value}</p>
            <p className="text-sm text-[#8A8F98] mt-1">{stat.label}</p>
          </div>
        ))}
      </motion.div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Upcoming Events */}
        <motion.div variants={item} className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[#00F0FF]" />
              Proximos Eventos
            </h2>
            <Link to="/events" className="text-sm text-[#00F0FF] hover:underline flex items-center gap-1">
              Ver todos <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {(filteredEvents || []).length === 0 && (
            <div className="glass-panel p-8 text-center">
              <Calendar className="w-12 h-12 text-[#8A8F98] mx-auto mb-3" />
              <p className="text-[#8A8F98]">Nenhum evento encontrado para este modo</p>
            </div>
          )}

          {(filteredEvents || []).map((event) => (
            <Link
              key={event.id}
              to={`/events/${event.id}`}
              className="glass-panel-hover p-4 flex flex-col sm:flex-row sm:items-center gap-4 block"
            >
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className={event.status === "live" ? "badge-live" : "badge-upcoming"}>
                    {event.status === "live" ? "AO VIVO" : event.type.toUpperCase()}
                  </span>
                  <span className="text-xs text-[#8A8F98] capitalize">{event.mode}</span>
                </div>
                <h3 className="font-semibold text-white">{event.name}</h3>
                <p className="text-sm text-[#8A8F98] mt-0.5">
                  {event.date ? new Date(event.date).toLocaleDateString("pt-BR") : ""}
                  {" "}
                  {event.timeBr && `• ${event.timeBr} (BR)`}
                </p>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="text-xs text-[#8A8F98]">Formato</p>
                  <p className="text-sm font-mono">{event.format}</p>
                </div>
                <ArrowRight className="w-5 h-5 text-[#8A8F98]" />
              </div>
            </Link>
          ))}
        </motion.div>

        {/* Sidebar: Top Players */}
        <motion.div variants={item} className="space-y-4">
          <div className="glass-panel p-6">
            <h2 className="text-lg font-semibold flex items-center gap-2 mb-4">
              <Trophy className="w-5 h-5 text-[#FFD700]" />
              Top Jogadores
            </h2>
            <div className="space-y-3">
              {(topPlayers || []).map((player, idx) => (
                <div
                  key={player.id}
                  className="flex items-center gap-3 p-2 rounded-xl hover:bg-white/5 transition-colors"
                >
                  <span className={cn(
                    "w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold font-mono",
                    idx === 0 ? "bg-[#FFD700]/20 text-[#FFD700]" :
                    idx === 1 ? "bg-[#C0C0C0]/20 text-[#C0C0C0]" :
                    idx === 2 ? "bg-[#CD7F32]/20 text-[#CD7F32]" :
                    "bg-white/5 text-[#8A8F98]"
                  )}>
                    {idx + 1}
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{player.nickname}</p>
                    <p className="text-xs text-[#8A8F98]">{player.kills} kills</p>
                  </div>
                  <span className="text-sm font-mono text-[#00F0FF]">{player.rankingPoints} pts</span>
                </div>
              ))}
            </div>
            <Link
              to="/rankings"
              className="mt-4 text-sm text-[#00F0FF] hover:underline flex items-center justify-center gap-1 pt-3 border-t border-white/5"
            >
              Ver ranking completo <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {/* Top Organizations */}
          <div className="glass-panel p-6">
            <h2 className="text-lg font-semibold flex items-center gap-2 mb-4">
              <Shield className="w-5 h-5 text-[#BC13FE]" />
              Top Organizacoes
            </h2>
            <div className="space-y-3">
              {(topOrgs || []).slice(0, 5).map((org, idx) => (
                <div
                  key={org.id}
                  className="flex items-center gap-3 p-2 rounded-xl hover:bg-white/5 transition-colors"
                >
                  <span className="w-7 h-7 rounded-lg bg-white/5 flex items-center justify-center text-xs font-bold font-mono text-[#8A8F98]">
                    {idx + 1}
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{org.name}</p>
                    <p className="text-xs text-[#8A8F98]">{org.tag}</p>
                  </div>
                  <span className="text-sm font-mono text-[#BC13FE]">{org.rankingPoints} pts</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>

      {/* Live Matches Section */}
      {(liveMatches || []).length > 0 && (
        <motion.div variants={item} className="space-y-4">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Radio className="w-5 h-5 text-[#FF2E63] animate-pulse" />
            Partidas Ao Vivo
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {(liveMatches || []).map((match) => (
              <div key={match.id} className="glass-panel p-4 neon-border">
                <div className="flex items-center justify-between mb-3">
                  <span className="badge-live animate-pulse">AO VIVO</span>
                  <span className="text-xs text-[#8A8F98] font-mono">Round {match.round}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="text-center flex-1">
                    <p className="text-sm font-medium">Time A</p>
                    <p className="text-2xl font-bold font-mono text-[#00F0FF]">{match.teamAScore}</p>
                  </div>
                  <span className="text-lg text-[#8A8F98] font-mono px-4">VS</span>
                  <div className="text-center flex-1">
                    <p className="text-sm font-medium">Time B</p>
                    <p className="text-2xl font-bold font-mono text-[#BC13FE]">{match.teamBScore}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}

function cn(...classes: (string | undefined | false)[]) {
  return classes.filter(Boolean).join(" ");
}
