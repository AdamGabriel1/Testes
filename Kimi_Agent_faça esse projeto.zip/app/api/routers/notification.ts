import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { notifications } from "@db/schema";
import { eq, desc, count } from "drizzle-orm";

export const notificationRouter = createRouter({
  list: publicQuery
    .input(z.object({
      userId: z.number().optional(),
      limit: z.number().min(1).max(50).default(20),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      return await db.select().from(notifications)
        .orderBy(desc(notifications.createdAt))
        .limit(input?.limit || 20);
    }),

  getUnreadCount: publicQuery.query(async () => {
    const db = getDb();
    const [result] = await db.select({ count: count() }).from(notifications)
      .where(eq(notifications.isRead, false));
    return result.count;
  }),

  markAsRead: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, input.id));
      return { success: true };
    }),

  markAllRead: publicQuery.mutation(async () => {
    const db = getDb();
    await db.update(notifications).set({ isRead: true });
    return { success: true };
  }),

  create: publicQuery
    .input(z.object({
      title: z.string().min(1),
      message: z.string().optional(),
      type: z.string().default("info"),
      userId: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(notifications).values(input);
      return { id: Number(result.insertId), ...input };
    }),
});
