import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { players, organizations } from "@db/schema";
import { eq, desc, like } from "drizzle-orm";

export const playerRouter = createRouter({
  list: publicQuery
    .input(z.object({
      search: z.string().optional(),
      organizationId: z.number().optional(),
      country: z.string().optional(),
      role: z.string().optional(),
      limit: z.number().min(1).max(100).default(50),
      offset: z.number().min(0).default(0),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      
      if (input?.search) {
        return await db.select({
          id: players.id,
          nickname: players.nickname,
          gameId: players.gameId,
          uid: players.uid,
          discord: players.discord,
          country: players.country,
          role: players.role,
          avatar: players.avatar,
          organizationId: players.organizationId,
          kills: players.kills,
          mvps: players.mvps,
          wins: players.wins,
          losses: players.losses,
          matchesPlayed: players.matchesPlayed,
          winRate: players.winRate,
          rankingPoints: players.rankingPoints,
          penalizations: players.penalizations,
          isBanned: players.isBanned,
          createdAt: players.createdAt,
        }).from(players)
          .leftJoin(organizations, eq(players.organizationId, organizations.id))
          .where(like(players.nickname, `%${input.search}%`))
          .orderBy(desc(players.rankingPoints))
          .limit(input.limit)
          .offset(input.offset);
      }
      
      if (input?.organizationId) {
        return await db.select().from(players)
          .where(eq(players.organizationId, input.organizationId))
          .orderBy(desc(players.rankingPoints));
      }

      return await db.select().from(players)
        .orderBy(desc(players.rankingPoints))
        .limit(input?.limit || 50)
        .offset(input?.offset || 0);
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [player] = await db.select().from(players).where(eq(players.id, input.id));
      if (!player) return null;
      
      let org = null;
      if (player.organizationId) {
        const [o] = await db.select().from(organizations).where(eq(organizations.id, player.organizationId));
        org = o;
      }
      
      return { ...player, organization: org };
    }),

  getTop: publicQuery
    .input(z.object({
      by: z.enum(["kills", "rankingPoints"]).default("rankingPoints"),
      limit: z.number().min(1).max(50).default(10),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const orderBy = input?.by || "rankingPoints";
      
      if (orderBy === "kills") {
        return await db.select().from(players)
          .orderBy(desc(players.kills))
          .limit(input?.limit || 10);
      }
      
      return await db.select().from(players)
        .orderBy(desc(players.rankingPoints))
        .limit(input?.limit || 10);
    }),

  create: publicQuery
    .input(z.object({
      nickname: z.string().min(1),
      gameId: z.string().optional(),
      uid: z.string().optional(),
      discord: z.string().optional(),
      whatsapp: z.string().optional(),
      country: z.string().optional(),
      role: z.string().default("player"),
      organizationId: z.number().optional(),
      avatar: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(players).values(input);
      return { id: Number(result.insertId), ...input };
    }),

  update: publicQuery
    .input(z.object({
      id: z.number(),
      nickname: z.string().optional(),
      gameId: z.string().optional(),
      uid: z.string().optional(),
      discord: z.string().optional(),
      country: z.string().optional(),
      role: z.string().optional(),
      organizationId: z.number().optional(),
      kills: z.number().optional(),
      mvps: z.number().optional(),
      wins: z.number().optional(),
      losses: z.number().optional(),
      matchesPlayed: z.number().optional(),
      winRate: z.string().optional(),
      rankingPoints: z.number().optional(),
      penalizations: z.number().optional(),
      isBanned: z.boolean().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(players).set(data).where(eq(players.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(players).where(eq(players.id, input.id));
      return { success: true };
    }),
});
