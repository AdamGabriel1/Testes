import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { seasons } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const seasonRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return await db.select().from(seasons).orderBy(desc(seasons.createdAt));
  }),

  getActive: publicQuery.query(async () => {
    const db = getDb();
    const [season] = await db.select().from(seasons).where(eq(seasons.isActive, true));
    return season || null;
  }),

  create: publicQuery
    .input(z.object({
      name: z.string().min(1),
      startDate: z.string().optional(),
      endDate: z.string().optional(),
      isActive: z.boolean().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const data: any = { name: input.name };
      if (input.startDate) data.startDate = new Date(input.startDate);
      if (input.endDate) data.endDate = new Date(input.endDate);
      if (input.isActive !== undefined) data.isActive = input.isActive;
      
      const [result] = await db.insert(seasons).values(data);
      return { id: Number(result.insertId), ...input };
    }),
});
