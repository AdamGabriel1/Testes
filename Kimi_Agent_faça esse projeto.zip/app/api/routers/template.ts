import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { templates, events, registrations } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const templateRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return await db.select().from(templates).orderBy(desc(templates.createdAt));
  }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [template] = await db.select().from(templates).where(eq(templates.id, input.id));
      return template || null;
    }),

  create: publicQuery
    .input(z.object({
      name: z.string().min(1),
      content: z.string().min(1),
      variables: z.array(z.string()).optional(),
      isDefault: z.boolean().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(templates).values(input);
      return { id: Number(result.insertId), ...input };
    }),

  update: publicQuery
    .input(z.object({
      id: z.number(),
      name: z.string().optional(),
      content: z.string().optional(),
      variables: z.array(z.string()).optional(),
      isDefault: z.boolean().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(templates).set(data).where(eq(templates.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(templates).where(eq(templates.id, input.id));
      return { success: true };
    }),

  generateMessage: publicQuery
    .input(z.object({
      templateId: z.number(),
      eventId: z.number(),
    }))
    .query(async ({ input }) => {
      const db = getDb();
      
      const [template] = await db.select().from(templates).where(eq(templates.id, input.templateId));
      if (!template) return null;
      
      const [event] = await db.select().from(events).where(eq(events.id, input.eventId));
      if (!event) return null;
      
      const regs = await db.select().from(registrations)
        .where(eq(registrations.eventId, input.eventId));
      
      const mainTeams = regs.filter(r => !r.isReserve);
      const reserveTeams = regs.filter(r => r.isReserve);
      
      const formatDate = (dateStr: string | Date | null) => {
        if (!dateStr) return "";
        const d = new Date(dateStr);
        return d.toLocaleDateString("pt-BR");
      };
      
      const formatMode = (mode: string) => {
        const modes: Record<string, string> = {
          solo: "SOLO", duo: "DUO", trio: "TRIO", squad: "SQUAD",
          "2v2": "2v2", "4v4": "4v4", "5v5": "5v5",
        };
        return modes[mode] || mode.toUpperCase();
      };
      
      const formatFormat = (format: string) => {
        const formats: Record<string, string> = {
          pontuacao_corrida: "Pontuação Corrida",
          mata_mata: "Mata-Mata",
          fase_grupos: "Fase de Grupos",
          chaveamento: "Chaveamento",
          eliminacao_simples: "Eliminação Simples",
          eliminacao_dupla: "Eliminação Dupla",
          suico: "Sistema Suíço",
        };
        return formats[format] || format;
      };
      
      let equipesStr = "";
      mainTeams.forEach((t, i) => {
        equipesStr += `📍 ${String(i + 1).padStart(2, "0")} — ${t.teamName}\n`;
      });
      
      let reservasStr = "";
      if (reserveTeams.length > 0) {
        reserveTeams.forEach((t, i) => {
          reservasStr += `⚪ ${String(i + 1).padStart(2, "0")} — ${t.teamName}\n`;
        });
      } else {
        reservasStr = "Nenhuma reserva";
      }
      
      let message = template.content
        .replace(/{nome_camp}/g, event.name)
        .replace(/{modo}/g, formatMode(event.mode))
        .replace(/{data}/g, formatDate(event.date))
        .replace(/{horario_br}/g, event.timeBr || "")
        .replace(/{horario_ar}/g, event.timeAr || "")
        .replace(/{horario_mx}/g, event.timeMx || "")
        .replace(/{horario_mex}/g, event.timeMx || "")
        .replace(/{equipes}/g, equipesStr.trim())
        .replace(/{reservas}/g, reservasStr.trim())
        .replace(/{link_scrim}/g, event.scrimLink || "")
        .replace(/{link_discord}/g, event.discordLink || "")
        .replace(/{regras}/g, event.rules || "")
        .replace(/{formato}/g, formatFormat(event.format));
      
      return { message, template, event };
    }),
});
