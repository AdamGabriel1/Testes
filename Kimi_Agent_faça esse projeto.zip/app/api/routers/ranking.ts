import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { organizations, players } from "@db/schema";
import { desc } from "drizzle-orm";

export const rankingRouter = createRouter({
  getTeams: publicQuery
    .input(z.object({
      limit: z.number().min(1).max(100).default(50),
      offset: z.number().min(0).default(0),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      return await db.select().from(organizations)
        .orderBy(desc(organizations.rankingPoints))
        .limit(input?.limit || 50)
        .offset(input?.offset || 0);
    }),

  getPlayers: publicQuery
    .input(z.object({
      limit: z.number().min(1).max(100).default(50),
      offset: z.number().min(0).default(0),
      mode: z.string().optional(),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      return await db.select().from(players)
        .orderBy(desc(players.rankingPoints))
        .limit(input?.limit || 50)
        .offset(input?.offset || 0);
    }),

  getTopKills: publicQuery
    .input(z.object({
      limit: z.number().min(1).max(50).default(20),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      return await db.select().from(players)
        .orderBy(desc(players.kills))
        .limit(input?.limit || 20);
    }),

  getTopMvps: publicQuery
    .input(z.object({
      limit: z.number().min(1).max(50).default(20),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      return await db.select().from(players)
        .orderBy(desc(players.mvps))
        .limit(input?.limit || 20);
    }),

  getTopWinRate: publicQuery
    .input(z.object({
      limit: z.number().min(1).max(50).default(20),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      return await db.select().from(players)
        .orderBy(desc(players.winRate))
        .limit(input?.limit || 20);
    }),
});
