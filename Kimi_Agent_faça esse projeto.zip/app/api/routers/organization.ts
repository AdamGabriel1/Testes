import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { organizations, players } from "@db/schema";
import { eq, desc, like, count } from "drizzle-orm";

export const organizationRouter = createRouter({
  list: publicQuery
    .input(z.object({
      search: z.string().optional(),
      country: z.string().optional(),
      limit: z.number().min(1).max(100).default(50),
      offset: z.number().min(0).default(0),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      
      if (input?.search) {
        return await db.select().from(organizations)
          .where(like(organizations.name, `%${input.search}%`))
          .orderBy(desc(organizations.rankingPoints))
          .limit(input.limit)
          .offset(input.offset);
      }
      
      if (input?.country) {
        return await db.select().from(organizations)
          .where(eq(organizations.country, input.country))
          .orderBy(desc(organizations.rankingPoints))
          .limit(input.limit)
          .offset(input.offset);
      }

      return await db.select().from(organizations)
        .orderBy(desc(organizations.rankingPoints))
        .limit(input?.limit || 50)
        .offset(input?.offset || 0);
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [org] = await db.select().from(organizations).where(eq(organizations.id, input.id));
      if (!org) return null;
      
      const orgPlayers = await db.select().from(players).where(eq(players.organizationId, input.id));
      return { ...org, players: orgPlayers };
    }),

  create: publicQuery
    .input(z.object({
      name: z.string().min(1),
      tag: z.string().min(1).max(50),
      logo: z.string().optional(),
      owner: z.string().min(1),
      captain: z.string().optional(),
      description: z.string().optional(),
      country: z.string().optional(),
      discord: z.string().optional(),
      whatsapp: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(organizations).values(input);
      return { id: Number(result.insertId), ...input };
    }),

  update: publicQuery
    .input(z.object({
      id: z.number(),
      name: z.string().optional(),
      tag: z.string().optional(),
      logo: z.string().optional(),
      owner: z.string().optional(),
      captain: z.string().optional(),
      description: z.string().optional(),
      country: z.string().optional(),
      discord: z.string().optional(),
      whatsapp: z.string().optional(),
      rankingPoints: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(organizations).set(data).where(eq(organizations.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(organizations).where(eq(organizations.id, input.id));
      return { success: true };
    }),

  getStats: publicQuery.query(async () => {
    const db = getDb();
    const [total] = await db.select({ count: count() }).from(organizations);
    const topOrg = await db.select().from(organizations).orderBy(desc(organizations.rankingPoints)).limit(1);
    return {
      total: total.count,
      topOrg: topOrg[0] || null,
    };
  }),
});
