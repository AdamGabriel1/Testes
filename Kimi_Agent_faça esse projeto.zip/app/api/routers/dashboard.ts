import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { organizations, players, events, matches } from "@db/schema";
import { eq, desc, count } from "drizzle-orm";

export const dashboardRouter = createRouter({
  getStats: publicQuery.query(async () => {
    const db = getDb();
    const [orgCount] = await db.select({ count: count() }).from(organizations);
    const [playerCount] = await db.select({ count: count() }).from(players);
    const [eventCount] = await db.select({ count: count() }).from(events);
    const [matchCount] = await db.select({ count: count() }).from(matches);
    const [liveEvents] = await db.select({ count: count() }).from(events).where(eq(events.status, "live"));
    const [upcomingEvents] = await db.select({ count: count() }).from(events).where(eq(events.status, "upcoming"));

    return {
      organizations: orgCount.count,
      players: playerCount.count,
      events: eventCount.count,
      matches: matchCount.count,
      liveEvents: liveEvents.count,
      upcomingEvents: upcomingEvents.count,
    };
  }),

  getRecentActivity: publicQuery.query(async () => {
    const db = getDb();
    const logs = await db.select().from(matches).orderBy(desc(matches.createdAt)).limit(10);
    return logs;
  }),

  getUpcomingEvents: publicQuery.query(async () => {
    const db = getDb();
    const upcoming = await db.select().from(events)
      .where(eq(events.status, "upcoming"))
      .orderBy(events.date)
      .limit(5);
    return upcoming;
  }),

  getLiveMatches: publicQuery.query(async () => {
    const db = getDb();
    const live = await db.select().from(matches)
      .where(eq(matches.status, "live"))
      .limit(10);
    return live;
  }),

  getTopPlayers: publicQuery.query(async () => {
    const db = getDb();
    const topPlayers = await db.select().from(players)
      .orderBy(desc(players.rankingPoints))
      .limit(5);
    return topPlayers;
  }),

  getTopOrganizations: publicQuery.query(async () => {
    const db = getDb();
    const topOrgs = await db.select().from(organizations)
      .orderBy(desc(organizations.rankingPoints))
      .limit(5);
    return topOrgs;
  }),
});
