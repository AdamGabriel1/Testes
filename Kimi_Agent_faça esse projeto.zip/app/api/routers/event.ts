import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { events, registrations } from "@db/schema";
import { eq, desc, count } from "drizzle-orm";

export const eventRouter = createRouter({
  list: publicQuery
    .input(z.object({
      type: z.string().optional(),
      status: z.string().optional(),
      mode: z.string().optional(),
      limit: z.number().min(1).max(100).default(50),
      offset: z.number().min(0).default(0),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      
      if (input?.type) {
        return await db.select().from(events)
          .where(eq(events.type, input.type))
          .orderBy(desc(events.createdAt))
          .limit(input.limit)
          .offset(input.offset);
      }
      
      if (input?.status) {
        return await db.select().from(events)
          .where(eq(events.status, input.status))
          .orderBy(desc(events.createdAt))
          .limit(input.limit)
          .offset(input.offset);
      }

      return await db.select().from(events)
        .orderBy(desc(events.createdAt))
        .limit(input?.limit || 50)
        .offset(input?.offset || 0);
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [event] = await db.select().from(events).where(eq(events.id, input.id));
      if (!event) return null;
      
      const eventRegs = await db.select().from(registrations).where(eq(registrations.eventId, input.id));
      return { ...event, registrations: eventRegs };
    }),

  getByType: publicQuery
    .input(z.object({ type: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      return await db.select().from(events)
        .where(eq(events.type, input.type))
        .orderBy(desc(events.date));
    }),

  create: publicQuery
    .input(z.object({
      name: z.string().min(1),
      type: z.string().min(1),
      mode: z.string().min(1),
      format: z.string().min(1),
      description: z.string().optional(),
      rules: z.string().optional(),
      banner: z.string().optional(),
      maxTeams: z.number().default(20),
      maxReserves: z.number().default(5),
      date: z.string().optional(),
      timeBr: z.string().optional(),
      timeAr: z.string().optional(),
      timeMx: z.string().optional(),
      discordLink: z.string().optional(),
      scrimLink: z.string().optional(),
      seasonId: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(events).values({
        ...input,
        date: input.date ? new Date(input.date) : null,
        status: "upcoming",
        registrationOpen: true,
      } as any);
      return { id: Number(result.insertId), ...input };
    }),

  update: publicQuery
    .input(z.object({
      id: z.number(),
      name: z.string().optional(),
      type: z.string().optional(),
      mode: z.string().optional(),
      format: z.string().optional(),
      status: z.string().optional(),
      description: z.string().optional(),
      rules: z.string().optional(),
      maxTeams: z.number().optional(),
      maxReserves: z.number().optional(),
      date: z.string().optional(),
      timeBr: z.string().optional(),
      timeAr: z.string().optional(),
      timeMx: z.string().optional(),
      discordLink: z.string().optional(),
      scrimLink: z.string().optional(),
      registrationOpen: z.boolean().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      const updateData: any = { ...data };
      if (data.date) {
        updateData.date = new Date(data.date);
      }
      await db.update(events).set(updateData).where(eq(events.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(events).where(eq(events.id, input.id));
      return { success: true };
    }),

  getStats: publicQuery.query(async () => {
    const db = getDb();
    const [total] = await db.select({ count: count() }).from(events);
    const [upcoming] = await db.select({ count: count() }).from(events).where(eq(events.status, "upcoming"));
    const [live] = await db.select({ count: count() }).from(events).where(eq(events.status, "live"));
    const [finished] = await db.select({ count: count() }).from(events).where(eq(events.status, "finished"));
    return { total: total.count, upcoming: upcoming.count, live: live.count, finished: finished.count };
  }),
});
