import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { registrations, events } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const registrationRouter = createRouter({
  list: publicQuery
    .input(z.object({
      eventId: z.number().optional(),
      status: z.string().optional(),
      limit: z.number().min(1).max(100).default(50),
      offset: z.number().min(0).default(0),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      
      if (input?.eventId) {
        return await db.select().from(registrations)
          .where(eq(registrations.eventId, input.eventId))
          .orderBy(registrations.slotNumber);
      }

      return await db.select().from(registrations)
        .orderBy(desc(registrations.createdAt))
        .limit(input?.limit || 50)
        .offset(input?.offset || 0);
    }),

  getByEvent: publicQuery
    .input(z.object({ eventId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const regs = await db.select().from(registrations)
        .where(eq(registrations.eventId, input.eventId))
        .orderBy(registrations.slotNumber);
      
      const [event] = await db.select().from(events).where(eq(events.id, input.eventId));
      
      const slots = [];
      for (let i = 1; i <= (event?.maxTeams || 20); i++) {
        const team = regs.find(r => r.slotNumber === i && !r.isReserve);
        slots.push({
          number: i,
          team: team || null,
          isEmpty: !team,
        });
      }
      
      const reserves = regs.filter(r => r.isReserve);
      
      return { registrations: regs, slots, reserves, maxTeams: event?.maxTeams || 20 };
    }),

  create: publicQuery
    .input(z.object({
      eventId: z.number(),
      teamName: z.string().min(1),
      teamLogo: z.string().optional(),
      captainName: z.string().min(1),
      captainDiscord: z.string().optional(),
      players: z.array(z.object({
        name: z.string(),
        discord: z.string(),
        gameId: z.string(),
      })).optional(),
      reservePlayers: z.array(z.object({
        name: z.string(),
        discord: z.string(),
        gameId: z.string(),
      })).optional(),
      region: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      
      const [event] = await db.select().from(events).where(eq(events.id, input.eventId));
      if (!event) throw new Error("Event not found");
      
      const existingRegs = await db.select().from(registrations)
        .where(eq(registrations.eventId, input.eventId));
      
      const mainRegs = existingRegs.filter(r => !r.isReserve);
      const isReserve = mainRegs.length >= (event.maxTeams || 20);
      
      let slotNumber = null;
      if (!isReserve) {
        const usedSlots = mainRegs.map(r => r.slotNumber).filter(Boolean);
        for (let i = 1; i <= (event.maxTeams || 20); i++) {
          if (!usedSlots.includes(i)) {
            slotNumber = i;
            break;
          }
        }
      }
      
      const [result] = await db.insert(registrations).values({
        ...input,
        players: input.players as any,
        reservePlayers: input.reservePlayers as any,
        isReserve,
        slotNumber,
        status: "approved",
      });
      
      return { id: Number(result.insertId), isReserve, slotNumber };
    }),

  update: publicQuery
    .input(z.object({
      id: z.number(),
      teamName: z.string().optional(),
      captainName: z.string().optional(),
      captainDiscord: z.string().optional(),
      players: z.array(z.any()).optional(),
      reservePlayers: z.array(z.any()).optional(),
      region: z.string().optional(),
      notes: z.string().optional(),
      slotNumber: z.number().optional(),
      isReserve: z.boolean().optional(),
      status: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(registrations).set(data as any).where(eq(registrations.id, id));
      return { success: true };
    }),

  approve: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(registrations).set({ status: "approved" }).where(eq(registrations.id, input.id));
      return { success: true };
    }),

  reject: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(registrations).set({ status: "rejected" }).where(eq(registrations.id, input.id));
      return { success: true };
    }),
});
