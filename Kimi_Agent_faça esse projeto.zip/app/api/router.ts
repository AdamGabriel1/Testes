import { authRouter } from "./auth-router";
import { createRouter, publicQuery } from "./middleware";
import { dashboardRouter } from "./routers/dashboard";
import { organizationRouter } from "./routers/organization";
import { playerRouter } from "./routers/player";
import { eventRouter } from "./routers/event";
import { registrationRouter } from "./routers/registration";
import { templateRouter } from "./routers/template";
import { rankingRouter } from "./routers/ranking";
import { seasonRouter } from "./routers/season";
import { notificationRouter } from "./routers/notification";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  dashboard: dashboardRouter,
  organization: organizationRouter,
  player: playerRouter,
  event: eventRouter,
  registration: registrationRouter,
  template: templateRouter,
  ranking: rankingRouter,
  season: seasonRouter,
  notification: notificationRouter,
});

export type AppRouter = typeof appRouter;
