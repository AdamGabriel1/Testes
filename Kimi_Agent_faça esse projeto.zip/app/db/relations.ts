import { relations } from "drizzle-orm";
import {
  users,
  organizations,
  players,
  seasons,
  events,
  registrations,
  matches,
  notifications,
  activityLogs,
} from "./schema";

export const usersRelations = relations(users, ({ many }) => ({
  events: many(events),
  notifications: many(notifications),
  activityLogs: many(activityLogs),
}));

export const organizationsRelations = relations(organizations, ({ many }) => ({
  players: many(players),
}));

export const playersRelations = relations(players, ({ one }) => ({
  organization: one(organizations, {
    fields: [players.organizationId],
    references: [organizations.id],
  }),
}));

export const seasonsRelations = relations(seasons, ({ many }) => ({
  events: many(events),
}));

export const eventsRelations = relations(events, ({ one, many }) => ({
  season: one(seasons, {
    fields: [events.seasonId],
    references: [seasons.id],
  }),
  creator: one(users, {
    fields: [events.createdBy],
    references: [users.id],
  }),
  registrations: many(registrations),
  matches: many(matches),
}));

export const registrationsRelations = relations(registrations, ({ one }) => ({
  event: one(events, {
    fields: [registrations.eventId],
    references: [events.id],
  }),
}));

export const matchesRelations = relations(matches, ({ one }) => ({
  event: one(events, {
    fields: [matches.eventId],
    references: [events.id],
  }),
}));
