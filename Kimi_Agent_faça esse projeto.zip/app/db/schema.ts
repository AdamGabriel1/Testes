import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  int,
  bigint,
  boolean,
  decimal,
  date,
  json,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const organizations = mysqlTable("organizations", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  tag: varchar("tag", { length: 50 }).notNull(),
  logo: varchar("logo", { length: 500 }),
  owner: varchar("owner", { length: 255 }).notNull(),
  captain: varchar("captain", { length: 255 }),
  description: text("description"),
  country: varchar("country", { length: 100 }),
  discord: varchar("discord", { length: 255 }),
  whatsapp: varchar("whatsapp", { length: 255 }),
  twitter: varchar("twitter", { length: 255 }),
  instagram: varchar("instagram", { length: 255 }),
  youtube: varchar("youtube", { length: 255 }),
  rankingPoints: int("ranking_points").default(0),
  wins: int("wins").default(0),
  losses: int("losses").default(0),
  matchesPlayed: int("matches_played").default(0),
  kills: int("kills").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow().$onUpdate(() => new Date()),
});

export const players = mysqlTable("players", {
  id: serial("id").primaryKey(),
  nickname: varchar("nickname", { length: 255 }).notNull(),
  gameId: varchar("game_id", { length: 255 }),
  uid: varchar("uid", { length: 255 }),
  discord: varchar("discord", { length: 255 }),
  whatsapp: varchar("whatsapp", { length: 255 }),
  country: varchar("country", { length: 100 }),
  role: varchar("role", { length: 100 }).default("player"),
  avatar: varchar("avatar", { length: 500 }),
  organizationId: bigint("organization_id", { mode: "number", unsigned: true }).references(() => organizations.id),
  kills: int("kills").default(0),
  mvps: int("mvps").default(0),
  wins: int("wins").default(0),
  losses: int("losses").default(0),
  matchesPlayed: int("matches_played").default(0),
  winRate: decimal("win_rate", { precision: 5, scale: 2 }).default("0.00"),
  rankingPoints: int("ranking_points").default(0),
  penalizations: int("penalizations").default(0),
  isBanned: boolean("is_banned").default(false),
  banReason: text("ban_reason"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow().$onUpdate(() => new Date()),
});

export const seasons = mysqlTable("seasons", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  startDate: date("start_date"),
  endDate: date("end_date"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const events = mysqlTable("events", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  type: varchar("type", { length: 100 }).notNull(),
  mode: varchar("mode", { length: 100 }).notNull(),
  format: varchar("format", { length: 100 }).notNull(),
  status: varchar("status", { length: 50 }).default("upcoming"),
  description: text("description"),
  rules: text("rules"),
  banner: varchar("banner", { length: 500 }),
  maxTeams: int("max_teams").default(20),
  maxReserves: int("max_reserves").default(5),
  date: date("date"),
  timeBr: varchar("time_br", { length: 50 }),
  timeAr: varchar("time_ar", { length: 50 }),
  timeMx: varchar("time_mx", { length: 50 }),
  discordLink: varchar("discord_link", { length: 500 }),
  scrimLink: varchar("scrim_link", { length: 500 }),
  registrationOpen: boolean("registration_open").default(true),
  createdBy: bigint("created_by", { mode: "number", unsigned: true }).references(() => users.id),
  seasonId: bigint("season_id", { mode: "number", unsigned: true }).references(() => seasons.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow().$onUpdate(() => new Date()),
});

export const registrations = mysqlTable("registrations", {
  id: serial("id").primaryKey(),
  eventId: bigint("event_id", { mode: "number", unsigned: true }).references(() => events.id).notNull(),
  teamName: varchar("team_name", { length: 255 }).notNull(),
  teamLogo: varchar("team_logo", { length: 500 }),
  captainName: varchar("captain_name", { length: 255 }).notNull(),
  captainDiscord: varchar("captain_discord", { length: 255 }),
  players: json("players").$type<Array<{ name: string; discord: string; gameId: string }>>(),
  reservePlayers: json("reserve_players").$type<Array<{ name: string; discord: string; gameId: string }>>(),
  region: varchar("region", { length: 100 }),
  notes: text("notes"),
  slotNumber: int("slot_number"),
  isReserve: boolean("is_reserve").default(false),
  status: varchar("status", { length: 50 }).default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const matches = mysqlTable("matches", {
  id: serial("id").primaryKey(),
  eventId: bigint("event_id", { mode: "number", unsigned: true }).references(() => events.id),
  round: int("round").default(1),
  bracket: varchar("bracket", { length: 50 }).default("winners"),
  teamAId: bigint("team_a_id", { mode: "number", unsigned: true }).references(() => registrations.id),
  teamBId: bigint("team_b_id", { mode: "number", unsigned: true }).references(() => registrations.id),
  teamAScore: int("team_a_score").default(0),
  teamBScore: int("team_b_score").default(0),
  status: varchar("status", { length: 50 }).default("scheduled"),
  winnerId: bigint("winner_id", { mode: "number", unsigned: true }).references(() => registrations.id),
  scheduledAt: timestamp("scheduled_at"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const templates = mysqlTable("templates", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  content: text("content").notNull(),
  variables: json("variables").$type<string[]>(),
  isDefault: boolean("is_default").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow().$onUpdate(() => new Date()),
});

export const notifications = mysqlTable("notifications", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message"),
  type: varchar("type", { length: 50 }).default("info"),
  isRead: boolean("is_read").default(false),
  userId: bigint("user_id", { mode: "number", unsigned: true }).references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const activityLogs = mysqlTable("activity_logs", {
  id: serial("id").primaryKey(),
  action: varchar("action", { length: 255 }).notNull(),
  details: text("details"),
  entityType: varchar("entity_type", { length: 100 }),
  entityId: bigint("entity_id", { mode: "number", unsigned: true }),
  userId: bigint("user_id", { mode: "number", unsigned: true }).references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});
