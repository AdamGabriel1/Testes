require('dotenv/config');
const mysql = require('mysql2/promise');

async function seed() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);

  console.log("Seeding...");

  // Seasons
  await conn.execute(
    `INSERT INTO seasons (name, start_date, end_date, is_active) VALUES (?, ?, ?, ?)`,
    ['Season 4', '2025-07-01', '2025-12-31', false]
  );
  await conn.execute(
    `INSERT INTO seasons (name, start_date, end_date, is_active) VALUES (?, ?, ?, ?)`,
    ['Season 5', '2026-01-01', '2026-06-30', true]
  );
  console.log("Seasons done");

  // Organizations
  const orgs = [
    ['Red Devils', 'RD', 'Brasil', 'DevilMaster', 'DevilKing', 'Equipe brasileira de elite em mobile esports', 1500, 45, 12, 57, 3420],
    ['Underground', 'UG', 'Argentina', 'UnderBoss', 'UG_Leader', 'Organizacao argentina competitiva', 1200, 38, 20, 58, 2890],
    ['Devils Mobile League', 'DML', 'Brasil', 'DML_Owner', 'DML_Captain', 'Liga profissional de mobile', 1800, 52, 8, 60, 4100],
    ['Red Magic BR', 'RMB', 'Brasil', 'MagicOwner', 'MagicCaptain', 'Magia no campo de batalha', 1350, 40, 15, 55, 3100],
    ['Shadow Squad', 'SS', 'Mexico', 'ShadowOwner', 'ShadowLead', 'Sombrios e letais', 1100, 33, 22, 55, 2650],
    ['Phoenix Rising', 'PX', 'Chile', 'PhoenixOwner', 'PhoenixCap', 'Renascendo das cinzas', 950, 28, 25, 53, 2380],
    ['Ghost Legion', 'GL', 'Argentina', 'GhostOwner', 'GhostLead', 'Fantasmas do campo', 800, 22, 30, 52, 1980],
    ['Neon Tigers', 'NT', 'Brasil', 'NeonOwner', 'NeonCap', 'Tigres eletricos', 1050, 31, 23, 54, 2520],
    ['Steel Wolves', 'SW', 'Mexico', 'WolfOwner', 'WolfLead', 'Lobos de aco', 900, 26, 28, 54, 2200],
    ['Dark Alliance', 'DA', 'Peru', 'DarkOwner', 'DarkCap', 'Alianca das sombras', 750, 20, 32, 52, 1850],
  ];
  for (const o of orgs) {
    await conn.execute(
      `INSERT INTO organizations (name, tag, country, owner, captain, description, ranking_points, wins, losses, matches_played, kills) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      o
    );
  }
  console.log("Orgs done");

  // Players
  const players = [
    ['Devil_King', 'RD001', '1001', 'devilking#1234', 'Brasil', 'capitao', 1, 1250, 18, 45, 12, 57, '78.95', 850],
    ['Devil_Storm', 'RD002', '1002', 'devilstorm#5678', 'Brasil', 'player', 1, 1100, 12, 42, 14, 56, '75.00', 720],
    ['Devil_Snake', 'RD003', '1003', 'devilsnake#9012', 'Brasil', 'player', 1, 1070, 15, 40, 15, 55, '72.73', 680],
    ['UG_Leader', 'UG001', '2001', 'ugleader#1111', 'Argentina', 'capitao', 2, 980, 14, 38, 20, 58, '65.52', 620],
    ['UG_Shadow', 'UG002', '2002', 'ugshadow#2222', 'Argentina', 'player', 2, 920, 10, 35, 22, 57, '61.40', 580],
    ['UG_Phoenix', 'UG003', '2003', 'ugphoenix#3333', 'Argentina', 'player', 2, 990, 11, 36, 21, 57, '63.16', 590],
    ['DML_God', 'DML001', '3001', 'dmlgod#4444', 'Brasil', 'capitao', 3, 1420, 22, 52, 8, 60, '86.67', 950],
    ['DML_Beast', 'DML002', '3002', 'dmlbeast#5555', 'Brasil', 'player', 3, 1380, 19, 50, 9, 59, '84.75', 880],
    ['DML_Ninja', 'DML003', '3003', 'dmlninja#6666', 'Brasil', 'player', 3, 1300, 16, 48, 10, 58, '82.76', 820],
    ['RMB_Magic', 'RMB001', '4001', 'rmbmagic#7777', 'Brasil', 'capitao', 4, 1050, 13, 40, 15, 55, '72.73', 670],
    ['RMB_Fire', 'RMB002', '4002', 'rmbfire#8888', 'Brasil', 'player', 4, 980, 11, 38, 17, 55, '69.09', 610],
    ['RMB_Ice', 'RMB003', '4003', 'rmbice#9999', 'Brasil', 'player', 4, 1070, 14, 39, 16, 55, '70.91', 640],
    ['SS_Shadow', 'SS001', '5001', 'ssshadow#0001', 'Mexico', 'capitao', 5, 890, 11, 33, 22, 55, '60.00', 580],
    ['SS_Night', 'SS002', '5002', 'ssnight#0002', 'Mexico', 'player', 5, 880, 9, 31, 23, 54, '57.41', 540],
    ['SS_Dark', 'SS003', '5003', 'ssdark#0003', 'Mexico', 'player', 5, 880, 10, 32, 23, 55, '58.18', 550],
    ['PX_Flame', 'PX001', '6001', 'pxflame#1112', 'Chile', 'capitao', 6, 800, 9, 28, 25, 53, '52.83', 480],
    ['PX_Blaze', 'PX002', '6002', 'pxblaze#1113', 'Chile', 'player', 6, 790, 8, 27, 26, 53, '50.94', 470],
    ['PX_Ash', 'PX003', '6003', 'pxash#1114', 'Chile', 'player', 6, 790, 7, 26, 26, 52, '50.00', 450],
    ['GL_Ghost', 'GL001', '7001', 'glghost#2223', 'Argentina', 'capitao', 7, 670, 7, 22, 30, 52, '42.31', 390],
    ['GL_Spirit', 'GL002', '7002', 'glspirit#2224', 'Argentina', 'player', 7, 660, 6, 21, 30, 51, '41.18', 370],
    ['GL_Soul', 'GL003', '7003', 'glsoul#2225', 'Argentina', 'player', 7, 650, 6, 21, 31, 52, '40.38', 360],
    ['NT_Tiger', 'NT001', '8001', 'nttiger#3334', 'Brasil', 'capitao', 8, 850, 10, 31, 23, 54, '57.41', 520],
    ['NT_Stripe', 'NT002', '8002', 'ntstripe#3335', 'Brasil', 'player', 8, 830, 9, 30, 24, 54, '55.56', 500],
    ['NT_Claw', 'NT003', '8003', 'ntclaw#3336', 'Brasil', 'player', 8, 840, 9, 30, 23, 53, '56.60', 510],
    ['SW_Alpha', 'SW001', '9001', 'swalpha#4445', 'Mexico', 'capitao', 9, 740, 8, 26, 28, 54, '48.15', 440],
    ['SW_Beta', 'SW002', '9002', 'swbeta#4446', 'Mexico', 'player', 9, 730, 7, 25, 28, 53, '47.17', 420],
    ['SW_Omega', 'SW003', '9003', 'swomega#4447', 'Mexico', 'player', 9, 730, 7, 25, 29, 54, '46.30', 410],
    ['DA_Dark', 'DA001', '10001', 'dadark#5556', 'Peru', 'capitao', 10, 620, 6, 20, 32, 52, '38.46', 350],
    ['DA_Shade', 'DA002', '10002', 'dashade#5557', 'Peru', 'player', 10, 610, 6, 20, 32, 52, '38.46', 340],
    ['DA_Eclipse', 'DA003', '10003', 'daeclipse#5558', 'Peru', 'player', 10, 620, 5, 19, 32, 51, '37.25', 330],
  ];
  for (const p of players) {
    await conn.execute(
      `INSERT INTO players (nickname, game_id, uid, discord, country, role, organization_id, kills, mvps, wins, losses, matches_played, win_rate, ranking_points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      p
    );
  }
  console.log("Players done");

  // Events
  const evs = [
    ['DEVILS MOBILE LEAGUE #45', 'scrim', 'squad', 'pontuacao_corrida', 'upcoming', 'Scrim semanal da Devils Mobile League', '3 quedas, sem auxilios', 25, 5, '2026-05-30', '21:00', '21:00', '19:00', 'https://discord.gg/dml', 'https://scrim.gg/dml45', true, 2],
    ['Xtrenio Red Devils #12', 'xtrenio', 'duo', 'pontuacao_corrida', 'upcoming', 'Xtrenio exclusivo da Red Devils', '4 quedas, pontuacao completa', 20, 3, '2026-05-28', '20:00', '20:00', '18:00', 'https://discord.gg/rd', 'https://scrim.gg/rd12', true, 2],
    ['Underground Championship', 'campeonato', 'squad', 'mata_mata', 'live', 'Campeonato oficial da Underground', 'Mata-mata duplo, 5 quedas', 16, 3, '2026-05-26', '19:00', '19:00', '17:00', 'https://discord.gg/ug', 'https://scrim.gg/ugchamp', false, 2],
    ['Liga Mobile Season 5', 'liga', 'squad', 'fase_grupos', 'upcoming', 'Liga oficial Season 5', 'Fase de grupos + mata-mata', 20, 5, '2026-06-01', '20:00', '20:00', '18:00', 'https://discord.gg/liga', 'https://scrim.gg/ligas5', true, 2],
    ['Red Magic Scrim Night', 'scrim', 'squad', 'pontuacao_corrida', 'live', 'Noite de scrims da Red Magic', '3 quedas, todos convidados', 20, 5, '2026-05-26', '22:00', '22:00', '20:00', 'https://discord.gg/rmb', 'https://scrim.gg/rmbnight', false, 2],
    ['Torneio Solo BR', 'torneio', 'solo', 'eliminacao_simples', 'upcoming', 'Torneio individual brasileiro', 'Eliminacao simples, 1v1', 32, 0, '2026-05-31', '19:00', '19:00', '17:00', 'https://discord.gg/solo', 'https://scrim.gg/solobr', true, 2],
    ['4v4 MME Cup', 'campeonato', '4v4', 'chaveamento', 'finished', 'Campeonato 4v4 MME', 'Chaveamento simples', 16, 2, '2026-05-20', '20:00', '20:00', '18:00', 'https://discord.gg/mme', 'https://scrim.gg/mme4v4', false, 2],
    ['Ranqueada Semanal #8', 'ranqueada', 'squad', 'pontuacao_corrida', 'upcoming', 'Ranqueada semanal oficial', '5 quedas, pontuacao completa', 20, 5, '2026-05-29', '21:00', '21:00', '19:00', 'https://discord.gg/ranked', 'https://scrim.gg/ranked8', true, 2],
  ];
  for (const e of evs) {
    await conn.execute(
      `INSERT INTO events (name, type, mode, format, status, description, rules, max_teams, max_reserves, date, time_br, time_ar, time_mx, discord_link, scrim_link, registration_open, season_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      e
    );
  }
  console.log("Events done");

  // Registrations
  const regs = [
    [3, 'Red Devils', 'Devil_King', 'devilking#1234', JSON.stringify([{name:'Devil_King',discord:'devilking#1234',gameId:'RD001'},{name:'Devil_Storm',discord:'devilstorm#5678',gameId:'RD002'},{name:'Devil_Snake',discord:'devilsnake#9012',gameId:'RD003'}]), 1, false, 'approved'],
    [3, 'Underground', 'UG_Leader', 'ugleader#1111', JSON.stringify([{name:'UG_Leader',discord:'ugleader#1111',gameId:'UG001'},{name:'UG_Shadow',discord:'ugshadow#2222',gameId:'UG002'},{name:'UG_Phoenix',discord:'ugphoenix#3333',gameId:'UG003'}]), 2, false, 'approved'],
    [3, 'Devils Mobile League', 'DML_God', 'dmlgod#4444', JSON.stringify([{name:'DML_God',discord:'dmlgod#4444',gameId:'DML001'},{name:'DML_Beast',discord:'dmlbeast#5555',gameId:'DML002'},{name:'DML_Ninja',discord:'dmlninja#6666',gameId:'DML003'}]), 3, false, 'approved'],
    [3, 'Red Magic BR', 'RMB_Magic', 'rmbmagic#7777', JSON.stringify([{name:'RMB_Magic',discord:'rmbmagic#7777',gameId:'RMB001'},{name:'RMB_Fire',discord:'rmbfire#8888',gameId:'RMB002'},{name:'RMB_Ice',discord:'rmbice#9999',gameId:'RMB003'}]), 4, false, 'approved'],
    [3, 'Shadow Squad', 'SS_Shadow', 'ssshadow#0001', JSON.stringify([{name:'SS_Shadow',discord:'ssshadow#0001',gameId:'SS001'},{name:'SS_Night',discord:'ssnight#0002',gameId:'SS002'},{name:'SS_Dark',discord:'ssdark#0003',gameId:'SS003'}]), 5, false, 'approved'],
    [3, 'Phoenix Rising', 'PX_Flame', 'pxflame#1112', JSON.stringify([{name:'PX_Flame',discord:'pxflame#1112',gameId:'PX001'},{name:'PX_Blaze',discord:'pxblaze#1113',gameId:'PX002'},{name:'PX_Ash',discord:'pxash#1114',gameId:'PX003'}]), 6, false, 'approved'],
    [3, 'Ghost Legion', 'GL_Ghost', 'glghost#2223', JSON.stringify([{name:'GL_Ghost',discord:'glghost#2223',gameId:'GL001'},{name:'GL_Spirit',discord:'glspirit#2224',gameId:'GL002'},{name:'GL_Soul',discord:'glsoul#2225',gameId:'GL003'}]), 7, false, 'approved'],
    [3, 'Neon Tigers', 'NT_Tiger', 'nttiger#3334', JSON.stringify([{name:'NT_Tiger',discord:'nttiger#3334',gameId:'NT001'},{name:'NT_Stripe',discord:'ntstripe#3335',gameId:'NT002'},{name:'NT_Claw',discord:'ntclaw#3336',gameId:'NT003'}]), 8, false, 'approved'],
  ];
  for (const r of regs) {
    await conn.execute(
      `INSERT INTO registrations (event_id, team_name, captain_name, captain_discord, players, slot_number, is_reserve, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      r
    );
  }
  console.log("Registrations done");

  // Templates
  const tmps = [
    ['Template Padrão Scrim', `{nome_camp} 🚩\n\nPLATAFORMA: MOBILE 📱\n\nMODO: {modo} 👥\n\n🗓️ - DATA: {data}\n\n⏱️- HORÁRIOS\n\n🇲🇽 {horario_mx}\n🇦🇷 {horario_ar}\n🇧🇷 {horario_br}\n\n🪂| 3 QUEDAS\n\n- SLOTS | EQUIPES\n\n{equipes}\n\nRESERVAS:\n\n{reservas}\n\n⚠️ TODOS AUXÍLIOS BANIDOS\n\nSCRIM:\n{link_scrim}\n\nDISCORD:\n{link_discord}\n\n@todos`, JSON.stringify(['nome_camp','modo','data','horario_mx','horario_ar','horario_br','equipes','reservas','link_scrim','link_discord']), true],
    ['Template Xtrenio', `🏆 {nome_camp} - XTRENO OFICIAL 🏆\n\n📱 PLATAFORMA: MOBILE\n👥 MODO: {modo}\n📅 DATA: {data}\n\n⏰ HORÁRIOS:\n🇧🇷 {horario_br}\n🇦🇷 {horario_ar}\n🇲🇽 {horario_mx}\n\n🎮 4 QUEDAS\n\n📍 EQUIPES INSCRITAS:\n{equipes}\n\n🔗 {link_scrim}\n💬 {link_discord}`, JSON.stringify(['nome_camp','modo','data','horario_br','horario_ar','horario_mx','equipes','link_scrim','link_discord']), false],
    ['Template Campeonato', `🏆 {nome_camp} - CAMPEONATO OFICIAL 🏆\n\n📱 PLATAFORMA: MOBILE\n👥 MODO: {modo}\n📅 DATA: {data}\n🎯 FORMATO: {formato}\n\n⏰ HORÁRIOS:\n🇧🇷 {horario_br}\n🇦🇷 {horario_ar}\n🇲🇽 {horario_mx}\n\n📍 PARTICIPANTES:\n{equipes}\n\n🔗 {link_scrim}\n💬 {link_discord}\n\n🏅 PREMIAÇÃO EM BREVE`, JSON.stringify(['nome_camp','modo','data','formato','horario_br','horario_ar','horario_mx','equipes','link_scrim','link_discord']), false],
  ];
  for (const t of tmps) {
    await conn.execute(
      `INSERT INTO templates (name, content, variables, is_default) VALUES (?, ?, ?, ?)`,
      t
    );
  }
  console.log("Templates done");

  await conn.end();
  console.log("Seed complete!");
}

seed().catch(console.error);
