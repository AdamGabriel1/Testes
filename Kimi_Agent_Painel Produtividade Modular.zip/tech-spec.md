# Tech Spec — Modular Pro Canvas

## Dependências

| Pacote | Versão | Finalidade |
|--------|--------|------------|
| react | ^19.0 | Framework UI |
| react-dom | ^19.0 | Renderização DOM |
| vite | ^6.0 | Bundler / dev server |
| @vitejs/plugin-react | ^4.4 | Plugin React para Vite |
| tailwindcss | ^4.0 | Estilização utilitária |
| @tailwindcss/vite | ^4.0 | Integração Tailwind + Vite |
| typescript | ^5.7 | Tipagem estática |
| @types/react | ^19.0 | Tipos React |
| @types/react-dom | ^19.0 | Tipos React DOM |
| @dnd-kit/core | ^6.3 | Core drag-and-drop (Kanban) |
| @dnd-kit/sortable | ^10.0 | Sortable lists (Kanban cards) |
| @dnd-kit/utilities | ^3.2 | Utilitários DnD (CSS transforms) |
| date-fns | ^4.1 | Cálculos e formatação de datas (Calendário) |
| framer-motion | ^12.0 | Animações (layout, cards, spring) |
| sonner | ^2.0 | Toast notifications |
| lucide-react | ^0.469 | Ícones (monocromáticos) |
| uuid | ^11.0 | Geração de IDs únicos |
| @types/uuid | ^10.0 | Tipos uuid |

## Inventário de Componentes

### Layout (compartilhados)

| Componente | Fonte | Reutilização |
|------------|-------|-------------|
| Sidebar | Custom | Único — menu lateral retrátil com navegação, badge de tarefas, toggle collapse |
| WidgetContainer | Custom | Wrapper padrão para todos os 5 módulos — chrome, header, collapse/expand, drag handle |
| FooterStatusBar | Custom | Único — barra de status com save indicator e hora |

### Módulos

| Componente | Fonte | Notas |
|------------|-------|-------|
| KanbanBoard | Custom | Container das 3 colunas + lógica DnD |
| KanbanColumn | Custom | Sub-componente de coluna — lista de cards, área de drop |
| KanbanCard | Custom | Card individual — view / edit inline modes |
| KanbanCardForm | Custom | Form de criação/edição inline — reutilizado entre criar e editar |
| CalendarWidget | Custom | Grid mensal + painel de detalhes do dia selecionado |
| CalendarDayCell | Custom | Célula individual do calendário |
| CalendarDayPanel | Custom | Painel inferior — tarefas do dia + lembretes |
| RichTextEditor | Custom | Editor contentEditable com toolbar e formatação |
| PomodoroTimer | Custom | Timer com SVG progress ring, controles, tabs de modo |
| HabitTracker | Custom | Lista de hábitos + progress bar |

### Hooks

| Hook | Finalidade |
|------|-----------|
| useAppState | Gerencia o state global unificado, auto-save debounced, load/save localStorage |
| usePomodoro | Lógica do timer: countdown, play/pause/reset, auto-switch de modo, beep no complete |
| useAudioBeep | Web Audio API — gera beep 880Hz quando timer completa |

### State Management

**React Context + useReducer** — um único `AppStateContext` fornece o state global e dispatch para toda a árvore. Motivação: 5 módulos compartilham um state unificado (JSON serializável) com alta frequência de atualizações cruzadas (Kanban ↔ Calendar via dueDate, sidebar badge lê Kanban). useReducer centraliza todas as mutações em um reducer tipado.

**Formato do State:**

```typescript
interface AppState {
  version: number;
  kanban: {
    todo: KanbanCard[];
    inprogress: KanbanCard[];
    done: KanbanCard[];
  };
  calendar: {
    reminders: Record<string, string[]>; // key: "YYYY-MM-DD"
  };
  editor: {
    content: string; // HTML string
  };
  pomodoro: {
    mode: 'focus' | 'shortBreak';
    timeLeft: number; // segundos
  };
  habits: {
    items: HabitItem[];
  };
  sidebar: {
    collapsed: boolean;
    activeModule: string;
  };
}
```

**Actions do Reducer:**
- `KANBAN_ADD_CARD` / `KANBAN_UPDATE_CARD` / `KANBAN_DELETE_CARD` / `KANBAN_MOVE_CARD` — CRUD + DnD
- `CALENDAR_SET_REMINDER` / `CALENDAR_DELETE_REMINDER`
- `EDITOR_SET_CONTENT`
- `POMODORO_SET_TIME` / `POMODORO_SET_MODE`
- `HABIT_ADD` / `HABIT_TOGGLE` / `HABIT_DELETE` / `HABIT_SET_LABEL`
- `SIDEBAR_TOGGLE` / `SIDEBAR_SET_MODULE`
- `RESET_ALL`

### Planos de Animação

| Animação | Biblioteca | Abordagem | Complexidade |
|----------|-----------|-----------|-------------|
| Sidebar expand/collapse | Framer Motion | `animate={{ width }}` com `transition={{ type: "tween", duration: 0.25 }}` | Baixa |
| Widget grid reflow | Framer Motion | `motion.div` com `layout` prop — reposicionamento automático ao colapsar widget | Baixa |
| Card drag lift | @dnd-kit + CSS | `transform` via DnD kit + `shadow-elevated` e `scale(1.02)` no drag overlay | Baixa |
| Card placeholder | CSS | Skeleton com `--bg-quaternary` + border dashed, opacity 0.5 | Baixa |
| Card drop spring | Framer Motion | `layoutId` ou spring transition no re-render após reordenação | Média |
| Column highlight on hover | CSS | `background-color` transition quando `isOver` do DnD | Baixa |
| Progress ring fill | SVG + CSS | `stroke-dashoffset` animado via CSS transition ou JS a cada segundo | Baixa |
| Timer complete pulse | Framer Motion | `animate={{ scale: [1, 1.05, 1] }}` com repeat no SVG circle | Baixa |
| Progress bar fill | CSS | `width` transition `smooth` (0.3s) a cada toggle de hábito | Baixa |
| Toast notifications | Sonner | API nativa do Sonner — sem animação customizada | Baixa |
| Save indicator pulse | CSS | `opacity` animation no dot durante debounce | Baixa |
| Chevron rotation | CSS | `transform: rotate(180deg)` transition `fast` | Baixa |

**Nota:** Não há animações de alta complexidade (scroll-driven, 3D, canvas). Todas as animações são ou CSS transitions simples ou Framer Motion layout animations. O @dnd-kit já fornece as transforms de drag nativamente.

## Decisões Técnicas Críticas

### Rich Text: contentEditable manual (não biblioteca)

O editor usa `contentEditable` + `document.execCommand` para formatação (bold, italic, underline, lists) e armazena HTML como string. Justificativa: os requisitos são básicos (formatação simples, bullet/checkbox lists). Uma biblioteca como TipTap ou Slate adicionaria ~50-100KB de bundle para funcionalidade que `execCommand` cobre adequadamente. O HTML é sanitizado implicitamente ao renderizar (innerHTML em contentEditable). O conteúdo é salvo como string HTML no localStorage.

### DnD: @dnd-kit (não react-beautiful-dnd)

@dnd-kit é escolhido por: (a) suporte nativo a múltiplas listas (columns), (b) acessibilidade completa (keyboard sorting), (c) menor bundle que react-beautiful-dnd, (d) compatível com React 19. A arquitetura usa `DndContext` wrapper + `SortableContext` por coluna + `useSortable` por card.

### Persistência: localStorage com debounce

Todas as actions do reducer acionam um efeito colateral de save via `useEffect`. O save é debounced em 500ms usando `setTimeout` — evita writes excessivos. A serialização é `JSON.stringify(state)` completo a cada save. No load (mount), `JSON.parse(localStorage.getItem('modular_pro_state'))` ou fallback para dados demo.

### Pomodoro: Web Audio API para beep

Ao invés de arquivo de áudio, usa `AudioContext` + `OscillatorNode` (880Hz, sine wave, 0.2s) — zero dependências externas, instantâneo, funciona offline. Hook `useAudioBeep` encapsula criação do context e playback.

### Responsive: grid CSS puro (não masonry)

O layout usa `grid-template-columns: repeat(auto-fill, minmax(300px, 1fr))` com `grid-column: span N` nos widgets. Kanban usa `span 3` (full width). Em mobile (`<768px`), single column com `span 1` forçado. Não requer biblioteca de masonry — o grid CSS nativo com spanning é suficiente para este layout.
