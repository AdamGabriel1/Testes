import { useState, useEffect, useRef, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Play, Pause, RotateCcw, SkipForward } from 'lucide-react';
import { toast } from 'sonner';
import { useAppState } from '@/hooks/useAppState';
import { useAudioBeep } from '@/hooks/useAudioBeep';

const MODES = {
  focus: { label: 'Foco', minutes: 25, seconds: 1500 },
  shortBreak: { label: 'Pausa Curta', minutes: 5, seconds: 300 },
};

const RADIUS = 54;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

export function PomodoroTimer() {
  const { state, dispatch } = useAppState();
  const playBeep = useAudioBeep();

  const [isRunning, setIsRunning] = useState(false);
  const [timeLeft, setTimeLeft] = useState(state.pomodoro.timeLeft);
  const [mode, setMode] = useState(state.pomodoro.mode);
  const [showPulse, setShowPulse] = useState(false);

  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const totalTime = MODES[mode].seconds;

  // Sync with global state on mount
  useEffect(() => {
    setTimeLeft(state.pomodoro.timeLeft);
    setMode(state.pomodoro.mode);
  }, []);

  // Timer countdown
  useEffect(() => {
    if (isRunning && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          const next = prev - 1;
          dispatch({ type: 'POMODORO_SET_TIME', timeLeft: next });
          return next;
        });
      }, 1000);
    } else if (timeLeft === 0 && isRunning) {
      setIsRunning(false);
      handleComplete();
    }

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isRunning, timeLeft === 0]);

  const handleComplete = useCallback(() => {
    playBeep();
    setShowPulse(true);
    toast('Tempo finalizado!');

    // Auto-switch after 3 seconds
    setTimeout(() => {
      const nextMode = mode === 'focus' ? 'shortBreak' : 'focus';
      const nextTime = MODES[nextMode].seconds;
      setMode(nextMode);
      setTimeLeft(nextTime);
      dispatch({ type: 'POMODORO_SET_MODE', mode: nextMode, timeLeft: nextTime });
      setShowPulse(false);
    }, 3000);
  }, [mode, playBeep, dispatch]);

  const toggleTimer = () => {
    setIsRunning(!isRunning);
  };

  const resetTimer = () => {
    setIsRunning(false);
    const resetTime = MODES[mode].seconds;
    setTimeLeft(resetTime);
    dispatch({ type: 'POMODORO_SET_TIME', timeLeft: resetTime });
  };

  const switchMode = (newMode: 'focus' | 'shortBreak') => {
    if (newMode === mode) return;
    setIsRunning(false);
    setMode(newMode);
    const newTime = MODES[newMode].seconds;
    setTimeLeft(newTime);
    dispatch({ type: 'POMODORO_SET_MODE', mode: newMode, timeLeft: newTime });
  };

  const progress = (timeLeft / totalTime) * CIRCUMFERENCE;
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <div className="flex flex-col items-center gap-4">
      {/* Mode tabs */}
      <div
        className="flex rounded-full p-0.5"
        style={{ backgroundColor: 'var(--bg-tertiary)' }}
      >
        {(['focus', 'shortBreak'] as const).map((m) => (
          <button
            key={m}
            onClick={() => switchMode(m)}
            className="px-4 py-1.5 rounded-full text-xs font-medium transition-all"
            style={{
              backgroundColor: mode === m ? 'var(--accent)' : 'transparent',
              color: mode === m ? 'var(--bg-primary)' : 'var(--text-secondary)',
            }}
          >
            {MODES[m].label}
          </button>
        ))}
      </div>

      {/* Timer display with progress ring */}
      <div className="relative flex items-center justify-center">
        <svg width="140" height="140" className="-rotate-90">
          {/* Track */}
          <circle
            cx="70"
            cy="70"
            r={RADIUS}
            fill="none"
            stroke="var(--bg-quaternary)"
            strokeWidth="4"
          />
          {/* Progress */}
          <motion.circle
            cx="70"
            cy="70"
            r={RADIUS}
            fill="none"
            stroke="var(--accent)"
            strokeWidth="4"
            strokeLinecap="round"
            strokeDasharray={CIRCUMFERENCE}
            animate={{
              strokeDashoffset: CIRCUMFERENCE - progress,
              scale: showPulse ? [1, 1.05, 1] : 1,
            }}
            transition={{
              strokeDashoffset: { duration: 0.5, ease: 'easeOut' },
              scale: showPulse ? { duration: 0.6, repeat: 2 } : { duration: 0 },
            }}
          />
        </svg>

        {/* Digital display */}
        <div className="absolute flex flex-col items-center">
          <span
            className="font-mono text-5xl font-medium tracking-tight"
            style={{ color: 'var(--text-primary)' }}
          >
            {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
          </span>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-3">
        {/* Play/Pause */}
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={toggleTimer}
          className="w-11 h-11 rounded-full flex items-center justify-center transition-all"
          style={{
            backgroundColor: isRunning ? 'var(--bg-tertiary)' : 'var(--accent)',
            color: isRunning ? 'var(--text-secondary)' : 'var(--bg-primary)',
          }}
        >
          {isRunning ? <Pause size={18} /> : <Play size={18} className="ml-0.5" />}
        </motion.button>

        {/* Reset */}
        <button
          onClick={resetTimer}
          className="w-9 h-9 rounded-full flex items-center justify-center transition-all"
          style={{
            backgroundColor: 'var(--bg-tertiary)',
            color: 'var(--text-secondary)',
            border: '1px solid var(--border-subtle)',
          }}
          onMouseEnter={(e) => (e.currentTarget.style.borderColor = 'var(--border-active)')}
          onMouseLeave={(e) => (e.currentTarget.style.borderColor = 'var(--border-subtle)')}
        >
          <RotateCcw size={14} />
        </button>

        {/* Skip (show in break mode) */}
        {mode === 'shortBreak' && (
          <button
            onClick={() => switchMode('focus')}
            className="w-9 h-9 rounded-full flex items-center justify-center transition-all"
            style={{
              backgroundColor: 'var(--bg-tertiary)',
              color: 'var(--text-secondary)',
              border: '1px solid var(--border-subtle)',
            }}
            onMouseEnter={(e) => (e.currentTarget.style.borderColor = 'var(--border-active)')}
            onMouseLeave={(e) => (e.currentTarget.style.borderColor = 'var(--border-subtle)')}
          >
            <SkipForward size={14} />
          </button>
        )}
      </div>
    </div>
  );
}
