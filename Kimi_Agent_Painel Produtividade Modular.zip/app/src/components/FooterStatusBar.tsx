import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useAppState } from '@/hooks/useAppState';

export function FooterStatusBar() {
  const { saveStatus } = useAppState();
  const [currentTime, setCurrentTime] = useState('');

  useEffect(() => {
    const update = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
      );
    };
    update();
    const interval = setInterval(update, 60000);
    return () => clearInterval(interval);
  }, []);

  return (
    <footer
      className="flex items-center justify-between px-4 py-1.5 text-[11px] border-t shrink-0"
      style={{
        backgroundColor: 'var(--bg-secondary)',
        borderColor: 'var(--border-subtle)',
        color: 'var(--text-tertiary)',
      }}
    >
      <span>Modular Pro v1.0</span>

      <div className="flex items-center gap-1.5">
        <motion.span
          animate={{
            opacity: saveStatus === 'saving' ? [1, 0.3, 1] : 1,
          }}
          transition={{
            duration: 0.8,
            repeat: saveStatus === 'saving' ? Infinity : 0,
          }}
          className="w-1.5 h-1.5 rounded-full"
          style={{
            backgroundColor: saveStatus === 'saved' ? 'var(--success)' : 'var(--accent)',
          }}
        />
        <span>{saveStatus === 'saved' ? 'Salvo' : 'Salvando...'}</span>
      </div>

      <span className="font-mono">{currentTime}</span>
    </footer>
  );
}
