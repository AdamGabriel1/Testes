import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard,
  Columns3,
  CalendarDays,
  FileText,
  Timer,
  Target,
  ChevronLeft,
  Trash2,
  AlertTriangle,
} from 'lucide-react';
import { useAppState } from '@/hooks/useAppState';

const modules = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'kanban', label: 'Kanban', icon: Columns3 },
  { id: 'calendar', label: 'Calendário', icon: CalendarDays },
  { id: 'editor', label: 'Editor', icon: FileText },
  { id: 'pomodoro', label: 'Pomodoro', icon: Timer },
  { id: 'habits', label: 'Metas', icon: Target },
];

export function Sidebar() {
  const { state, dispatch, saveStatus } = useAppState();
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const collapsed = state.sidebar.collapsed;
  const pendingCount = state.kanban.todo.length + state.kanban.inprogress.length;

  return (
    <>
      <motion.aside
        animate={{ width: collapsed ? 56 : 220 }}
        transition={{ type: 'tween', duration: 0.25, ease: [0.4, 0, 0.2, 1] }}
        className="flex flex-col h-screen shrink-0 border-r overflow-hidden relative z-20"
        style={{
          backgroundColor: 'var(--bg-secondary)',
          borderColor: 'var(--border-subtle)',
        }}
      >
        {/* Toggle button */}
        <div className="flex items-center justify-end p-2 h-12">
          <button
            onClick={() => dispatch({ type: 'SIDEBAR_TOGGLE' })}
            className="w-8 h-8 rounded-md flex items-center justify-center transition-colors"
            style={{ color: 'var(--text-tertiary)' }}
            onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'var(--bg-tertiary)')}
            onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
            aria-label={collapsed ? 'Expandir sidebar' : 'Recolher sidebar'}
          >
            <motion.div
              animate={{ rotate: collapsed ? 180 : 0 }}
              transition={{ duration: 0.2 }}
            >
              <ChevronLeft size={16} />
            </motion.div>
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-2 space-y-1">
          {modules.map((mod) => {
            const Icon = mod.icon;
            const isActive = state.sidebar.activeModule === mod.id;
            return (
              <button
                key={mod.id}
                onClick={() => dispatch({ type: 'SIDEBAR_SET_MODULE', module: mod.id })}
                className="w-full flex items-center gap-3 px-2.5 py-2 rounded-md transition-all relative group"
                style={{
                  backgroundColor: isActive ? 'var(--accent-muted)' : 'transparent',
                  color: isActive ? 'var(--accent)' : 'var(--text-secondary)',
                }}
                onMouseEnter={(e) => {
                  if (!isActive) e.currentTarget.style.backgroundColor = 'var(--bg-tertiary)';
                }}
                onMouseLeave={(e) => {
                  if (!isActive) e.currentTarget.style.backgroundColor = 'transparent';
                }}
              >
                <Icon size={18} />
                <AnimatePresence>
                  {!collapsed && (
                    <motion.span
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.15 }}
                      className="text-sm font-medium whitespace-nowrap"
                    >
                      {mod.label}
                    </motion.span>
                  )}
                </AnimatePresence>
                {mod.id === 'kanban' && pendingCount > 0 && (
                  <span
                    className="ml-auto text-xs font-semibold px-1.5 py-0.5 rounded-full"
                    style={{
                      backgroundColor: 'var(--accent)',
                      color: 'var(--bg-primary)',
                      fontSize: collapsed ? 8 : 10,
                      padding: collapsed ? '1px 3px' : undefined,
                      minWidth: collapsed ? 8 : 20,
                      height: collapsed ? 8 : 20,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    {!collapsed && pendingCount}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="px-2 pb-3 space-y-2">
          <AnimatePresence>
            {!collapsed && saveStatus === 'saved' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex items-center gap-1.5 px-2.5 py-1"
              >
                <span
                  className="w-1.5 h-1.5 rounded-full"
                  style={{ backgroundColor: 'var(--success)' }}
                />
                <span style={{ color: 'var(--text-tertiary)', fontSize: 11 }}>
                  Salvo
                </span>
              </motion.div>
            )}
          </AnimatePresence>

          <button
            onClick={() => setShowResetConfirm(true)}
            className="w-full flex items-center gap-3 px-2.5 py-2 rounded-md transition-colors"
            style={{ color: 'var(--text-tertiary)' }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'rgba(196, 129, 122, 0.15)';
              e.currentTarget.style.color = 'var(--error)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'transparent';
              e.currentTarget.style.color = 'var(--text-tertiary)';
            }}
          >
            <Trash2 size={16} />
            <AnimatePresence>
              {!collapsed && (
                <motion.span
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.15 }}
                  className="text-sm whitespace-nowrap"
                >
                  Resetar Dados
                </motion.span>
              )}
            </AnimatePresence>
          </button>
        </div>
      </motion.aside>

      {/* Reset confirmation dialog */}
      <AnimatePresence>
        {showResetConfirm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center"
            style={{ backgroundColor: 'rgba(0,0,0,0.6)' }}
            onClick={() => setShowResetConfirm(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="rounded-lg p-6 max-w-sm w-full mx-4"
              style={{
                backgroundColor: 'var(--bg-secondary)',
                border: '1px solid var(--border-subtle)',
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center gap-3 mb-4">
                <AlertTriangle size={20} style={{ color: 'var(--warning)' }} />
                <h3 className="text-base font-semibold" style={{ color: 'var(--text-primary)' }}>
                  Resetar todos os dados?
                </h3>
              </div>
              <p className="text-sm mb-6" style={{ color: 'var(--text-secondary)' }}>
                Isso apagará todos os dados permanentemente. Esta ação não pode ser desfeita.
              </p>
              <div className="flex justify-end gap-2">
                <button
                  onClick={() => setShowResetConfirm(false)}
                  className="px-3 py-1.5 rounded-md text-sm transition-colors"
                  style={{ color: 'var(--text-secondary)' }}
                  onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'var(--bg-tertiary)')}
                  onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
                >
                  Cancelar
                </button>
                <button
                  onClick={() => {
                    dispatch({ type: 'RESET_ALL' });
                    setShowResetConfirm(false);
                  }}
                  className="px-3 py-1.5 rounded-md text-sm font-medium transition-colors"
                  style={{ backgroundColor: 'var(--error)', color: 'white' }}
                  onMouseEnter={(e) => (e.currentTarget.style.opacity = '0.9')}
                  onMouseLeave={(e) => (e.currentTarget.style.opacity = '1')}
                >
                  Confirmar
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
