import { useState, useMemo } from 'react';
import {
  format,
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  isSameMonth,
  isSameDay,
  addMonths,
  subMonths,
  isToday,
} from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { ChevronLeft, ChevronRight, Plus, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppState } from '@/hooks/useAppState';
import type { KanbanCardData } from '@/types';

export function CalendarWidget() {
  const { state, dispatch } = useAppState();
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [newReminder, setNewReminder] = useState('');

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const calendarStart = startOfWeek(monthStart, { weekStartsOn: 1 });
  const calendarEnd = endOfWeek(monthEnd, { weekStartsOn: 1 });
  const days = eachDayOfInterval({ start: calendarStart, end: calendarEnd });

  const selectedDateStr = useMemo(
    () => format(selectedDate, 'yyyy-MM-dd'),
    [selectedDate]
  );

  const reminders = state.calendar.reminders[selectedDateStr] || [];

  // Find kanban tasks due on selected date
  const dueTasks: { card: KanbanCardData; column: string }[] = useMemo(() => {
    const result: { card: KanbanCardData; column: string }[] = [];
    (['todo', 'inprogress', 'done'] as const).forEach((col) => {
      state.kanban[col].forEach((card) => {
        if (card.dueDate === selectedDateStr) {
          result.push({ card, column: col });
        }
      });
    });
    return result;
  }, [state.kanban, selectedDateStr]);

  // Days with reminders
  const daysWithReminders = useMemo(() => {
    const set = new Set<string>();
    Object.keys(state.calendar.reminders).forEach((date) => {
      if (state.calendar.reminders[date].length > 0) {
        set.add(date);
      }
    });
    return set;
  }, [state.calendar.reminders]);

  const handleAddReminder = () => {
    if (!newReminder.trim()) return;
    dispatch({
      type: 'CALENDAR_SET_REMINDER',
      date: selectedDateStr,
      reminder: newReminder.trim(),
    });
    setNewReminder('');
  };

  const handleDeleteReminder = (index: number) => {
    dispatch({
      type: 'CALENDAR_DELETE_REMINDER',
      date: selectedDateStr,
      index,
    });
  };

  const weekDays = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];

  return (
    <div className="space-y-3">
      {/* Month header */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>
          {format(currentMonth, 'MMMM yyyy', { locale: ptBR })}
        </h3>
        <div className="flex gap-1">
          <button
            onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
            className="w-7 h-7 rounded-md flex items-center justify-center transition-colors"
            style={{ color: 'var(--text-tertiary)' }}
            onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'var(--bg-tertiary)')}
            onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
          >
            <ChevronLeft size={14} />
          </button>
          <button
            onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
            className="w-7 h-7 rounded-md flex items-center justify-center transition-colors"
            style={{ color: 'var(--text-tertiary)' }}
            onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'var(--bg-tertiary)')}
            onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
          >
            <ChevronRight size={14} />
          </button>
        </div>
      </div>

      {/* Weekday labels */}
      <div className="grid grid-cols-7 gap-0">
        {weekDays.map((day) => (
          <div
            key={day}
            className="text-center text-[10px] font-medium py-1"
            style={{ color: 'var(--text-tertiary)' }}
          >
            {day}
          </div>
        ))}
      </div>

      {/* Days grid */}
      <div className="grid grid-cols-7 gap-0.5">
        {days.map((day) => {
          const dateStr = format(day, 'yyyy-MM-dd');
          const isSelected = isSameDay(day, selectedDate);
          const isCurrentMonth = isSameMonth(day, currentMonth);
          const isTodayDate = isToday(day);
          const hasReminder = daysWithReminders.has(dateStr);

          return (
            <button
              key={dateStr}
              onClick={() => setSelectedDate(day)}
              className="relative w-full aspect-square flex items-center justify-center rounded-md text-xs transition-all"
              style={{
                backgroundColor: isSelected
                  ? 'var(--accent)'
                  : isTodayDate
                  ? 'var(--accent-muted)'
                  : 'transparent',
                color: isSelected
                  ? 'var(--bg-primary)'
                  : !isCurrentMonth
                  ? 'var(--text-tertiary)'
                  : isTodayDate
                  ? 'var(--accent)'
                  : 'var(--text-secondary)',
                opacity: !isCurrentMonth ? 0.4 : 1,
                fontWeight: isTodayDate || isSelected ? 600 : 400,
              }}
              onMouseEnter={(e) => {
                if (!isSelected && !isTodayDate) {
                  e.currentTarget.style.backgroundColor = 'var(--bg-tertiary)';
                }
              }}
              onMouseLeave={(e) => {
                if (!isSelected && !isTodayDate) {
                  e.currentTarget.style.backgroundColor = 'transparent';
                }
              }}
            >
              {format(day, 'd')}
              {hasReminder && (
                <span
                  className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full"
                  style={{ backgroundColor: isSelected ? 'var(--bg-primary)' : 'var(--accent)' }}
                />
              )}
            </button>
          );
        })}
      </div>

      {/* Selected day panel */}
      <div
        className="rounded-md p-3 space-y-3"
        style={{ backgroundColor: 'var(--bg-primary)', border: '1px solid var(--border-subtle)' }}
      >
        <h4 className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>
          {format(selectedDate, "dd 'de' MMMM", { locale: ptBR })}
        </h4>

        {/* Due tasks */}
        {dueTasks.length > 0 && (
          <div>
            <p className="text-[10px] font-medium uppercase tracking-wider mb-1.5" style={{ color: 'var(--text-tertiary)' }}>
              Tarefas do dia
            </p>
            <div className="space-y-1">
              {dueTasks.map(({ card, column }) => (
                <div
                  key={card.id}
                  className="flex items-center gap-2 text-xs py-1 px-2 rounded"
                  style={{ backgroundColor: 'var(--bg-tertiary)' }}
                >
                  <span
                    className="w-1.5 h-1.5 rounded-full shrink-0"
                    style={{
                      backgroundColor:
                        column === 'todo' ? 'var(--error)' : column === 'inprogress' ? 'var(--accent)' : 'var(--success)',
                    }}
                  />
                  <span className="truncate" style={{ color: 'var(--text-secondary)' }}>
                    {card.title}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Reminders */}
        <div>
          <p className="text-[10px] font-medium uppercase tracking-wider mb-1.5" style={{ color: 'var(--text-tertiary)' }}>
            Lembretes
          </p>
          <AnimatePresence>
            {reminders.map((reminder, index) => (
              <motion.div
                key={`${selectedDateStr}-${index}`}
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="flex items-center gap-2 text-xs py-1 group"
              >
                <span className="flex-1" style={{ color: 'var(--text-secondary)' }}>
                  {reminder}
                </span>
                <button
                  onClick={() => handleDeleteReminder(index)}
                  className="opacity-0 group-hover:opacity-100 transition-opacity p-0.5 rounded"
                  style={{ color: 'var(--text-tertiary)' }}
                  onMouseEnter={(e) => (e.currentTarget.style.color = 'var(--error)')}
                >
                  <X size={12} />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>

          {/* Add reminder */}
          <div className="flex gap-1.5 mt-2">
            <input
              value={newReminder}
              onChange={(e) => setNewReminder(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddReminder()}
              placeholder="Novo lembrete..."
              className="flex-1 bg-transparent text-xs outline-none placeholder:text-[var(--text-tertiary)] py-1 px-2 rounded-md"
              style={{
                color: 'var(--text-primary)',
                backgroundColor: 'var(--bg-tertiary)',
                border: '1px solid var(--border-subtle)',
              }}
            />
            <button
              onClick={handleAddReminder}
              className="w-6 h-6 rounded-md flex items-center justify-center transition-colors"
              style={{ color: 'var(--accent)' }}
              onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'var(--accent-muted)')}
              onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
            >
              <Plus size={14} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
