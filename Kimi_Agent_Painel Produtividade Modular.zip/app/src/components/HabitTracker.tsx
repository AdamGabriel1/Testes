import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, X, CheckCircle2 } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import { toast } from 'sonner';
import { useAppState } from '@/hooks/useAppState';

export function HabitTracker() {
  const { state, dispatch } = useAppState();
  const [newHabit, setNewHabit] = useState('');

  const habits = state.habits.items;
  const completedCount = habits.filter((h) => h.completed).length;
  const totalCount = habits.length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;
  const allComplete = totalCount > 0 && completedCount === totalCount;

  const handleAddHabit = () => {
    if (!newHabit.trim()) return;
    dispatch({
      type: 'HABIT_ADD',
      habit: { id: uuidv4(), label: newHabit.trim(), completed: false },
    });
    setNewHabit('');
  };

  const handleToggle = (id: string) => {
    dispatch({ type: 'HABIT_TOGGLE', habitId: id });

    // Check if this toggle made all complete
    const target = habits.find((h) => h.id === id);
    if (target && !target.completed) {
      const newCompleted = completedCount + 1;
      if (newCompleted === totalCount && totalCount > 0) {
        toast('Todas as metas concluídas!');
      }
    }
  };

  const handleDelete = (id: string) => {
    dispatch({ type: 'HABIT_DELETE', habitId: id });
  };

  return (
    <div className="space-y-3">
      {/* Header with progress */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>
          Metas do Dia
        </h3>
        <span
          className="text-xs font-medium"
          style={{ color: allComplete ? 'var(--success)' : 'var(--accent)' }}
        >
          {progressPercent}%
        </span>
      </div>

      {/* Progress bar */}
      <div
        className="w-full h-1.5 rounded-full overflow-hidden"
        style={{ backgroundColor: 'var(--bg-quaternary)' }}
      >
        <motion.div
          className="h-full rounded-full"
          style={{
            backgroundColor: allComplete ? 'var(--success)' : 'var(--accent)',
          }}
          animate={{ width: `${progressPercent}%` }}
          transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
        />
      </div>

      {/* All complete message */}
      <AnimatePresence>
        {allComplete && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="flex items-center gap-1.5 text-xs"
            style={{ color: 'var(--success)' }}
          >
            <CheckCircle2 size={14} />
            <span>Todas as metas concluídas!</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Habits list */}
      <div className="space-y-1 max-h-[200px] overflow-y-auto">
        <AnimatePresence initial={false}>
          {habits.map((habit) => (
            <motion.div
              key={habit.id}
              layout
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="flex items-center gap-2.5 py-1.5 px-1 rounded-md group transition-colors"
              onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'var(--bg-tertiary)')}
              onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
            >
              {/* Checkbox */}
              <button
                onClick={() => handleToggle(habit.id)}
                className="w-[18px] h-[18px] rounded flex items-center justify-center shrink-0 transition-all"
                style={{
                  backgroundColor: habit.completed ? 'var(--accent)' : 'var(--bg-tertiary)',
                  border: `1px solid ${habit.completed ? 'var(--accent)' : 'var(--border-subtle)'}`,
                }}
                onMouseEnter={(e) => {
                  if (!habit.completed) e.currentTarget.style.borderColor = 'var(--border-active)';
                }}
                onMouseLeave={(e) => {
                  if (!habit.completed) e.currentTarget.style.borderColor = 'var(--border-subtle)';
                }}
              >
                {habit.completed && (
                  <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
                    <path
                      d="M2 5L4 7L8 3"
                      stroke="white"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                )}
              </button>

              {/* Label */}
              <span
                className="text-xs flex-1 transition-all"
                style={{
                  color: habit.completed ? 'var(--text-tertiary)' : 'var(--text-primary)',
                  textDecoration: habit.completed ? 'line-through' : 'none',
                }}
              >
                {habit.label}
              </span>

              {/* Delete button */}
              <button
                onClick={() => handleDelete(habit.id)}
                className="opacity-0 group-hover:opacity-100 transition-all p-0.5 rounded"
                style={{ color: 'var(--text-tertiary)' }}
                onMouseEnter={(e) => (e.currentTarget.style.color = 'var(--error)')}
              >
                <X size={12} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Add habit */}
      <div className="flex gap-1.5">
        <input
          value={newHabit}
          onChange={(e) => setNewHabit(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleAddHabit()}
          placeholder="Nova meta..."
          className="flex-1 bg-transparent text-xs outline-none placeholder:text-[var(--text-tertiary)] py-1.5 px-2 rounded-md"
          style={{
            color: 'var(--text-primary)',
            backgroundColor: 'var(--bg-tertiary)',
            border: '1px solid var(--border-subtle)',
          }}
        />
        <button
          onClick={handleAddHabit}
          className="w-7 h-7 rounded-md flex items-center justify-center transition-colors shrink-0"
          style={{ color: 'var(--accent)' }}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'var(--accent-muted)')}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
        >
          <Plus size={16} />
        </button>
      </div>
    </div>
  );
}
