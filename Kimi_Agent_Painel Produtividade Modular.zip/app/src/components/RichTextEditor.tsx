import { useRef, useCallback, useState, useEffect } from 'react';
import {
  Bold,
  Italic,
  Underline,
  List,
  CheckSquare,
  ClipboardCopy,
} from 'lucide-react';
import { toast } from 'sonner';
import { useAppState } from '@/hooks/useAppState';

const toolbarButtons = [
  { command: 'bold', icon: Bold, label: 'Negrito' },
  { command: 'italic', icon: Italic, label: 'Itálico' },
  { command: 'underline', icon: Underline, label: 'Sublinhado' },
  { divider: true as const },
  { command: 'insertUnorderedList', icon: List, label: 'Lista' },
  { command: 'checklist', icon: CheckSquare, label: 'Checklist' },
];

export function RichTextEditor() {
  const { state, dispatch } = useAppState();
  const editorRef = useRef<HTMLDivElement>(null);
  const [activeFormats, setActiveFormats] = useState<Set<string>>(new Set());

  // Initialize content
  useEffect(() => {
    if (editorRef.current && editorRef.current.innerHTML !== state.editor.content) {
      editorRef.current.innerHTML = state.editor.content;
    }
  }, []);

  const updateActiveFormats = useCallback(() => {
    const formats = new Set<string>();
    if (document.queryCommandState('bold')) formats.add('bold');
    if (document.queryCommandState('italic')) formats.add('italic');
    if (document.queryCommandState('underline')) formats.add('underline');
    setActiveFormats(formats);
  }, []);

  const handleFormat = useCallback(
    (command: string) => {
      if (command === 'checklist') {
        insertChecklist();
      } else {
        document.execCommand(command, false);
        editorRef.current?.focus();
      }
      updateActiveFormats();
    },
    [updateActiveFormats]
  );

  const insertChecklist = () => {
    const editor = editorRef.current;
    if (!editor) return;

    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) return;

    const range = selection.getRangeAt(0);
    const ul = document.createElement('ul');
    ul.className = 'checklist';

    const li = document.createElement('li');
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.addEventListener('change', (e) => {
      const span = (e.target as HTMLInputElement).nextElementSibling as HTMLSpanElement;
      if (span) {
        if ((e.target as HTMLInputElement).checked) {
          span.style.textDecoration = 'line-through';
          span.style.color = 'var(--text-tertiary)';
        } else {
          span.style.textDecoration = 'none';
          span.style.color = 'var(--text-primary)';
        }
      }
    });

    const span = document.createElement('span');
    span.textContent = '\u00A0';
    span.contentEditable = 'true';

    li.appendChild(checkbox);
    li.appendChild(span);
    ul.appendChild(li);

    range.deleteContents();
    range.insertNode(ul);

    // Place cursor in the span
    const newRange = document.createRange();
    newRange.setStart(span, 0);
    newRange.collapse(true);
    selection.removeAllRanges();
    selection.addRange(newRange);

    editor.focus();
    handleContentChange();
  };

  const handleContentChange = useCallback(() => {
    if (editorRef.current) {
      dispatch({
        type: 'EDITOR_SET_CONTENT',
        content: editorRef.current.innerHTML,
      });
    }
  }, [dispatch]);

  const handleCopy = useCallback(() => {
    if (editorRef.current) {
      const text = editorRef.current.innerText;
      navigator.clipboard.writeText(text).then(() => {
        toast('Texto copiado para a área de transferência');
      });
    }
  }, []);

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'b') {
        e.preventDefault();
        handleFormat('bold');
      } else if ((e.metaKey || e.ctrlKey) && e.key === 'i') {
        e.preventDefault();
        handleFormat('italic');
      } else if ((e.metaKey || e.ctrlKey) && e.key === 'u') {
        e.preventDefault();
        handleFormat('underline');
      }
    },
    [handleFormat]
  );

  return (
    <div className="flex flex-col h-full min-h-[240px]">
      {/* Toolbar */}
      <div
        className="flex items-center gap-1 p-1.5 rounded-md mb-2"
        style={{ backgroundColor: 'var(--bg-tertiary)', border: '1px solid var(--border-subtle)' }}
      >
        {toolbarButtons.map((btn, index) => {
          if ('divider' in btn) {
            return (
              <div
                key={`div-${index}`}
                className="w-px h-5 mx-1"
                style={{ backgroundColor: 'var(--border-subtle)' }}
              />
            );
          }
          const Icon = btn.icon;
          const isActive = activeFormats.has(btn.command);
          return (
            <button
              key={btn.command}
              onClick={() => handleFormat(btn.command)}
              className="w-7 h-7 rounded flex items-center justify-center transition-all"
              style={{
                backgroundColor: isActive ? 'var(--accent-muted)' : 'transparent',
                color: isActive ? 'var(--accent)' : 'var(--text-secondary)',
              }}
              onMouseEnter={(e) => {
                if (!isActive) e.currentTarget.style.backgroundColor = 'var(--bg-quaternary)';
              }}
              onMouseLeave={(e) => {
                if (!isActive) e.currentTarget.style.backgroundColor = 'transparent';
              }}
              title={btn.label}
              aria-label={btn.label}
            >
              <Icon size={14} />
            </button>
          );
        })}
      </div>

      {/* Editor area */}
      <div
        ref={editorRef}
        contentEditable
        suppressContentEditableWarning
        onInput={handleContentChange}
        onKeyDown={handleKeyDown}
        onMouseUp={updateActiveFormats}
        onKeyUp={updateActiveFormats}
        className="editor-content flex-1 min-h-[180px] p-3 rounded-md text-sm outline-none overflow-y-auto"
        style={{
          backgroundColor: 'var(--bg-primary)',
          color: 'var(--text-primary)',
          lineHeight: 1.6,
          border: '1px solid var(--border-subtle)',
          caretColor: 'var(--accent)',
        }}
        data-placeholder="Comece a escrever..."
      />

      {/* Copy button */}
      <div className="flex justify-end mt-2">
        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs transition-colors"
          style={{ color: 'var(--accent)' }}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'var(--accent-muted)')}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
        >
          <ClipboardCopy size={13} />
          Copiar Texto
        </button>
      </div>
    </div>
  );
}
