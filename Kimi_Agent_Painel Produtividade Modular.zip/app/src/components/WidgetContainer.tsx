import { useState, type ReactNode } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, GripVertical, type LucideIcon } from 'lucide-react';

interface WidgetContainerProps {
  title: string;
  icon: LucideIcon;
  children: ReactNode;
  className?: string;
  gridClass?: string;
}

export function WidgetContainer({ title, icon: Icon, children, className = '', gridClass = '' }: WidgetContainerProps) {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <motion.div
      layout
      className={`widget-card flex flex-col ${gridClass} ${className}`}
    >
      {/* Header */}
      <div
        className="flex items-center gap-2 px-3 py-2.5 border-b cursor-pointer select-none"
        style={{ borderColor: 'var(--border-subtle)' }}
        onClick={() => setCollapsed(!collapsed)}
      >
        <GripVertical size={14} style={{ color: 'var(--text-tertiary)' }} className="cursor-grab" />
        <Icon size={16} style={{ color: 'var(--text-secondary)' }} />
        <span
          className="text-sm font-medium flex-1"
          style={{ color: 'var(--text-primary)' }}
        >
          {title}
        </span>
        <motion.div
          animate={{ rotate: collapsed ? -90 : 0 }}
          transition={{ duration: 0.15 }}
        >
          <ChevronDown size={16} style={{ color: 'var(--text-tertiary)' }} />
        </motion.div>
      </div>

      {/* Body */}
      <motion.div
        initial={false}
        animate={{
          height: collapsed ? 0 : 'auto',
          opacity: collapsed ? 0 : 1,
        }}
        transition={{ duration: 0.2, ease: [0.4, 0, 0.2, 1] }}
        className="overflow-hidden"
      >
        <div className="p-3">{children}</div>
      </motion.div>
    </motion.div>
  );
}
