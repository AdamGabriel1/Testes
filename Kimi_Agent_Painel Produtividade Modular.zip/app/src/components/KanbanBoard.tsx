import { useState } from 'react';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
  DragOverlay,
} from '@dnd-kit/core';
import {
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import { toast } from 'sonner';
import type { KanbanCardData, KanbanColumn, Priority } from '@/types';
import { useAppState } from '@/hooks/useAppState';

const columnsConfig: { id: KanbanColumn; label: string; dotColor: string }[] = [
  { id: 'todo', label: 'A Fazer', dotColor: 'var(--error)' },
  { id: 'inprogress', label: 'Em Progresso', dotColor: 'var(--accent)' },
  { id: 'done', label: 'Concluído', dotColor: 'var(--success)' },
];

const priorityOptions: { value: Priority; label: string }[] = [
  { value: 'high', label: 'Alta' },
  { value: 'medium', label: 'Média' },
  { value: 'low', label: 'Baixa' },
];

// Card Form Component (inline create/edit)
function CardForm({
  initialData,
  onSave,
  onCancel,
}: {
  initialData?: KanbanCardData;
  onSave: (card: KanbanCardData) => void;
  onCancel: () => void;
}) {
  const [title, setTitle] = useState(initialData?.title || '');
  const [description, setDescription] = useState(initialData?.description || '');
  const [priority, setPriority] = useState<Priority>(initialData?.priority || 'medium');

  const handleSubmit = () => {
    if (!title.trim()) return;
    onSave({
      id: initialData?.id || uuidv4(),
      title: title.trim(),
      description: description.trim(),
      priority,
      dueDate: initialData?.dueDate || null,
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    } else if (e.key === 'Escape') {
      onCancel();
    }
  };

  return (
    <div
      className="p-3 rounded-md space-y-2.5"
      style={{ backgroundColor: 'var(--bg-tertiary)', border: '1px solid var(--border-active)' }}
    >
      <input
        autoFocus
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Título da tarefa"
        className="w-full bg-transparent text-sm font-medium outline-none placeholder:text-[var(--text-tertiary)]"
        style={{ color: 'var(--text-primary)' }}
      />
      <textarea
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Descrição opcional"
        rows={2}
        className="w-full bg-transparent text-xs outline-none resize-none placeholder:text-[var(--text-tertiary)]"
        style={{ color: 'var(--text-secondary)' }}
      />
      <div className="flex gap-1.5">
        {priorityOptions.map((opt) => (
          <button
            key={opt.value}
            onClick={() => setPriority(opt.value)}
            className="px-2.5 py-1 rounded text-xs font-medium transition-all"
            style={{
              backgroundColor: priority === opt.value ? `var(--priority-${opt.value}-bg, rgba(212,165,116,0.2))` : 'transparent',
              color: priority === opt.value ? `var(--priority-${opt.value}-text, var(--accent))` : 'var(--text-tertiary)',
              border: `1px solid ${priority === opt.value ? 'var(--border-active)' : 'var(--border-subtle)'}`,
            }}
          >
            {opt.label}
          </button>
        ))}
      </div>
      <div className="flex justify-end gap-2 pt-1">
        <button
          onClick={onCancel}
          className="px-2.5 py-1 rounded text-xs transition-colors"
          style={{ color: 'var(--text-tertiary)' }}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'var(--bg-quaternary)')}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
        >
          Cancelar
        </button>
        <button
          onClick={handleSubmit}
          className="px-2.5 py-1 rounded text-xs font-medium transition-opacity"
          style={{ backgroundColor: 'var(--accent)', color: 'var(--bg-primary)' }}
          onMouseEnter={(e) => (e.currentTarget.style.opacity = '0.9')}
          onMouseLeave={(e) => (e.currentTarget.style.opacity = '1')}
        >
          {initialData ? 'Salvar' : 'Adicionar'}
        </button>
      </div>
    </div>
  );
}

// Sortable Card Component
function SortableKanbanCard({
  card,
  column,
  onEdit,
}: {
  card: KanbanCardData;
  column: KanbanColumn;
  onEdit: (card: KanbanCardData) => void;
}) {
  const { dispatch } = useAppState();
  const [isEditing, setIsEditing] = useState(false);
  const [showActions, setShowActions] = useState(false);

  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: card.id, data: { card, column } });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.3 : 1,
  };

  const priorityClass = `priority-${card.priority}`;

  const handleDelete = () => {
    dispatch({ type: 'KANBAN_DELETE_CARD', column, cardId: card.id });
    toast('Tarefa excluída');
  };

  const handleSave = (updated: KanbanCardData) => {
    dispatch({ type: 'KANBAN_UPDATE_CARD', column, card: updated });
    setIsEditing(false);
    toast('Tarefa atualizada');
  };

  if (isEditing) {
    return (
      <div ref={setNodeRef} style={style} className="mb-2">
        <CardForm
          initialData={card}
          onSave={handleSave}
          onCancel={() => setIsEditing(false)}
        />
      </div>
    );
  }

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className="mb-2 rounded-md p-2.5 cursor-grab active:cursor-grabbing relative group transition-all"
      onMouseEnter={(e) => {
        e.currentTarget.style.borderColor = 'var(--border-active)';
        setShowActions(true);
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.borderColor = 'var(--border-subtle)';
        setShowActions(false);
      }}
      onClick={() => onEdit(card)}
    >
      <div
        className="rounded-md p-2.5 border transition-all"
        style={{
          backgroundColor: 'var(--bg-tertiary)',
          borderColor: 'var(--border-subtle)',
          boxShadow: isDragging ? 'var(--shadow-elevated)' : 'none',
          transform: isDragging ? 'scale(1.02)' : 'scale(1)',
        }}
      >
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${priorityClass}`}>
                {card.priority === 'high' ? 'Alta' : card.priority === 'medium' ? 'Média' : 'Baixa'}
              </span>
            </div>
            <p className="text-sm font-medium truncate" style={{ color: 'var(--text-primary)' }}>
              {card.title}
            </p>
            {card.description && (
              <p
                className="text-xs mt-0.5 line-clamp-2"
                style={{ color: 'var(--text-secondary)' }}
              >
                {card.description}
              </p>
            )}
            {card.dueDate && (
              <p className="text-[10px] mt-1.5 flex items-center gap-1" style={{ color: 'var(--text-tertiary)' }}>
                <span>{new Date(card.dueDate + 'T12:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}</span>
              </p>
            )}
          </div>
          <AnimatePresence>
            {showActions && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col gap-1 shrink-0"
                onClick={(e) => e.stopPropagation()}
              >
                <button
                  onClick={() => setIsEditing(true)}
                  className="p-1 rounded transition-colors"
                  style={{ color: 'var(--text-tertiary)' }}
                  onMouseEnter={(e) => (e.currentTarget.style.color = 'var(--accent)')}
                  onMouseLeave={(e) => (e.currentTarget.style.color = 'var(--text-tertiary)')}
                >
                  <Pencil size={12} />
                </button>
                <button
                  onClick={handleDelete}
                  className="p-1 rounded transition-colors"
                  style={{ color: 'var(--text-tertiary)' }}
                  onMouseEnter={(e) => (e.currentTarget.style.color = 'var(--error)')}
                  onMouseLeave={(e) => (e.currentTarget.style.color = 'var(--text-tertiary)')}
                >
                  <Trash2 size={12} />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

// Column Component
function KanbanColumnComponent({
  column,
  cards,
}: {
  column: (typeof columnsConfig)[0];
  cards: KanbanCardData[];
}) {
  const { dispatch } = useAppState();
  const [showForm, setShowForm] = useState(false);
  const [, setEditingCard] = useState<KanbanCardData | null>(null);

  const handleAddCard = (card: KanbanCardData) => {
    dispatch({ type: 'KANBAN_ADD_CARD', column: column.id, card });
    setShowForm(false);
    toast('Tarefa adicionada');
  };

  return (
    <div
      className="flex flex-col rounded-md min-h-[200px]"
      style={{
        backgroundColor: 'var(--bg-quaternary)',
        padding: 12,
      }}
    >
      {/* Column header */}
      <div className="flex items-center gap-2 mb-3">
        <span
          className="w-2 h-2 rounded-full"
          style={{ backgroundColor: column.dotColor }}
        />
        <span className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>
          {column.label}
        </span>
        <span
          className="text-xs ml-auto"
          style={{ color: 'var(--text-tertiary)' }}
        >
          {cards.length}
        </span>
      </div>

      {/* Cards list */}
      <SortableContext items={cards.map((c) => c.id)} strategy={verticalListSortingStrategy}>
        <div className="flex-1 space-y-0">
          {cards.map((card) => (
            <SortableKanbanCard
              key={card.id}
              card={card}
              column={column.id}
              onEdit={setEditingCard}
            />
          ))}
        </div>
      </SortableContext>

      {/* Add card */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-2"
          >
            <CardForm
              onSave={handleAddCard}
              onCancel={() => setShowForm(false)}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {!showForm && (
        <button
          onClick={() => setShowForm(true)}
          className="mt-2 w-full py-2 rounded-md border border-dashed text-xs font-medium flex items-center justify-center gap-1.5 transition-all"
          style={{
            borderColor: 'var(--border-active)',
            color: 'var(--text-tertiary)',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.borderColor = 'var(--accent)';
            e.currentTarget.style.backgroundColor = 'var(--accent-muted)';
            e.currentTarget.style.color = 'var(--accent)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.borderColor = 'var(--border-active)';
            e.currentTarget.style.backgroundColor = 'transparent';
            e.currentTarget.style.color = 'var(--text-tertiary)';
          }}
        >
          <Plus size={14} />
          Nova Tarefa
        </button>
      )}
    </div>
  );
}

// Main Board Component
export function KanbanBoard() {
  const { state, dispatch } = useAppState();
  const [activeCard, setActiveCard] = useState<KanbanCardData | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over) return;

    const activeData = active.data.current as { card: KanbanCardData; column: KanbanColumn } | undefined;
    const overId = over.id as string;

    if (!activeData) return;

    // Check if dropped over a column
    const overColumn = columnsConfig.find((c) => c.id === overId);
    if (overColumn && overColumn.id !== activeData.column) {
      dispatch({
        type: 'KANBAN_MOVE_CARD',
        fromColumn: activeData.column,
        toColumn: overColumn.id,
        cardId: activeData.card.id,
      });
      setActiveCard(null);
      return;
    }

    // Check if dropped over a card in a different column
    for (const col of columnsConfig) {
      if (col.id === activeData.column) continue;
      const cardInColumn = state.kanban[col.id].find((c) => c.id === overId);
      if (cardInColumn) {
        dispatch({
          type: 'KANBAN_MOVE_CARD',
          fromColumn: activeData.column,
          toColumn: col.id,
          cardId: activeData.card.id,
        });
        setActiveCard(null);
        return;
      }
    }

    // Same column reorder
    const activeColumn = activeData.column;
    const activeIndex = state.kanban[activeColumn].findIndex((c) => c.id === active.id);
    const overIndex = state.kanban[activeColumn].findIndex((c) => c.id === over.id);

    if (activeIndex !== -1 && overIndex !== -1 && activeIndex !== overIndex) {
      dispatch({
        type: 'KANBAN_MOVE_CARD',
        fromColumn: activeColumn,
        toColumn: activeColumn,
        cardId: activeData.card.id,
        newIndex: overIndex,
      });
    }

    setActiveCard(null);
  };

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragStart={(e) => {
        const data = e.active.data.current as { card: KanbanCardData } | undefined;
        if (data?.card) setActiveCard(data.card);
      }}
      onDragEnd={handleDragEnd}
      onDragCancel={() => setActiveCard(null)}
    >
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {columnsConfig.map((col) => (
          <DroppableColumn key={col.id} column={col}>
            <KanbanColumnComponent column={col} cards={state.kanban[col.id]} />
          </DroppableColumn>
        ))}
      </div>
      <DragOverlay>
        {activeCard ? (
          <div
            className="rounded-md p-2.5 border"
            style={{
              backgroundColor: 'var(--bg-tertiary)',
              borderColor: 'var(--accent)',
              boxShadow: 'var(--shadow-elevated)',
              transform: 'scale(1.02) rotate(2deg)',
            }}
          >
            <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded priority-${activeCard.priority}`}>
              {activeCard.priority === 'high' ? 'Alta' : activeCard.priority === 'medium' ? 'Média' : 'Baixa'}
            </span>
            <p className="text-sm font-medium mt-1" style={{ color: 'var(--text-primary)' }}>
              {activeCard.title}
            </p>
          </div>
        ) : null}
      </DragOverlay>
    </DndContext>
  );
}

// Droppable Column Wrapper
function DroppableColumn({
  column,
  children,
}: {
  column: (typeof columnsConfig)[0];
  children: React.ReactNode;
}) {
  return (
    <div
      data-column-id={column.id}
      className="min-h-0"
    >
      {children}
    </div>
  );
}
