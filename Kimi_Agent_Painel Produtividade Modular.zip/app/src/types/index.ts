export type Priority = 'high' | 'medium' | 'low';
export type KanbanColumn = 'todo' | 'inprogress' | 'done';
export type PomodoroMode = 'focus' | 'shortBreak';

export interface KanbanCardData {
  id: string;
  title: string;
  description: string;
  priority: Priority;
  dueDate: string | null;
}

export interface HabitItem {
  id: string;
  label: string;
  completed: boolean;
}

export interface AppState {
  version: number;
  kanban: {
    todo: KanbanCardData[];
    inprogress: KanbanCardData[];
    done: KanbanCardData[];
  };
  calendar: {
    reminders: Record<string, string[]>;
  };
  editor: {
    content: string;
  };
  pomodoro: {
    mode: PomodoroMode;
    timeLeft: number;
  };
  habits: {
    items: HabitItem[];
  };
  sidebar: {
    collapsed: boolean;
    activeModule: string;
  };
}

export type AppAction =
  | { type: 'KANBAN_ADD_CARD'; column: KanbanColumn; card: KanbanCardData }
  | { type: 'KANBAN_UPDATE_CARD'; column: KanbanColumn; card: KanbanCardData }
  | { type: 'KANBAN_DELETE_CARD'; column: KanbanColumn; cardId: string }
  | { type: 'KANBAN_MOVE_CARD'; fromColumn: KanbanColumn; toColumn: KanbanColumn; cardId: string; newIndex?: number }
  | { type: 'CALENDAR_SET_REMINDER'; date: string; reminder: string }
  | { type: 'CALENDAR_DELETE_REMINDER'; date: string; index: number }
  | { type: 'EDITOR_SET_CONTENT'; content: string }
  | { type: 'POMODORO_SET_TIME'; timeLeft: number }
  | { type: 'POMODORO_SET_MODE'; mode: PomodoroMode; timeLeft: number }
  | { type: 'HABIT_ADD'; habit: HabitItem }
  | { type: 'HABIT_TOGGLE'; habitId: string }
  | { type: 'HABIT_DELETE'; habitId: string }
  | { type: 'SIDEBAR_TOGGLE' }
  | { type: 'SIDEBAR_SET_MODULE'; module: string }
  | { type: 'RESET_ALL' };
