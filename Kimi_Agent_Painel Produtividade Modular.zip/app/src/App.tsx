import { Toaster } from '@/components/ui/sonner';
import { AppStateProvider } from '@/hooks/useAppState';
import { Sidebar } from '@/components/Sidebar';
import { WidgetContainer } from '@/components/WidgetContainer';
import { KanbanBoard } from '@/components/KanbanBoard';
import { CalendarWidget } from '@/components/CalendarWidget';
import { RichTextEditor } from '@/components/RichTextEditor';
import { PomodoroTimer } from '@/components/PomodoroTimer';
import { HabitTracker } from '@/components/HabitTracker';
import { FooterStatusBar } from '@/components/FooterStatusBar';
import { useAppState } from '@/hooks/useAppState';
import {
  Columns3,
  CalendarDays,
  FileText,
  Timer,
  Target,
} from 'lucide-react';

function Dashboard() {
  const { state } = useAppState();
  const activeModule = state.sidebar.activeModule;

  // If a specific module is selected, show only that one full-width
  const showOnly = activeModule !== 'dashboard' ? activeModule : null;

  return (
    <main
      className="flex-1 overflow-y-auto p-4 md:p-6"
      style={{ backgroundColor: 'var(--bg-primary)' }}
    >
      <div className="max-w-[1400px] mx-auto">
        {/* Page title */}
        <h1
          className="text-xl font-semibold mb-5"
          style={{ color: 'var(--text-primary)', letterSpacing: '-0.02em' }}
        >
          {showOnly
            ? {
                kanban: 'Quadro Kanban',
                calendar: 'Calendário',
                editor: 'Editor de Notas',
                pomodoro: 'Pomodoro',
                habits: 'Metas Diárias',
              }[showOnly] || 'Dashboard'
            : 'Dashboard'}
        </h1>

        {/* Widget Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Kanban - always full width */}
          {(!showOnly || showOnly === 'kanban') && (
            <div className={showOnly === 'kanban' ? 'col-span-full' : 'md:col-span-2 lg:col-span-3'}>
              <WidgetContainer
                title="Quadro Kanban"
                icon={Columns3}
                gridClass="col-span-full"
              >
                <KanbanBoard />
              </WidgetContainer>
            </div>
          )}

          {/* Calendar - 1 column */}
          {(!showOnly || showOnly === 'calendar') && (
            <WidgetContainer
              title="Calendário"
              icon={CalendarDays}
            >
              <CalendarWidget />
            </WidgetContainer>
          )}

          {/* Rich Text Editor - 2 columns */}
          {(!showOnly || showOnly === 'editor') && (
            <div className={showOnly === 'editor' ? 'col-span-full md:col-span-2' : 'md:col-span-1 lg:col-span-2'}>
              <WidgetContainer
                title="Editor de Notas"
                icon={FileText}
                gridClass="min-h-[320px]"
              >
                <RichTextEditor />
              </WidgetContainer>
            </div>
          )}

          {/* Pomodoro - 1 column */}
          {(!showOnly || showOnly === 'pomodoro') && (
            <WidgetContainer
              title="Pomodoro"
              icon={Timer}
            >
              <PomodoroTimer />
            </WidgetContainer>
          )}

          {/* Habit Tracker - 1 column */}
          {(!showOnly || showOnly === 'habits') && (
            <WidgetContainer
              title="Metas Diárias"
              icon={Target}
            >
              <HabitTracker />
            </WidgetContainer>
          )}
        </div>
      </div>
    </main>
  );
}

function App() {
  return (
    <AppStateProvider>
      <div className="flex h-screen w-screen overflow-hidden" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <Sidebar />
        <div className="flex flex-col flex-1 min-w-0">
          <Dashboard />
          <FooterStatusBar />
        </div>
      </div>
      <Toaster
        position="bottom-right"
        toastOptions={{
          style: {
            background: 'var(--bg-secondary)',
            border: '1px solid var(--border-subtle)',
            color: 'var(--text-primary)',
            fontSize: '13px',
          },
        }}
      />
    </AppStateProvider>
  );
}

export default App;
