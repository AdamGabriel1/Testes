import { createContext, useContext, useReducer, useEffect, useRef, useState, type ReactNode } from 'react';
import { v4 as uuidv4 } from 'uuid';
import type { AppState, AppAction } from '@/types';

const STORAGE_KEY = 'modular_pro_state';
const CURRENT_VERSION = 1;

const today = new Date().toISOString().split('T')[0];
const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];

const defaultState: AppState = {
  version: CURRENT_VERSION,
  kanban: {
    todo: [
      {
        id: uuidv4(),
        title: 'Revisar proposta de design',
        description: 'Analisar o documento de especificações técnicas',
        priority: 'high',
        dueDate: today,
      },
      {
        id: uuidv4(),
        title: 'Preparar apresentação',
        description: 'Slides para a reunião de sexta-feira',
        priority: 'medium',
        dueDate: tomorrow,
      },
      {
        id: uuidv4(),
        title: 'Atualizar dependências',
        description: 'Verificar atualizações de segurança',
        priority: 'low',
        dueDate: null,
      },
    ],
    inprogress: [
      {
        id: uuidv4(),
        title: 'Implementar dashboard',
        description: 'Criar os widgets principais do painel',
        priority: 'high',
        dueDate: today,
      },
    ],
    done: [
      {
        id: uuidv4(),
        title: 'Definir arquitetura',
        description: 'Escolher stack e estrutura do projeto',
        priority: 'medium',
        dueDate: null,
      },
    ],
  },
  calendar: {
    reminders: {
      [today]: ['Reunião de planejamento às 14h', 'Revisar código do colega'],
    },
  },
  editor: {
    content: '<p><strong>Bem-vindo ao Modular Pro!</strong></p><p>Este é seu espaço de anotações. Use o toolbar acima para formatar texto.</p><ul><li>Crie listas de tarefas</li><li>Organize suas ideias</li><li>Documente seus processos</li></ul><p>Use <em>itálico</em> e <u>sublinhado</u> para dar ênfase.</p>',
  },
  pomodoro: {
    mode: 'focus',
    timeLeft: 1500,
  },
  habits: {
    items: [
      { id: uuidv4(), label: 'Beber 2L de água', completed: false },
      { id: uuidv4(), label: 'Ler 10 páginas', completed: true },
      { id: uuidv4(), label: 'Exercício físico 30min', completed: false },
      { id: uuidv4(), label: 'Meditar 10 minutos', completed: false },
    ],
  },
  sidebar: {
    collapsed: false,
    activeModule: 'dashboard',
  },
};

function loadState(): AppState {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (parsed.version === CURRENT_VERSION) {
        return parsed;
      }
    }
  } catch {
    // ignore
  }
  return defaultState;
}

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'KANBAN_ADD_CARD':
      return {
        ...state,
        kanban: {
          ...state.kanban,
          [action.column]: [...state.kanban[action.column], action.card],
        },
      };

    case 'KANBAN_UPDATE_CARD':
      return {
        ...state,
        kanban: {
          ...state.kanban,
          [action.column]: state.kanban[action.column].map((c) =>
            c.id === action.card.id ? action.card : c
          ),
        },
      };

    case 'KANBAN_DELETE_CARD':
      return {
        ...state,
        kanban: {
          ...state.kanban,
          [action.column]: state.kanban[action.column].filter((c) => c.id !== action.cardId),
        },
      };

    case 'KANBAN_MOVE_CARD': {
      const fromCards = [...state.kanban[action.fromColumn]];
      const cardIndex = fromCards.findIndex((c) => c.id === action.cardId);
      if (cardIndex === -1) return state;
      const [movedCard] = fromCards.splice(cardIndex, 1);
      const toCards = [...state.kanban[action.toColumn]];
      const insertIndex = action.newIndex ?? toCards.length;
      toCards.splice(insertIndex, 0, movedCard);
      return {
        ...state,
        kanban: {
          ...state.kanban,
          [action.fromColumn]: fromCards,
          [action.toColumn]: toCards,
        },
      };
    }

    case 'CALENDAR_SET_REMINDER': {
      const current = state.calendar.reminders[action.date] || [];
      return {
        ...state,
        calendar: {
          ...state.calendar,
          reminders: {
            ...state.calendar.reminders,
            [action.date]: [...current, action.reminder],
          },
        },
      };
    }

    case 'CALENDAR_DELETE_REMINDER': {
      const current = state.calendar.reminders[action.date] || [];
      return {
        ...state,
        calendar: {
          ...state.calendar,
          reminders: {
            ...state.calendar.reminders,
            [action.date]: current.filter((_, i) => i !== action.index),
          },
        },
      };
    }

    case 'EDITOR_SET_CONTENT':
      return {
        ...state,
        editor: { ...state.editor, content: action.content },
      };

    case 'POMODORO_SET_TIME':
      return {
        ...state,
        pomodoro: { ...state.pomodoro, timeLeft: action.timeLeft },
      };

    case 'POMODORO_SET_MODE':
      return {
        ...state,
        pomodoro: { ...state.pomodoro, mode: action.mode, timeLeft: action.timeLeft },
      };

    case 'HABIT_ADD':
      return {
        ...state,
        habits: { ...state.habits, items: [...state.habits.items, action.habit] },
      };

    case 'HABIT_TOGGLE':
      return {
        ...state,
        habits: {
          ...state.habits,
          items: state.habits.items.map((h) =>
            h.id === action.habitId ? { ...h, completed: !h.completed } : h
          ),
        },
      };

    case 'HABIT_DELETE':
      return {
        ...state,
        habits: {
          ...state.habits,
          items: state.habits.items.filter((h) => h.id !== action.habitId),
        },
      };

    case 'SIDEBAR_TOGGLE':
      return {
        ...state,
        sidebar: { ...state.sidebar, collapsed: !state.sidebar.collapsed },
      };

    case 'SIDEBAR_SET_MODULE':
      return {
        ...state,
        sidebar: { ...state.sidebar, activeModule: action.module },
      };

    case 'RESET_ALL':
      return { ...defaultState };

    default:
      return state;
  }
}

interface AppContextValue {
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
  saveStatus: 'saved' | 'saving';
}

const AppStateContext = createContext<AppContextValue | null>(null);

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, null, loadState);
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving'>('saved');
  const saveTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Debounced auto-save
  useEffect(() => {
    setSaveStatus('saving');
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
    }
    saveTimeoutRef.current = setTimeout(() => {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
        setSaveStatus('saved');
      } catch {
        // storage full or other error
      }
    }, 500);
    return () => {
      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    };
  }, [state]);

  return (
    <AppStateContext.Provider value={{ state, dispatch, saveStatus }}>
      {children}
    </AppStateContext.Provider>
  );
}

export function useAppState(): AppContextValue {
  const context = useContext(AppStateContext);
  if (!context) {
    throw new Error('useAppState must be used within AppStateProvider');
  }
  return context;
}
