import type { LoaderFunctionArgs } from 'react-router';
import { exportCSV } from '~/lib/queries.server';

export async function loader({ request }: LoaderFunctionArgs) {
  const csv = exportCSV();
  return new Response(csv, {
    headers: {
      'Content-Type': 'text/csv',
      'Content-Disposition': 'attachment; filename="esports_export.csv"'
    }
  });
}
