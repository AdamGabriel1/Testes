import { Outlet, useLoaderData, Link } from 'react-router';
import type { LoaderFunctionArgs } from 'react-router';
import { getStats, getMeses, getTimes } from '~/lib/queries.server';
import { StatsCard } from '~/components/ui/StatsCard';
import type { TabType } from '~/types';

export async function loader({ request }: LoaderFunctionArgs) {
  const url = new URL(request.url);
  const tab = (url.pathname.split('/')[1] || 'colocacoes') as TabType;

  return {
    stats: getStats(),
    meses: getMeses(),
    times: getTimes(),
    currentTab: tab
  };
}

export default function Layout() {
  const { stats, meses, times, currentTab } = useLoaderData<typeof loader>();

  const tabs: { id: TabType; label: string }[] = [
    { id: 'colocacoes', label: 'Colocações' },
    { id: 'jogadores', label: 'Jogadores' },
    { id: 'dashboard', label: 'Dashboard' },
  ];

  return (
    <div className="min-h-screen bg-[#0f172a] text-[#e2e8f0]">
      <header className="glass-strong sticky top-0 z-50 border-b border-slate-700/50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/30">
              <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path d="M10 2a8 8 0 100 16 8 8 0 000-16zM9 9V5a1 1 0 012 0v4h4a1 1 0 010 2h-4v4a1 1 0 01-2 0v-4H5a1 1 0 010-2h4z"/>
              </svg>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white glow-text">eSports Manager</h1>
              <p className="text-xs text-slate-400">Remix + TypeScript + SQLite</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span className="api-status api-online">
              <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block mr-1"></span> Online
            </span>

            <Link to="/export/sql" download 
              className="px-4 py-2 rounded-lg bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-600/30 transition-all text-sm font-medium flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              SQL
            </Link>
            <Link to="/export/csv" download
              className="px-4 py-2 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30 hover:bg-blue-600/30 transition-all text-sm font-medium flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              CSV
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <StatsCard title="Total de Times" value={stats.total_times} 
            icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>}
            color="indigo" delay={0} />
          <StatsCard title="Total de Jogadores" value={stats.total_jogadores}
            icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>}
            color="purple" delay={0.1} />
          <StatsCard title="Partidas Registradas" value={stats.total_partidas}
            icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>}
            color="pink" delay={0.2} />
          <StatsCard title="Total de Kills" value={stats.total_kills}
            icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
            color="rose" delay={0.3} />
        </div>

        <div className="glass rounded-2xl p-2 flex gap-2">
          {tabs.map(tab => (
            <Link
              key={tab.id}
              to={`/${tab.id}`}
              className={`flex-1 py-3 rounded-xl text-sm font-semibold transition-all flex items-center justify-center gap-2 ${
                currentTab === tab.id 
                  ? 'tab-active' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <span>{tab.label}</span>
            </Link>
          ))}
        </div>

        <Outlet context={{ meses, times }} />
      </main>
    </div>
  );
}
