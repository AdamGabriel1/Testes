import type { LoaderFunctionArgs } from 'react-router';
import { exportSQL } from '~/lib/queries.server';

export async function loader({ request }: LoaderFunctionArgs) {
  const sql = exportSQL();
  return new Response(sql, {
    headers: {
      'Content-Type': 'text/plain',
      'Content-Disposition': 'attachment; filename="esports_export.sql"'
    }
  });
}
