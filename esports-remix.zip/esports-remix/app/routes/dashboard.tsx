import { useLoaderData } from 'react-router';
import type { LoaderFunctionArgs } from 'react-router';
import { Suspense, lazy } from 'react';
import { getDashboard } from '~/lib/queries.server';

const KillsPorTime = lazy(() => import('~/components/charts/KillsPorTime').then(m => ({ default: m.KillsPorTime })));
const TopJogadores = lazy(() => import('~/components/charts/TopJogadores').then(m => ({ default: m.TopJogadores })));
const DistribuicaoQ1 = lazy(() => import('~/components/charts/DistribuicaoQ1').then(m => ({ default: m.DistribuicaoQ1 })));
const KillsQuartis = lazy(() => import('~/components/charts/KillsQuartis').then(m => ({ default: m.KillsQuartis })));

export async function loader({ request }: LoaderFunctionArgs) {
  return { dashboard: getDashboard() };
}

function ChartSkeleton() {
  return <div className="h-[250px] flex items-center justify-center text-slate-500">Carregando gráfico...</div>;
}

export default function Dashboard() {
  const { dashboard } = useLoaderData<typeof loader>();

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="glass rounded-2xl p-6">
        <h3 className="text-lg font-bold text-white mb-4">Kills por Time (Top 10)</h3>
        <Suspense fallback={<ChartSkeleton />}>
          <KillsPorTime data={dashboard.kills_por_time} />
        </Suspense>
      </div>

      <div className="glass rounded-2xl p-6">
        <h3 className="text-lg font-bold text-white mb-4">Top Jogadores - Total de Kills</h3>
        <Suspense fallback={<ChartSkeleton />}>
          <TopJogadores data={dashboard.top_jogadores} />
        </Suspense>
      </div>

      <div className="glass rounded-2xl p-6">
        <h3 className="text-lg font-bold text-white mb-4">Distribuição de Colocações Q1</h3>
        <Suspense fallback={<ChartSkeleton />}>
          <DistribuicaoQ1 data={dashboard.distribuicao_q1} />
        </Suspense>
      </div>

      <div className="glass rounded-2xl p-6">
        <h3 className="text-lg font-bold text-white mb-4">Kills por Quartil (Média)</h3>
        <Suspense fallback={<ChartSkeleton />}>
          <KillsQuartis data={dashboard.kills_quartis} />
        </Suspense>
      </div>
    </div>
  );
}
