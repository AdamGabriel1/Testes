import { useLoaderData, useActionData, useOutletContext, Form } from 'react-router';
import type { ActionFunctionArgs, LoaderFunctionArgs } from 'react-router';
import { useState, useEffect } from 'react';
import { getColocacoes, createColocacao, updateColocacao, deleteColocacao } from '~/lib/queries.server';
import { Modal } from '~/components/ui/Modal';
import { Toast } from '~/components/ui/Toast';
import type { Colocacao } from '~/types';

export async function loader({ request }: LoaderFunctionArgs) {
  const url = new URL(request.url);
  const mes = url.searchParams.get('mes') || undefined;
  const search = url.searchParams.get('search') || undefined;
  return { colocacoes: getColocacoes(mes, search), mes, search };
}

export async function action({ request }: ActionFunctionArgs) {
  const formData = await request.formData();
  const _action = formData.get('_action') as string;

  try {
    if (_action === 'create') {
      const data = {
        Mes: formData.get('Mes') as string,
        Dia: parseInt(formData.get('Dia') as string),
        Time: formData.get('Time') as string,
        Q1_Pos: parseInt(formData.get('Q1') as string),
        Q2_Pos: parseInt(formData.get('Q2') as string),
        Q3_Pos: parseInt(formData.get('Q3') as string),
      };
      createColocacao(data);
      return { success: 'Colocação criada com sucesso!' };
    }

    if (_action === 'update') {
      const id = parseInt(formData.get('id') as string);
      const data = {
        Mes: formData.get('Mes') as string,
        Dia: parseInt(formData.get('Dia') as string),
        Time: formData.get('Time') as string,
        Q1_Pos: parseInt(formData.get('Q1') as string),
        Q2_Pos: parseInt(formData.get('Q2') as string),
        Q3_Pos: parseInt(formData.get('Q3') as string),
      };
      updateColocacao(id, data);
      return { success: 'Colocação atualizada com sucesso!' };
    }

    if (_action === 'delete') {
      const id = parseInt(formData.get('id') as string);
      deleteColocacao(id);
      return { success: 'Colocação excluída com sucesso!' };
    }
  } catch (error) {
    return { error: 'Erro ao processar operação: ' + (error as Error).message };
  }

  return null;
}

export default function Colocacoes() {
  const { colocacoes, mes, search } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();
  const { meses } = useOutletContext<{ meses: string[] }>();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<Colocacao | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  useEffect(() => {
    if (actionData && 'success' in actionData) setToast({ message: actionData.success as string, type: 'success' });
    if (actionData && 'error' in actionData) setToast({ message: actionData.error as string, type: 'error' });
  }, [actionData]);

  const posClass = (pos: number) => {
    if (pos === 1) return 'text-yellow-400 font-bold';
    if (pos <= 3) return 'text-emerald-400';
    return 'text-slate-400';
  };

  return (
    <div className="space-y-4">
      <div className="glass rounded-2xl p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-lg font-bold text-white">Colocações por Partida</h2>
            <p className="text-sm text-slate-400">Gerencie as posições dos times em cada quartil</p>
          </div>
          <button onClick={() => { setEditingRecord(null); setModalOpen(true); }}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-semibold hover:shadow-lg hover:shadow-indigo-500/30 transition-all flex items-center gap-2">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
            Nova Colocação
          </button>
        </div>

        <Form className="flex gap-3 mb-4">
          <div className="relative flex-1 max-w-xs">
            <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            <input type="text" name="search" defaultValue={search || ''} placeholder="Buscar time ou data..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white placeholder-slate-500 input-glow outline-none transition-all" />
          </div>
          <select name="mes" defaultValue={mes || ''} onChange={(e) => e.target.form?.submit()}
            className="px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow">
            <option value="">Todos os Meses</option>
            {meses.map(m => <option key={m} value={m}>{m}</option>)}
          </select>
        </Form>

        <div className="overflow-x-auto rounded-xl border border-slate-700/50">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-800/80 text-slate-300">
                <th className="px-4 py-3 text-left font-semibold">Mês</th>
                <th className="px-4 py-3 text-left font-semibold">Dia</th>
                <th className="px-4 py-3 text-left font-semibold">Time</th>
                <th className="px-4 py-3 text-center font-semibold">Q1 Pos</th>
                <th className="px-4 py-3 text-center font-semibold">Q2 Pos</th>
                <th className="px-4 py-3 text-center font-semibold">Q3 Pos</th>
                <th className="px-4 py-3 text-center font-semibold">Média</th>
                <th className="px-4 py-3 text-center font-semibold">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/50">
              {colocacoes.map((c: Colocacao) => {
                const media = ((c.Q1_Pos + c.Q2_Pos + c.Q3_Pos) / 3).toFixed(1);
                return (
                  <tr key={c.id} className="row-hover transition-colors">
                    <td className="px-4 py-3 text-slate-300">{c.Mes}</td>
                    <td className="px-4 py-3 text-slate-300">{c.Dia}</td>
                    <td className="px-4 py-3 text-white font-medium">{c.Time}</td>
                    <td className={`px-4 py-3 text-center ${posClass(c.Q1_Pos)}`}>{c.Q1_Pos}</td>
                    <td className={`px-4 py-3 text-center ${posClass(c.Q2_Pos)}`}>{c.Q2_Pos}</td>
                    <td className={`px-4 py-3 text-center ${posClass(c.Q3_Pos)}`}>{c.Q3_Pos}</td>
                    <td className="px-4 py-3 text-center text-slate-300">{media}</td>
                    <td className="px-4 py-3 text-center">
                      <button onClick={() => { setEditingRecord(c); setModalOpen(true); }}
                        className="text-indigo-400 hover:text-indigo-300 mr-2 transition-colors">
                        <svg className="w-4 h-4 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                      </button>
                      <Form method="post" className="inline">
                        <input type="hidden" name="_action" value="delete" />
                        <input type="hidden" name="id" value={c.id} />
                        <button type="submit" onClick={(e) => !confirm('Tem certeza?') && e.preventDefault()}
                          className="text-rose-400 hover:text-rose-300 transition-colors">
                          <svg className="w-4 h-4 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                        </button>
                      </Form>
                    </td>
                  </tr>
                );
              })}
              {colocacoes.length === 0 && (
                <tr><td colSpan={8} className="px-4 py-8 text-center text-slate-500">Nenhum registro encontrado</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} type="colocacoes" record={editingRecord as Record<string, unknown> | null} />
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
}
