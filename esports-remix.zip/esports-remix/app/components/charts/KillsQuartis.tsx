import { useEffect, useRef } from 'react';
import { Chart } from 'chart.js/auto';

interface Props {
  data: { q1_total: number; q2_total: number; q3_total: number };
}

export function KillsQuartis({ data }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;
    if (chartRef.current) chartRef.current.destroy();

    chartRef.current = new Chart(canvasRef.current, {
      type: 'line',
      data: {
        labels: ['Q1', 'Q2', 'Q3'],
        datasets: [{
          label: 'Total de Kills',
          data: [data.q1_total, data.q2_total, data.q3_total],
          borderColor: '#ec4899',
          backgroundColor: 'rgba(236, 72, 153, 0.1)',
          fill: true,
          tension: 0.4,
          pointBackgroundColor: '#ec4899',
          pointBorderColor: '#fff',
          pointRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(148, 163, 184, 0.1)' } },
          x: { ticks: { color: '#94a3b8' }, grid: { display: false } }
        }
      }
    });

    return () => { chartRef.current?.destroy(); };
  }, [data]);

  return <canvas ref={canvasRef} height={250} />;
}
