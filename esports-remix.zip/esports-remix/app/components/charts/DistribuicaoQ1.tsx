import { useEffect, useRef } from 'react';
import { Chart } from 'chart.js/auto';

interface Props {
  data: { posicao: number; quantidade: number }[];
}

export function DistribuicaoQ1({ data }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;
    if (chartRef.current) chartRef.current.destroy();

    const colors = ['#fbbf24', '#34d399', '#60a5fa', '#a78bfa', '#f472b6', '#fb923c', '#94a3b8'];

    chartRef.current = new Chart(canvasRef.current, {
      type: 'doughnut',
      data: {
        labels: data.map(x => `Pos ${x.posicao}`),
        datasets: [{
          data: data.map(x => x.quantidade),
          backgroundColor: colors,
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: 'right', labels: { color: '#e2e8f0' } } }
      }
    });

    return () => { chartRef.current?.destroy(); };
  }, [data]);

  return <canvas ref={canvasRef} height={250} />;
}
