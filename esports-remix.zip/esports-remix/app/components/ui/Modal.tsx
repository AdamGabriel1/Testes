import { Form, useNavigation } from 'react-router';
import type { TabType } from '~/types';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: TabType;
  record?: Record<string, unknown> | null;
}

const meses = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
];

export function Modal({ isOpen, onClose, type, record }: ModalProps) {
  const navigation = useNavigation();
  const isSubmitting = navigation.state === 'submitting';

  if (!isOpen) return null;

  const isJogador = type === 'jogadores';
  const isEditing = !!record;

  return (
    <div className="fixed inset-0 z-50">
      <div className="modal-overlay absolute inset-0" onClick={onClose} />
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="glass-strong rounded-2xl w-full max-w-lg p-6 animate-slide-in relative">
          <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-white transition-colors">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>

          <h3 className="text-xl font-bold text-white mb-6">
            {isEditing ? 'Editar Registro' : 'Novo Registro'}
          </h3>

          <Form method="post" className="space-y-4" onSubmit={onClose}>
            <input type="hidden" name="_action" value={isEditing ? 'update' : 'create'} />
            {isEditing && <input type="hidden" name="id" value={record?.id as number} />}

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Mês</label>
                <select name="Mes" required defaultValue={(record?.Mes as string) || 'Maio'}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow">
                  {meses.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Dia</label>
                <input type="number" name="Dia" min="1" max="31" required 
                  defaultValue={record?.Dia as number || ''}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Time</label>
              <input type="text" name="Time" required 
                defaultValue={record?.Time as string || ''}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow" />
            </div>

            {isJogador && (
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Jogador</label>
                <input type="text" name="Jogador" required 
                  defaultValue={record?.Jogador as string || ''}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow" />
              </div>
            )}

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Q1</label>
                <input type="number" name="Q1" min="0" required 
                  defaultValue={isJogador ? (record?.Q1_Kills as number) : (record?.Q1_Pos as number) || ''}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow text-center" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Q2</label>
                <input type="number" name="Q2" min="0" required 
                  defaultValue={isJogador ? (record?.Q2_Kills as number) : (record?.Q2_Pos as number) || ''}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow text-center" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Q3</label>
                <input type="number" name="Q3" min="0" required 
                  defaultValue={isJogador ? (record?.Q3_Kills as number) : (record?.Q3_Pos as number) || ''}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow text-center" />
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <button type="button" onClick={onClose} 
                className="flex-1 py-2.5 rounded-xl border border-slate-600 text-slate-300 hover:bg-slate-700/50 transition-all font-medium">
                Cancelar
              </button>
              <button type="submit" disabled={isSubmitting}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-semibold hover:shadow-lg hover:shadow-indigo-500/30 transition-all disabled:opacity-50">
                {isSubmitting ? 'Salvando...' : 'Salvar'}
              </button>
            </div>
          </Form>
        </div>
      </div>
    </div>
  );
}
