import type { ReactNode } from 'react';

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: ReactNode;
  delay?: number;
  color: 'indigo' | 'purple' | 'pink' | 'rose';
}

const colorMap = {
  indigo: 'from-indigo-500 to-purple-600 bg-indigo-500/20 text-indigo-400',
  purple: 'from-purple-500 to-violet-600 bg-purple-500/20 text-purple-400',
  pink: 'from-pink-500 to-rose-600 bg-pink-500/20 text-pink-400',
  rose: 'from-rose-500 to-red-600 bg-rose-500/20 text-rose-400',
};

export function StatsCard({ title, value, icon, delay = 0, color }: StatsCardProps) {
  return (
    <div 
      className="stats-card rounded-2xl p-5 animate-fade-in"
      style={{ animationDelay: `${delay}s` }}
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-slate-400 text-sm">{title}</p>
          <p className="text-2xl font-bold text-white mt-1">{value}</p>
        </div>
        <div className={`w-12 h-12 rounded-xl ${colorMap[color].split(' ').slice(2).join(' ')} flex items-center justify-center`}>
          {icon}
        </div>
      </div>
    </div>
  );
}
