import { type RouteConfig, index, layout, route } from "@react-router/dev/routes";

export default [
  layout("routes/_layout.tsx", [
    index("routes/_index.tsx"),
    route("colocacoes", "routes/colocacoes.tsx"),
    route("jogadores", "routes/jogadores.tsx"),
    route("dashboard", "routes/dashboard.tsx"),
  ]),
  route("export/sql", "routes/export.sql.ts"),
  route("export/csv", "routes/export.csv.ts"),
] satisfies RouteConfig;
