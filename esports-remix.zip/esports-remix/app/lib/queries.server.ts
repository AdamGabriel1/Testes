import { db } from './db.server';
import type { Colocacao, Jogador, Stats, DashboardData } from '~/types';

// ===== COLOCAÇÕES =====
export function getColocacoes(mes?: string, search?: string): Colocacao[] {
  let sql = 'SELECT * FROM colocacoes WHERE 1=1';
  const params: (string | number)[] = [];

  if (mes) { sql += ' AND Mes = ?'; params.push(mes); }
  if (search) { 
    sql += ' AND (Time LIKE ? OR Mes LIKE ?)'; 
    params.push(`%${search}%`, `%${search}%`); 
  }
  sql += ' ORDER BY Mes DESC, Dia DESC, Q1_Pos ASC';

  return db.prepare(sql).all(...params) as Colocacao[];
}

export function createColocacao(data: Omit<Colocacao, 'id'>): number {
  const result = db.prepare(`
    INSERT INTO colocacoes (Mes, Dia, Time, Q1_Pos, Q2_Pos, Q3_Pos)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(data.Mes, data.Dia, data.Time, data.Q1_Pos, data.Q2_Pos, data.Q3_Pos);
  return Number(result.lastInsertRowid);
}

export function updateColocacao(id: number, data: Omit<Colocacao, 'id'>): void {
  db.prepare(`
    UPDATE colocacoes SET Mes=?, Dia=?, Time=?, Q1_Pos=?, Q2_Pos=?, Q3_Pos=?
    WHERE id=?
  `).run(data.Mes, data.Dia, data.Time, data.Q1_Pos, data.Q2_Pos, data.Q3_Pos, id);
}

export function deleteColocacao(id: number): void {
  db.prepare('DELETE FROM colocacoes WHERE id=?').run(id);
}

// ===== JOGADORES =====
export function getJogadores(mes?: string, time?: string, search?: string): Jogador[] {
  let sql = 'SELECT * FROM jogadores WHERE 1=1';
  const params: (string | number)[] = [];

  if (mes) { sql += ' AND Mes = ?'; params.push(mes); }
  if (time) { sql += ' AND Time = ?'; params.push(time); }
  if (search) { 
    sql += ' AND (Jogador LIKE ? OR Time LIKE ? OR Mes LIKE ?)'; 
    params.push(`%${search}%`, `%${search}%`, `%${search}%`); 
  }
  sql += ' ORDER BY Mes DESC, Dia DESC';

  return db.prepare(sql).all(...params) as Jogador[];
}

export function createJogador(data: Omit<Jogador, 'id'>): number {
  const result = db.prepare(`
    INSERT INTO jogadores (Mes, Dia, Time, Jogador, Q1_Kills, Q2_Kills, Q3_Kills)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(data.Mes, data.Dia, data.Time, data.Jogador, data.Q1_Kills, data.Q2_Kills, data.Q3_Kills);
  return Number(result.lastInsertRowid);
}

export function updateJogador(id: number, data: Omit<Jogador, 'id'>): void {
  db.prepare(`
    UPDATE jogadores SET Mes=?, Dia=?, Time=?, Jogador=?, Q1_Kills=?, Q2_Kills=?, Q3_Kills=?
    WHERE id=?
  `).run(data.Mes, data.Dia, data.Time, data.Jogador, data.Q1_Kills, data.Q2_Kills, data.Q3_Kills, id);
}

export function deleteJogador(id: number): void {
  db.prepare('DELETE FROM jogadores WHERE id=?').run(id);
}

// ===== STATS & DASHBOARD =====
export function getStats(): Stats {
  const total_times = db.prepare(`
    SELECT COUNT(DISTINCT Time) as c FROM (
      SELECT Time FROM colocacoes UNION SELECT Time FROM jogadores
    )
  `).get() as { c: number };

  const total_jogadores = db.prepare('SELECT COUNT(*) as c FROM jogadores').get() as { c: number };
  const total_partidas = db.prepare(`
    SELECT COUNT(DISTINCT Mes || '-' || Dia) as c FROM colocacoes
  `).get() as { c: number };
  const total_kills = db.prepare(`
    SELECT COALESCE(SUM(Q1_Kills + Q2_Kills + Q3_Kills), 0) as c FROM jogadores
  `).get() as { c: number };

  return {
    total_times: total_times.c,
    total_jogadores: total_jogadores.c,
    total_partidas: total_partidas.c,
    total_kills: total_kills.c
  };
}

export function getDashboard(): DashboardData {
  const kills_por_time = db.prepare(`
    SELECT Time, SUM(Q1_Kills + Q2_Kills + Q3_Kills) as total 
    FROM jogadores GROUP BY Time ORDER BY total DESC LIMIT 10
  `).all() as { Time: string; total: number }[];

  const top_jogadores = db.prepare(`
    SELECT Jogador, SUM(Q1_Kills + Q2_Kills + Q3_Kills) as total 
    FROM jogadores GROUP BY Jogador ORDER BY total DESC LIMIT 10
  `).all() as { Jogador: string; total: number }[];

  const distribuicao_q1 = db.prepare(`
    SELECT Q1_Pos as posicao, COUNT(*) as quantidade 
    FROM colocacoes GROUP BY Q1_Pos
  `).all() as { posicao: number; quantidade: number }[];

  const kills_quartis = db.prepare(`
    SELECT 
      SUM(Q1_Kills) as q1_total,
      SUM(Q2_Kills) as q2_total,
      SUM(Q3_Kills) as q3_total
    FROM jogadores
  `).get() as { q1_total: number; q2_total: number; q3_total: number };

  return { kills_por_time, top_jogadores, distribuicao_q1, kills_quartis };
}

// ===== FILTROS =====
export function getMeses(): string[] {
  const rows = db.prepare(`
    SELECT DISTINCT Mes as m FROM (
      SELECT Mes FROM colocacoes UNION SELECT Mes FROM jogadores
    ) ORDER BY m
  `).all() as { m: string }[];
  return rows.map(r => r.m);
}

export function getTimes(): string[] {
  const rows = db.prepare('SELECT DISTINCT Time as t FROM jogadores ORDER BY t').all() as { t: string }[];
  return rows.map(r => r.t);
}

// ===== EXPORTAÇÕES =====
export function exportSQL(): string {
  const tables = db.prepare(`
    SELECT sql FROM sqlite_master 
    WHERE type='table' AND name IN ('colocacoes', 'jogadores')
  `).all() as { sql: string }[];

  let sql = ['-- eSports Database Export', 'PRAGMA foreign_keys=OFF;', 'BEGIN TRANSACTION;'];
  tables.forEach(t => sql.push(t.sql + ';'));

  const colocacoes = db.prepare('SELECT * FROM colocacoes').all() as Colocacao[];
  colocacoes.forEach(row => {
    const vals = Object.values(row).map(v => 
      typeof v === 'string' ? `'${v.replace(/'/g, "''")}'` : v
    ).join(', ');
    sql.push(`INSERT INTO colocacoes VALUES (${vals});`);
  });

  const jogadores = db.prepare('SELECT * FROM jogadores').all() as Jogador[];
  jogadores.forEach(row => {
    const vals = Object.values(row).map(v => 
      typeof v === 'string' ? `'${v.replace(/'/g, "''")}'` : v
    ).join(', ');
    sql.push(`INSERT INTO jogadores VALUES (${vals});`);
  });

  sql.push('COMMIT;');
  return sql.join('\n');
}

export function exportCSV(): string {
  const csv = ['Tipo;Mes;Dia;Time;Jogador;Q1;Q2;Q3'];

  const colocacoes = db.prepare('SELECT * FROM colocacoes').all() as Colocacao[];
  colocacoes.forEach(row => {
    csv.push(`Colocacao;${row.Mes};${row.Dia};${row.Time};;${row.Q1_Pos};${row.Q2_Pos};${row.Q3_Pos}`);
  });

  const jogadores = db.prepare('SELECT * FROM jogadores').all() as Jogador[];
  jogadores.forEach(row => {
    csv.push(`Jogador;${row.Mes};${row.Dia};${row.Time};${row.Jogador};${row.Q1_Kills};${row.Q2_Kills};${row.Q3_Kills}`);
  });

  return csv.join('\n');
}
