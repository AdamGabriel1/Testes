<script lang="ts">
	import { stats } from '$lib/stores';

	const cards = [
		{ label: 'Total de Times', key: 'total_times', icon: 'fa-users', color: 'indigo' },
		{ label: 'Total de Jogadores', key: 'total_jogadores', icon: 'fa-user-ninja', color: 'purple' },
		{ label: 'Partidas Registradas', key: 'total_partidas', icon: 'fa-calendar-check', color: 'pink' },
		{ label: 'Total de Kills', key: 'total_kills', icon: 'fa-skull', color: 'rose' }
	] as const;

	const colorMap: Record<string, string> = {
		indigo: 'bg-indigo-500/20 text-indigo-400',
		purple: 'bg-purple-500/20 text-purple-400',
		pink: 'bg-pink-500/20 text-pink-400',
		rose: 'bg-rose-500/20 text-rose-400'
	};
</script>

<div class="grid grid-cols-1 md:grid-cols-4 gap-4">
	{#each cards as card, i}
		<div class="stats-card rounded-2xl p-5 animate-fade-in" style="animation-delay: {i * 0.1}s">
			<div class="flex items-center justify-between">
				<div>
					<p class="text-slate-400 text-sm">{card.label}</p>
					<p class="text-2xl font-bold text-white mt-1">{$stats[card.key as keyof typeof $stats]}</p>
				</div>
				<div class="w-12 h-12 rounded-xl {colorMap[card.color]} flex items-center justify-center">
					<i class="fas {card.icon} text-xl"></i>
				</div>
			</div>
		</div>
	{/each}
</div>
