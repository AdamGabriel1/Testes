<script lang="ts">
	import { createEventDispatcher } from 'svelte';
	import { fly } from 'svelte/transition';

	export let open = false;
	export let title = 'Novo Registro';
	export let type: 'colocacoes' | 'jogadores' = 'colocacoes';
	export let editingId: number | null = null;

	const dispatch = createEventDispatcher<{ submit: Record<string, unknown>; close: void }>();

	const meses = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

	let mes = 'Maio';
	let dia = 1;
	let time = '';
	let jogador = '';
	let q1 = 0;
	let q2 = 0;
	let q3 = 0;

	export function setData(data: Record<string, unknown> | null) {
		if (data) {
			mes = String(data.Mes);
			dia = Number(data.Dia);
			time = String(data.Time);
			jogador = String(data.Jogador || '');
			if (type === 'colocacoes') {
				q1 = Number(data.Q1_Pos);
				q2 = Number(data.Q2_Pos);
				q3 = Number(data.Q3_Pos);
			} else {
				q1 = Number(data.Q1_Kills);
				q2 = Number(data.Q2_Kills);
				q3 = Number(data.Q3_Kills);
			}
		} else {
			mes = 'Maio'; dia = 1; time = ''; jogador = ''; q1 = 0; q2 = 0; q3 = 0;
		}
	}

	function handleSubmit() {
		const data: Record<string, unknown> = { Mes: mes, Dia: dia, Time: time };
		if (type === 'jogadores') data.Jogador = jogador;
		if (type === 'colocacoes') {
			data.Q1_Pos = q1; data.Q2_Pos = q2; data.Q3_Pos = q3;
		} else {
			data.Q1_Kills = q1; data.Q2_Kills = q2; data.Q3_Kills = q3;
		}
		dispatch('submit', data);
	}
</script>

{#if open}
	<div class="fixed inset-0 z-50">
		<div class="modal-overlay absolute inset-0" on:click={() => dispatch('close')}></div>
		<div class="absolute inset-0 flex items-center justify-center p-4">
			<div class="glass-strong rounded-2xl w-full max-w-lg p-6 animate-slide-in relative" transition:fly={{ y: -20, duration: 300 }}>
				<button on:click={() => dispatch('close')} class="absolute top-4 right-4 text-slate-400 hover:text-white transition-colors">
					<i class="fas fa-times text-xl"></i>
				</button>
				<h3 class="text-xl font-bold text-white mb-6">{title}</h3>
				<form on:submit|preventDefault={handleSubmit} class="space-y-4">
					<div class="grid grid-cols-2 gap-4">
						<div>
							<label class="block text-sm font-medium text-slate-400 mb-1">Mês</label>
							<select bind:value={mes} required class="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow">
								{#each meses as m}
									<option value={m}>{m}</option>
								{/each}
							</select>
						</div>
						<div>
							<label class="block text-sm font-medium text-slate-400 mb-1">Dia</label>
							<input type="number" bind:value={dia} min="1" max="31" required class="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow">
						</div>
					</div>
					<div>
						<label class="block text-sm font-medium text-slate-400 mb-1">Time</label>
						<input type="text" bind:value={time} required class="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow">
					</div>
					{#if type === 'jogadores'}
						<div>
							<label class="block text-sm font-medium text-slate-400 mb-1">Jogador</label>
							<input type="text" bind:value={jogador} required class="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow">
						</div>
					{/if}
					<div class="grid grid-cols-3 gap-4">
						<div><label class="block text-sm font-medium text-slate-400 mb-1">Q1</label><input type="number" bind:value={q1} min="0" required class="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow text-center"></div>
						<div><label class="block text-sm font-medium text-slate-400 mb-1">Q2</label><input type="number" bind:value={q2} min="0" required class="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow text-center"></div>
						<div><label class="block text-sm font-medium text-slate-400 mb-1">Q3</label><input type="number" bind:value={q3} min="0" required class="w-full px-4 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-white outline-none input-glow text-center"></div>
					</div>
					<div class="flex gap-3 pt-4">
						<button type="button" on:click={() => dispatch('close')} class="flex-1 py-2.5 rounded-xl border border-slate-600 text-slate-300 hover:bg-slate-700/50 transition-all font-medium">Cancelar</button>
						<button type="submit" class="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-semibold hover:shadow-lg hover:shadow-indigo-500/30 transition-all">Salvar</button>
					</div>
				</form>
			</div>
		</div>
	</div>
{/if}
