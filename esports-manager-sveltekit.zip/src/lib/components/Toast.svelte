<script lang="ts">
	import { toastMessage } from '$lib/stores';
	import { fly } from 'svelte/transition';

	$: msg = $toastMessage;
</script>

{#if msg}
	<div
		class="fixed bottom-6 right-6 z-50"
		transition:fly={{ y: 20, duration: 300 }}
	>
		<div class="glass-strong rounded-xl px-6 py-4 flex items-center gap-3 border {msg.type === 'error' ? 'border-rose-500/30' : 'border-emerald-500/30'}">
			<i class="fas {msg.type === 'error' ? 'fa-exclamation-circle text-rose-400' : 'fa-check-circle text-emerald-400'} text-xl"></i>
			<span class="text-white font-medium">{msg.msg}</span>
		</div>
	</div>
{/if}
