/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    // App Router já é padrão no Next.js 15
  },
  async rewrites() {
    return [
      {
        source: '/api/:path*',
        destination: 'http://localhost:5000/api/:path*',
      },
    ];
  },
};

module.exports = nextConfig;
